#include <stdint.h>
typedef unsigned int uint; typedef unsigned long long ulonglong; typedef long long longlong;
typedef unsigned short ushort; typedef signed char sbyte; typedef unsigned char byte;
uint FUN_0047d0d0(longlong param_1,uint param_2,uint param_3)

{
  uint uVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  sbyte sVar5;
  byte bVar6;
  byte bVar7;
  byte bVar8;
  uint uVar9;
  ulonglong uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  ulonglong uVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  int iVar19;
  
  uVar1 = *(uint *)(param_1 + 0x100027c);
  if ((uVar1 & 0x100) == 0) {
    if ((param_2 & 0x8000) != 0) goto code_r0x0047d1c9;
code_r0x0047d0f2:
    uVar3 = *(uint *)(param_1 + 0x1000344);
    uVar16 = (uint)*(ushort *)(param_1 + 0x1000340);
    uVar12 = uVar3 >> 0x1e;
    if (1 < uVar12) goto code_r0x0047d10e;
code_r0x0047d1e5:
    uVar12 = uVar12 << 0xf;
    uVar13 = uVar16 & 0x8000;
    uVar14 = (int)uVar16 >> 6 & 3;
code_r0x0047d21f:
    uVar11 = uVar3 >> 0x1c & 3;
    if (uVar11 == 1) goto code_r0x0047d171;
code_r0x0047d230:
    if (uVar11 == 3) {
      if (((uVar3 & 0x1000000) == 0) || ((uVar13 == 0 && (uVar14 != 2)))) {
        iVar19 = *(int *)(param_1 + 0x10002fc);
        if (iVar19 == 1) {
          uVar12 = uVar12 | param_2 & 1;
        }
        else if (iVar19 == 2) {
          uVar12 = uVar12 | *(int *)(param_1 + 0x10002b4) >> 0xf & 1U;
        }
        else if (iVar19 == 0) {
          uVar12 = uVar12 | *(int *)(param_1 + 0x10002b0) >> 0xf & 1U;
        }
        else {
          uVar12 = uVar12 | param_2 >> 0xf & 1;
        }
      }
      else {
        uVar12 = uVar12 | param_3 & 1;
      }
    }
    uVar3 = uVar3 >> 0x16 & 3;
    if (uVar3 != 2) goto code_r0x0047d248;
code_r0x0047d183:
    param_3 = param_3 >> 4 & 1 | param_3 & 0xfffffffe;
    iVar19 = *(int *)(param_1 + 0x10002f8);
    if (iVar19 == 2) goto code_r0x0047d1a6;
code_r0x0047d26d:
    if (iVar19 == 3) {
      uVar10 = (ulonglong)(param_2 >> 5 & 1 | param_2 & 0xfffffffe);
    }
    else {
      uVar10 = (ulonglong)param_2;
      if (iVar19 == 0) {
        uVar10 = (ulonglong)(param_2 & 0xfffffffe);
      }
    }
  }
  else {
    if ((uVar1 & 0x80) == 0) goto code_r0x0047d0f2;
code_r0x0047d1c9:
    uVar3 = *(uint *)(param_1 + 0x1000344);
    uVar16 = (uint)*(ushort *)(param_1 + 0x1000342);
    uVar12 = uVar3 >> 0x1e;
    if (uVar12 < 2) goto code_r0x0047d1e5;
code_r0x0047d10e:
    if ((uVar3 & 0x1000000) != 0) {
      uVar14 = (int)uVar16 >> 6 & 3;
      uVar13 = uVar16 & 0x8000;
      if ((uVar13 != 0) || (uVar14 == 2)) {
        uVar12 = param_3 & 0x8000;
        goto code_r0x0047d21f;
      }
    }
    uVar14 = (int)uVar16 >> 6 & 3;
    uVar13 = uVar16 & 0x8000;
    iVar19 = *(int *)(param_1 + 0x10002fc);
    uVar12 = param_2 & 0x8000;
    if (iVar19 == 1) goto code_r0x0047d21f;
    if (iVar19 == 2) {
      uVar12 = *(uint *)(param_1 + 0x10002b0) & 0x8000;
      goto code_r0x0047d21f;
    }
    if (iVar19 == 0) {
      uVar12 = *(uint *)(param_1 + 0x10002b4) & 0x8000;
      goto code_r0x0047d21f;
    }
    uVar11 = uVar3 >> 0x1c & 3;
    uVar12 = (param_2 & 1) << 0xf;
    if (uVar11 != 1) goto code_r0x0047d230;
code_r0x0047d171:
    uVar12 = uVar12 | 1;
    uVar3 = uVar3 >> 0x16 & 3;
    if (uVar3 == 2) goto code_r0x0047d183;
code_r0x0047d248:
    if (uVar3 == 3) {
      param_3 = param_3 >> 5 & 1 | param_3 & 0xfffffffe;
    }
    else if (uVar3 == 0) {
      param_3 = param_3 & 0xfffffffe;
    }
    iVar19 = *(int *)(param_1 + 0x10002f8);
    if (iVar19 != 2) goto code_r0x0047d26d;
code_r0x0047d1a6:
    uVar10 = (ulonglong)(param_2 >> 4 & 1 | param_2 & 0xfffffffe);
  }
  uVar15 = uVar10;
  if (uVar13 != 0) {
    uVar15 = (ulonglong)param_3;
  }
  uVar3 = (int)uVar16 >> 0xd & 3;
  uVar13 = (uint)uVar15;
  cVar2 = (char)(uVar16 >> 8);
  if (uVar3 == 1) {
    sVar5 = (cVar2 - 1U & 3) + 1;
    uVar17 = (uVar13 & 0x1f) * (((uint)(uVar10 >> 0x10) & 7) + 1) >> sVar5;
    uVar4 = ((uint)(uVar15 >> 5) & 0x1f) * (((uint)(uVar10 >> 0x13) & 7) + 1) >> sVar5;
    uVar3 = (uVar13 >> 10 & 0x1f) * (((uint)(uVar10 >> 0x16) & 7) + 1) >> sVar5;
  }
  else if (uVar3 == 2) {
    uVar17 = (uVar13 & 0x1f) * (((uint)(uVar10 >> 2) & 7) + 1) >> ((byte)uVar10 - 1 & 3) + 1;
    uVar4 = ((uint)(uVar15 >> 5) & 0x1f) * (((uint)(uVar10 >> 7) & 7) + 1) >>
            ((char)(uVar10 >> 5) - 1U & 3) + 1;
    uVar3 = (uVar13 >> 10 & 0x1f) * (((uint)(uVar10 >> 0xc) & 7) + 1) >>
            ((char)(uVar10 >> 10) - 1U & 3) + 1;
  }
  else {
    sVar5 = (cVar2 - 1U & 3) + 1;
    if (uVar3 == 0) {
      iVar19 = ((int)uVar16 >> 10 & 7U) + 1;
      uVar17 = (uVar13 & 0x1f) * iVar19 >> sVar5;
      uVar4 = ((uint)(uVar15 >> 5) & 0x1f) * iVar19 >> sVar5;
      uVar3 = (uVar13 >> 10 & 0x1f) * iVar19 >> sVar5;
    }
    else {
      uVar17 = (uVar13 & 0x1f) * (((uint)(uVar10 >> 2) & 7) + 1) >> sVar5;
      uVar4 = ((uint)(uVar15 >> 5) & 0x1f) * (((uint)(uVar10 >> 7) & 7) + 1) >> sVar5;
      uVar3 = (uVar13 >> 10 & 0x1f) * (((uint)(uVar10 >> 0xc) & 7) + 1) >> sVar5;
    }
  }
  if (uVar14 == 0) {
    if ((uVar16 & 1) != 0) {
      uVar3 = (int)uVar3 >> 1;
      uVar4 = (int)uVar4 >> 1;
      uVar17 = (int)uVar17 >> 1;
    }
    if (((uVar1 & 0x400) != 0) && ((uVar16 & 8) != 0)) {
code_r0x0047d43c:
      uVar17 = (uVar4 & 0x1f) << 5 | (uVar3 & 0x1f) << 10 | uVar17 & 0x1f;
      goto code_r0x0047d3fa;
    }
  }
  else {
    if (uVar14 == 1) {
      uVar14 = (int)uVar16 >> 1 & 0x1f;
      uVar13 = uVar14;
      uVar18 = uVar14;
    }
    else if (uVar14 == 2) {
      uVar14 = param_3 & 0x1f;
      uVar13 = param_3 >> 10 & 0x1f;
      uVar18 = param_3 >> 5 & 0x1f;
    }
    else {
      uVar14 = (uint)uVar10 & 0x1f;
      uVar13 = (uint)(uVar10 >> 10) & 0x1f;
      uVar18 = (uint)(uVar10 >> 5) & 0x1f;
    }
    if ((uVar1 & 0x400) == 0) {
      if ((uVar1 & 0x800) == 0) {
        uVar3 = uVar3 + uVar13;
        uVar4 = uVar4 + uVar18;
        uVar17 = uVar17 + uVar14;
      }
      else {
        uVar3 = uVar3 ^ uVar13;
        uVar4 = uVar4 ^ uVar18;
        uVar17 = uVar17 ^ uVar14;
      }
      if ((uVar16 & 1) != 0) {
        uVar3 = (int)uVar3 >> 1;
        uVar4 = (int)uVar4 >> 1;
        uVar17 = (int)uVar17 >> 1;
      }
    }
    else {
      uVar9 = (int)uVar16 >> 4 & 3;
      if (uVar9 == 3) {
        bVar6 = (byte)uVar10 & 3;
        bVar7 = (byte)(uVar10 >> 5) & 3;
        bVar8 = (byte)((uint)uVar10 >> 10) & 3;
      }
      else {
        bVar8 = (byte)uVar9;
        bVar7 = bVar8;
        bVar6 = bVar8;
      }
      uVar14 = (int)uVar14 >> bVar6;
      uVar18 = (int)uVar18 >> bVar7;
      uVar13 = (int)uVar13 >> bVar8;
      if ((uVar16 & 4) != 0) {
        uVar14 = (int)(uVar14 << 0x1b) >> 0x1b;
        uVar18 = (int)(uVar18 << 0x1b) >> 0x1b;
        uVar13 = (int)(uVar13 << 0x1b) >> 0x1b;
      }
      if ((uVar1 & 0x800) == 0) {
        if ((uVar16 & 2) == 0) {
          uVar3 = uVar3 + uVar13;
          uVar4 = uVar4 + uVar18;
          uVar17 = uVar17 + uVar14;
        }
        else {
          uVar3 = uVar3 - uVar13;
          uVar4 = uVar4 - uVar18;
          uVar17 = uVar17 - uVar14;
        }
      }
      else {
        uVar3 = uVar3 ^ uVar13;
        uVar4 = uVar4 ^ uVar18;
        uVar17 = uVar17 ^ uVar14;
      }
      if ((uVar16 & 1) != 0) {
        uVar3 = (int)uVar3 >> 1;
        uVar4 = (int)uVar4 >> 1;
        uVar17 = (int)uVar17 >> 1;
      }
      if ((uVar16 & 8) != 0) goto code_r0x0047d43c;
      if ((uVar16 & 6) != 0) {
        if ((int)uVar3 < 0) {
          uVar3 = 0;
        }
        if ((int)uVar4 < 0) {
          uVar4 = 0;
        }
        if ((int)uVar17 < 0) {
          uVar17 = 0;
        }
      }
    }
  }
  if (0x1f < (int)uVar4) {
    uVar4 = 0x1f;
  }
  if (0x1f < (int)uVar3) {
    uVar3 = 0x1f;
  }
  if (0x1f < (int)uVar17) {
    uVar17 = 0x1f;
  }
  uVar17 = uVar4 << 5 | uVar3 << 10 | uVar17;
code_r0x0047d3fa:
  uVar3 = uVar17 | uVar12;
  if (uVar11 == 0) {
    uVar3 = (uVar17 | uVar12) & 0xfffffffe;
  }
  if (((uVar1 & 0x10) == 0) && ((uVar3 & 0x7fff) == 0)) {
    uVar3 = uVar3 | 0x400;
  }
  return uVar3;
}


