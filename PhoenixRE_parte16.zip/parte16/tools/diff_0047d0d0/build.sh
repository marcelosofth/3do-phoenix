#!/bin/sh
# roda a decompilacao do Ghidra (orig.c) contra cel_pixel em 60 milhoes de entradas aleatorias
cd "$(dirname "$0")" && gcc -O2 -std=gnu11 -w -I../.. -o diff main.c orig.c ../../cel.c -lm && ./diff
