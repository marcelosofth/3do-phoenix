
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cel.h"
typedef unsigned int uint; typedef long long longlong;
uint FUN_0047d0d0(longlong param_1, uint param_2, uint param_3);
static uint64_t s=88172645463325252ull;
static uint32_t rnd(void){ s^=s<<13; s^=s>>7; s^=s<<17; return (uint32_t)(s>>16); }
int main(void){
  unsigned char *mem = calloc(1, 0x1001000);
  long long base = (long long)mem;
  long bad=0, n=0;
  for (long i=0;i<60000000;i++){
    cel_pix_t p;
    p.flags = rnd();
    p.ppmp0 = rnd(); p.ppmp1 = rnd();
    p.pixc = rnd();
    p.mode_f8 = rnd()&3; p.mode_fc = rnd()&3;
    p.xpos = rnd(); p.ypos = rnd();
    uint32_t src = rnd(), dst = rnd();
    if (i&1){ src |= (rnd()&0xff)<<16; }
    *(uint32_t*)(mem+0x100027c)=p.flags;
    *(uint16_t*)(mem+0x1000340)=p.ppmp0; *(uint16_t*)(mem+0x1000342)=p.ppmp1;
    *(uint32_t*)(mem+0x1000344)=p.pixc;
    *(int32_t*)(mem+0x10002f8)=p.mode_f8; *(int32_t*)(mem+0x10002fc)=p.mode_fc;
    *(int32_t*)(mem+0x10002b0)=p.xpos; *(int32_t*)(mem+0x10002b4)=p.ypos;
    uint a = FUN_0047d0d0(base, src, dst);
    uint b = cel_pixel(&p, src, dst);
    n++;
    if (a!=b){ if (bad<10) printf("DIFF fl=%08x p0=%04x p1=%04x pixc=%08x f8=%d fc=%d x=%d y=%d s=%08x d=%08x orig=%08x novo=%08x\n", p.flags,p.ppmp0,p.ppmp1,p.pixc,p.mode_f8,p.mode_fc,p.xpos,p.ypos,src,dst,a,b); bad++; }
  }
  printf("comparados %ld, divergencias %ld\n", n, bad);
  return bad!=0;
}