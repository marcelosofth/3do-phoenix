// FUN_0048f9f0 @ 0048f9f0 size=2326
// callers: 0049fda0 
// callees: 0047ac10:FUN_0047ac10 00427d90:FUN_00427d90 0047b7c0:FUN_0047b7c0 00498630:FUN_00498630 008ff560:FUN_008ff560 00498690:FUN_00498690 00498660:FUN_00498660 00498500:FUN_00498500 0045f8a0:FUN_0045f8a0 0047ac00:FUN_0047ac00 0047b8e0:FUN_0047b8e0 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048f9f0(longlong *param_1,uint param_2,ulonglong param_3)

{
  longlong *plVar1;
  uint *puVar2;
  char cVar3;
  uint uVar4;
  code *pcVar5;
  uint uVar6;
  longlong *plVar7;
  ushort uVar8;
  undefined8 uVar9;
  ulonglong uVar10;
  ushort uVar11;
  uint uVar12;
  int iVar13;
  ulonglong uVar14;
  ushort uVar15;
  int iVar16;
  
  uVar12 = (uint)param_3;
  uVar14 = param_3 & 0xffffffff;
  uVar4 = param_2 & 0xfffc;
  uVar6 = uVar4 >> 0xc;
  uVar11 = (ushort)uVar14;
  uVar15 = (ushort)param_3;
  if (uVar6 != 1) {
    if (uVar6 == 0) {
      switch(uVar4 >> 8) {
      case 0:
        switch(uVar4) {
        case 0x30:
          if ((char)param_1[0x10ccf] == '\0') {
            uVar4 = 0x613;
            if (uVar12 < 0x614) {
              uVar4 = uVar12;
            }
            iVar13 = 0x15a8;
            iVar16 = (*(uint *)((longlong)param_1 + 0x96694) / 0x15a8) * 0x613 + uVar4;
            uVar14 = 0x613;
          }
          else {
            uVar4 = 0x620;
            if (uVar12 < 0x621) {
              uVar4 = uVar12;
            }
            iVar13 = 0x15d7;
            iVar16 = (*(uint *)((longlong)param_1 + 0x96694) / 0x15d7) * 0x620 + uVar4;
            uVar14 = 0x620;
          }
          *(int *)((longlong)param_1 + 0x96694) = (int)((uint)(iVar13 * iVar16) / uVar14);
          return;
        case 0x3c:
          return;
        case 0x40:
          uVar12 = uVar12 | *(uint *)((longlong)param_1 + 0x866cc);
          *(uint *)((longlong)param_1 + 0x866cc) = uVar12;
          if (*(int *)((longlong)param_1 + 0x866ec) == 0) {
            return;
          }
          *(uint *)((longlong)param_1 + 0x866cc) = uVar12 | 0x80000000;
          return;
        case 0x44:
          uVar4 = ~uVar12 & *(uint *)((longlong)param_1 + 0x866cc);
          *(uint *)((longlong)param_1 + 0x866cc) = uVar4;
          if (*(int *)((longlong)param_1 + 0x866ec) != 0) {
            return;
          }
          *(uint *)((longlong)param_1 + 0x866cc) = uVar4 & 0x7fffffff;
          return;
        case 0x48:
          *(uint *)((longlong)param_1 + 0x866d4) = *(uint *)((longlong)param_1 + 0x866d4) | uVar12;
          return;
        case 0x4c:
          *(uint *)((longlong)param_1 + 0x866d4) =
               ~uVar12 & *(uint *)((longlong)param_1 + 0x866d4) | 0x80000000;
          return;
        case 0x50:
          *(uint *)((longlong)param_1 + 0x866dc) = *(uint *)((longlong)param_1 + 0x866dc) | uVar12;
          return;
        case 0x54:
          *(uint *)((longlong)param_1 + 0x866dc) = *(uint *)((longlong)param_1 + 0x866dc) & ~uVar12;
          return;
        case 0x60:
          puVar2 = (uint *)((longlong)param_1 + 0x866ec);
          *puVar2 = *puVar2 | uVar12;
          if (*puVar2 == 0) {
            return;
          }
          *(uint *)((longlong)param_1 + 0x866cc) =
               *(uint *)((longlong)param_1 + 0x866cc) | 0x80000000;
          return;
        case 100:
          puVar2 = (uint *)((longlong)param_1 + 0x866ec);
          *puVar2 = *puVar2 & ~uVar12;
          if (*puVar2 != 0) {
            return;
          }
          *(uint *)((longlong)param_1 + 0x866cc) =
               *(uint *)((longlong)param_1 + 0x866cc) & 0x7fffffff;
          return;
        case 0x68:
          *(uint *)((longlong)param_1 + 0x866f4) = *(uint *)((longlong)param_1 + 0x866f4) | uVar12;
          return;
        case 0x6c:
          *(uint *)((longlong)param_1 + 0x866f4) = *(uint *)((longlong)param_1 + 0x866f4) & ~uVar12;
          return;
        case 0x84:
          *(uint *)(param_1 + 0x10ce2) = uVar12 & 0xf;
          return;
        }
        break;
      case 1:
        if (uVar4 < 0x180) {
          *(uint *)((longlong)param_1 + (ulonglong)(uVar4 >> 2) * 4 + 0x8668c) = uVar12 & 0xffff;
          return;
        }
        break;
      case 2:
        switch(uVar4) {
        case 0x200:
          *(uint *)((longlong)param_1 + 0x8688c) = *(uint *)((longlong)param_1 + 0x8688c) | uVar12;
          return;
        case 0x204:
          *(uint *)((longlong)param_1 + 0x8688c) = *(uint *)((longlong)param_1 + 0x8688c) & ~uVar12;
          return;
        case 0x208:
          *(uint *)((longlong)param_1 + 0x86894) = *(uint *)((longlong)param_1 + 0x86894) | uVar12;
          return;
        case 0x20c:
          *(uint *)((longlong)param_1 + 0x86894) = *(uint *)((longlong)param_1 + 0x86894) & ~uVar12;
          return;
        case 0x220:
          *(uint *)((longlong)param_1 + 0x868ac) = uVar12 & 0x3ff;
                    /* WARNING: Could not recover jumptable at 0x0048ff87. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          (**(code **)(*param_1 + 0x78))(param_1,param_1,1,0);
          return;
        }
        break;
      case 3:
        if (uVar4 < 0x380) {
          if (uVar4 == 0x304) {
            *(uint *)(param_1 + 0x10d32) = *(uint *)(param_1 + 0x10d32) | uVar12;
            return;
          }
          if (uVar4 == 0x308) {
            *(uint *)(param_1 + 0x10d32) = *(uint *)(param_1 + 0x10d32) & ~uVar12;
            return;
          }
          if (uVar4 == 0x300) {
            if ((char)param_1[0x10cd0] != '\0') {
              (**(code **)(*param_1 + 0x40))(param_1,3);
            }
            iVar13 = 0;
            plVar1 = param_1 + 0x12cd3;
            *(uint *)(param_1 + 0x10d32) = *(uint *)(param_1 + 0x10d32) & ~uVar12;
            do {
              uVar4 = 1 << ((byte)iVar13 & 0x1f);
              if ((uVar4 & (uint)uVar14) != 0) {
                iVar16 = iVar13 * 0x10;
                if (param_1[0x12cd3] != 0) {
                  pcVar5 = (code *)param_1[0x12cd4];
                  plVar7 = (longlong *)(param_1[0x12cd3] + param_1[0x12cd5]);
                  if (((ulonglong)pcVar5 & 1) != 0) {
                    pcVar5 = *(code **)(pcVar5 + *plVar7 + -1);
                  }
                  (*pcVar5)(plVar7,iVar16 + 0x400,0);
                }
                FUN_008ff560(plVar1,iVar16 + 0x404);
                FUN_008ff560(plVar1,iVar16 + 0x408);
                uVar14 = (ulonglong)((uint)uVar14 & ~uVar4);
                FUN_008ff560(plVar1,iVar16 + 0x40c);
              }
              iVar13 = iVar13 + 1;
            } while (iVar13 != 0xd);
            iVar13 = 0;
            param_1 = param_1 + 0x12cd3;
            do {
              uVar4 = 1 << ((char)iVar13 + 0x10U & 0x1f);
              if ((uVar4 & (uint)uVar14) != 0) {
                iVar16 = iVar13 * 0x10;
                uVar14 = (ulonglong)((uint)uVar14 & ~uVar4);
                FUN_008ff560(param_1,iVar16 + 0x500,0);
                FUN_008ff560(param_1,iVar16 + 0x504);
                FUN_008ff560(param_1,iVar16 + 0x508);
                FUN_008ff560(param_1,iVar16 + 0x50c);
              }
              iVar13 = iVar13 + 1;
            } while (iVar13 != 4);
            return;
          }
        }
        break;
      case 4:
        if (uVar4 == 0x400) {
          *(uint *)((longlong)param_1 + 0x86a8c) = uVar12 & 0xffffbf7f;
          if ((param_3 & 0x800) != 0) {
            return;
          }
          *(uint *)((longlong)param_1 + 0x86a8c) = uVar12 & 0xffffbf7f | 0x80;
          return;
        }
        break;
      case 5:
        if ((*(uint *)((longlong)param_1 + 0x86a8c) & 0x80) != 0) {
          if (0xb < (uVar4 >> 4) - 0x54) {
            FUN_00498690(param_1 + 5,param_3 & 0xffffffff);
            return;
          }
          param_1 = param_1 + 5;
          switch(uVar4 >> 4) {
          default:
            FUN_00498660(param_1,param_3 & 0xffffffff);
            return;
          case 0x58:
          case 0x59:
          case 0x5a:
          case 0x5b:
            FUN_00498500(param_1,param_3 & 0xffffffff);
            return;
          case 0x5c:
          case 0x5d:
          case 0x5e:
          case 0x5f:
            FUN_00498630(param_1,param_3 & 0xffffffff);
            return;
          }
        }
        if ((uVar4 >> 4) - 0x50 < 4) {
          *(uint *)((longlong)param_1 + 0x86b8c) = uVar12;
          *(uint *)((longlong)param_1 + 0x86a8c) = *(uint *)((longlong)param_1 + 0x86a8c) | 0x40;
        }
      }
      goto switchD_0048fb58_default;
    }
    if (uVar6 != 2) {
      if ((uVar6 == 3) && (uVar6 = uVar4 >> 8, 0x2f < uVar6)) {
        if (uVar6 < 0x34) {
          uVar4 = uVar4 >> 1 & 0xfe;
          FUN_0045f8a0(param_1 + 0x95,uVar4,uVar12 >> 0x10);
          uVar4 = uVar4 + 1;
        }
        else {
          if (0x37 < uVar6) goto switchD_0048fb58_default;
          uVar4 = uVar4 - 0x3400 >> 2;
        }
        FUN_0045f8a0(param_1 + 0x95,uVar4,param_3 & 0xffff);
        return;
      }
      goto switchD_0048fb58_default;
    }
    uVar14 = (ulonglong)(int)((param_2 & 0x7ff) >> 2);
    if (*(ushort *)(param_1 + (uVar14 + 0x45) * 4 + 0x96) == 0) {
      *(undefined1 *)(param_1 + 0xa1) = 1;
      uVar11 = uVar15;
      if ((char)param_1[0x9a] == '\0') goto LAB_0048fba4;
      *(undefined1 *)((longlong)param_1 + 0x4dc) = 1;
      while (cVar3 = FUN_0047ac10(_DAT_00cf4050,(int)param_1[0x9b]), cVar3 == '\0') {
        FUN_0047ac00(_DAT_00cf4050,0);
      }
    }
    else {
      uVar11 = uVar15;
      if (((ushort)((uVar15 ^ *(ushort *)((longlong)param_1 + uVar14 * 2 + 0x10d3c)) &
                   ~*(ushort *)(param_1 + (uVar14 + 0x45) * 4 + 0x96)) == 0) ||
         (*(undefined1 *)(param_1 + 0xa1) = 1, (char)param_1[0x9a] == '\0')) goto LAB_0048fba4;
      *(undefined1 *)((longlong)param_1 + 0x4dc) = 1;
      while (cVar3 = FUN_0047ac10(_DAT_00cf4050,(int)param_1[0x9b]), cVar3 == '\0') {
        FUN_0047ac00(_DAT_00cf4050,0);
      }
    }
LAB_0048faf6:
    *(undefined1 *)((longlong)param_1 + 0x4dc) = 0;
    uVar11 = uVar15;
LAB_0048fba4:
    *(undefined1 *)((longlong)param_1 + 0x509) = 0;
    *(ushort *)((longlong)param_1 + uVar14 * 2 + 0x10d3c) = uVar11;
    return;
  }
  if (uVar4 < 0x17d0) {
switchD_0048fb58_default:
    *(uint *)((longlong)param_1 + (ulonglong)(uVar4 >> 2) * 4 + 0x8668c) = uVar12;
    return;
  }
  switch(uVar4) {
  case 0x17d0:
    if ((char)param_1[0x9a] == '\0') {
      *(ushort *)((longlong)param_1 + 0x12216) = uVar11;
      *(undefined2 *)((longlong)param_1 + 0x12214) = 8;
    }
    else {
      FUN_0047b7c0(_DAT_00cf4050,*(undefined4 *)((longlong)param_1 + 0x4d4));
      *(ushort *)((longlong)param_1 + 0x12216) = uVar11;
      *(undefined2 *)((longlong)param_1 + 0x12214) = 8;
      if ((char)param_1[0x9a] != '\0') {
        FUN_0047b8e0(_DAT_00cf4050,*(undefined4 *)((longlong)param_1 + 0x4d4));
        return;
      }
    }
    break;
  case 0x17d4:
  case 0x17d8:
  case 0x17dc:
  case 0x17e0:
  case 0x17ec:
  case 0x17f0:
  case 0x17f4:
  case 0x17f8:
    goto switchD_0048fb58_default;
  case 0x17e4:
    uVar9 = 1;
    goto LAB_0048fdae;
  case 0x17e8:
    uVar9 = 0;
LAB_0048fdae:
    FUN_00427d90(param_1 + 0x95,uVar9);
    return;
  case 0x17fc:
    *(uint *)((longlong)param_1 + 0x12264) = uVar12 & 1;
    break;
  default:
    uVar4 = (param_2 & 0xfbfc) - 0x1800 >> 1;
    uVar10 = (ulonglong)(uVar4 & 0x3fe);
    uVar8 = (ushort)(uVar14 >> 0x10);
    if (*(ushort *)(param_1 + (uVar10 + 0x45) * 4 + 0x96) == 0) {
      *(undefined1 *)(param_1 + 0xa1) = 1;
      if ((char)param_1[0x9a] != '\0') {
        *(undefined1 *)((longlong)param_1 + 0x4dc) = 1;
        while (cVar3 = FUN_0047ac10(_DAT_00cf4050,(int)param_1[0x9b]), cVar3 == '\0') {
          FUN_0047ac00(_DAT_00cf4050,0);
        }
        goto LAB_004901a4;
      }
    }
    else if (((ushort)((uVar8 ^ *(ushort *)((longlong)param_1 + uVar10 * 2 + 0x10d3c)) &
                      ~*(ushort *)(param_1 + (uVar10 + 0x45) * 4 + 0x96)) != 0) &&
            (*(undefined1 *)(param_1 + 0xa1) = 1, (char)param_1[0x9a] != '\0')) {
      *(undefined1 *)((longlong)param_1 + 0x4dc) = 1;
      while (cVar3 = FUN_0047ac10(_DAT_00cf4050,(int)param_1[0x9b]), cVar3 == '\0') {
        FUN_0047ac00(_DAT_00cf4050,0);
      }
LAB_004901a4:
      *(undefined1 *)((longlong)param_1 + 0x4dc) = 0;
    }
    *(undefined1 *)((longlong)param_1 + 0x509) = 0;
    *(ushort *)((longlong)param_1 + uVar10 * 2 + 0x10d3c) = uVar8;
    uVar14 = (ulonglong)(uVar4 + 1 & 0x3ff);
    if (*(ushort *)(param_1 + (uVar14 + 0x45) * 4 + 0x96) == 0) {
      *(undefined1 *)(param_1 + 0xa1) = 1;
      if ((char)param_1[0x9a] == '\0') goto LAB_0048fba4;
      *(undefined1 *)((longlong)param_1 + 0x4dc) = 1;
      while (cVar3 = FUN_0047ac10(_DAT_00cf4050,(int)param_1[0x9b]), cVar3 == '\0') {
        FUN_0047ac00(_DAT_00cf4050,0);
      }
    }
    else {
      if (((ushort)((uVar15 ^ *(ushort *)((longlong)param_1 + uVar14 * 2 + 0x10d3c)) &
                   ~*(ushort *)(param_1 + (uVar14 + 0x45) * 4 + 0x96)) == 0) ||
         (*(undefined1 *)(param_1 + 0xa1) = 1, (char)param_1[0x9a] == '\0')) goto LAB_0048fba4;
      *(undefined1 *)((longlong)param_1 + 0x4dc) = 1;
      while (cVar3 = FUN_0047ac10(_DAT_00cf4050,(int)param_1[0x9b]), cVar3 == '\0') {
        FUN_0047ac00(_DAT_00cf4050,0);
      }
    }
    goto LAB_0048faf6;
  }
  return;
}


