// FUN_004a0e10 @ 004a0e10 size=191
// callers: 004a19a0 0093b430 
// callees: 0093b400:FUN_0093b400 008ce290:operator.new[] 008de260:FUN_008de260 

void FUN_004a0e10(longlong *param_1,undefined1 param_2)

{
  int iVar1;
  int *piVar2;
  uint *puVar3;
  ulonglong uVar4;
  uint uVar5;
  uint uVar6;
  
  piVar2 = (int *)*param_1;
  iVar1 = *piVar2;
  uVar6 = iVar1 + 1;
  if (((int)uVar6 <= piVar2[1]) && (piVar2[2] < 2)) {
    *(undefined1 *)((longlong)piVar2 + (longlong)iVar1 + 0xc) = param_2;
    *(uint *)*param_1 = uVar6;
    *(undefined1 *)(*param_1 + 0xc + (longlong)(int)uVar6) = 0;
    return;
  }
  uVar5 = iVar1 + 2 + (uVar6 >> 1);
  if (uVar5 < 0x20) {
    uVar4 = 0x30;
    uVar5 = 0x20;
  }
  else {
    uVar4 = (longlong)(int)uVar5 + 0x10;
  }
  puVar3 = operator_new__(uVar4);
  *puVar3 = uVar6;
  puVar3[1] = uVar5;
  puVar3[2] = 1;
  *(undefined1 *)((longlong)puVar3 + (longlong)(int)uVar6 + 0xc) = 0;
  iVar1 = 0;
  if (*(int *)*param_1 != 0) {
    FUN_008de260(puVar3 + 3,(int *)*param_1 + 3);
    iVar1 = *(int *)*param_1;
  }
  *(undefined1 *)((longlong)puVar3 + (longlong)iVar1 + 0xc) = param_2;
  FUN_0093b400(param_1);
  *param_1 = (longlong)puVar3;
  return;
}


