// FUN_0048f690 @ 0048f690 size=696
// callers: 00490890 
// callees: 00498570:FUN_00498570 00498540:FUN_00498540 00498690:FUN_00498690 0048ef80:FUN_0048ef80 

void FUN_0048f690(longlong param_1)

{
  longlong lVar1;
  undefined1 uVar2;
  uint uVar3;
  uint uVar4;
  ulonglong uVar5;
  code *pcVar6;
  longlong *plVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  
  if (((*(byte *)(param_1 + 0x86992) & 0x10) != 0) && ((*(byte *)(param_1 + 0x86a8d) & 8) != 0)) {
    lVar1 = param_1 + 0x28;
    uVar5 = FUN_00498570(lVar1);
    if ((uVar5 & 0x20) != 0) {
      if (*(longlong *)(param_1 + 0x966b0) == 0) {
        uVar4 = *(uint *)(param_1 + 0x966c8);
        uVar3 = uVar4;
      }
      else {
        pcVar6 = *(code **)(param_1 + 0x966b8);
        plVar7 = (longlong *)(*(longlong *)(param_1 + 0x966b0) + *(longlong *)(param_1 + 0x966c0));
        if (((ulonglong)pcVar6 & 1) != 0) {
          pcVar6 = *(code **)(pcVar6 + *plVar7 + -1);
        }
        uVar3 = (*pcVar6)(plVar7,0x540);
        if (*(longlong *)(param_1 + 0x966b0) == 0) {
          uVar4 = *(uint *)(param_1 + 0x966c8);
        }
        else {
          pcVar6 = *(code **)(param_1 + 0x966b8);
          plVar7 = (longlong *)(*(longlong *)(param_1 + 0x966b0) + *(longlong *)(param_1 + 0x966c0))
          ;
          if (((ulonglong)pcVar6 & 1) != 0) {
            pcVar6 = *(code **)(pcVar6 + *plVar7 + -1);
          }
          uVar4 = (*pcVar6)(plVar7,0x544);
        }
      }
      uVar9 = 0xfffffffc;
      *(uint *)(param_1 + 0x86a8c) = *(uint *)(param_1 + 0x86a8c) & 0xffffff7f | 0x400;
      uVar8 = uVar3;
      if ((*(byte *)(param_1 + 0x86a91) & 2) != 0) {
        if ((int)uVar4 < 0) {
          uVar9 = 0xfffffffc;
        }
        else {
          uVar10 = uVar3 + 3;
          do {
            uVar5 = FUN_00498570(lVar1);
            uVar9 = uVar4;
            if ((uVar5 & 0x20) == 0) break;
            uVar2 = FUN_00498540(lVar1);
            if (uVar8 < 0x300000) {
              *(undefined1 *)(*(longlong *)(param_1 + 0x96700) + (ulonglong)(uVar8 ^ 3)) = uVar2;
            }
            uVar2 = FUN_00498540(lVar1);
            if (uVar8 + 1 < 0x300000) {
              *(undefined1 *)(*(longlong *)(param_1 + 0x96700) + (ulonglong)(uVar8 + 1 ^ 3)) = uVar2
              ;
            }
            uVar2 = FUN_00498540(lVar1);
            if (uVar8 + 2 < 0x300000) {
              *(undefined1 *)(*(longlong *)(param_1 + 0x96700) + (ulonglong)(uVar8 + 2 ^ 3)) = uVar2
              ;
            }
            uVar2 = FUN_00498540(lVar1);
            if (uVar10 < 0x300000) {
              *(undefined1 *)(*(longlong *)(param_1 + 0x96700) + (ulonglong)(uVar10 ^ 3)) = uVar2;
            }
            uVar8 = uVar8 + 4;
            uVar10 = uVar10 + 4;
            uVar4 = uVar4 - 4;
            uVar9 = uVar4;
          } while (-1 < (int)uVar4);
          if (uVar8 != uVar3) {
            if (*(longlong *)(param_1 + 0x966d0) != 0) {
              pcVar6 = *(code **)(param_1 + 0x966d8);
              plVar7 = (longlong *)
                       (*(longlong *)(param_1 + 0x966d0) + *(longlong *)(param_1 + 0x966e0));
              if (((ulonglong)pcVar6 & 1) != 0) {
                pcVar6 = *(code **)(pcVar6 + *plVar7 + -1);
              }
              (*pcVar6)(plVar7,uVar3,uVar8 - uVar3);
            }
          }
          if ((int)uVar9 < 0) {
            uVar9 = 0xfffffffc;
          }
        }
      }
      if (*(longlong *)(param_1 + 0x96698) != 0) {
        pcVar6 = *(code **)(param_1 + 0x966a0);
        plVar7 = (longlong *)(*(longlong *)(param_1 + 0x96698) + *(longlong *)(param_1 + 0x966a8));
        if (((ulonglong)pcVar6 & 1) != 0) {
          pcVar6 = *(code **)(pcVar6 + *plVar7 + -1);
        }
        (*pcVar6)(plVar7,0x544);
        if (*(longlong *)(param_1 + 0x96698) != 0) {
          pcVar6 = *(code **)(param_1 + 0x966a0);
          plVar7 = (longlong *)(*(longlong *)(param_1 + 0x96698) + *(longlong *)(param_1 + 0x966a8))
          ;
          if (((ulonglong)pcVar6 & 1) != 0) {
            pcVar6 = *(code **)(pcVar6 + *plVar7 + -1);
          }
          (*pcVar6)(plVar7,0x540,uVar8);
        }
      }
      if ((int)uVar9 < 0) {
        uVar4 = *(uint *)(param_1 + 0x86a8c);
        if ((uVar4 & 0x40) != 0) {
          FUN_00498690(lVar1,*(undefined4 *)(param_1 + 0x86b8c));
          uVar4 = *(uint *)(param_1 + 0x86a8c);
        }
        *(uint *)(param_1 + 0x86990) = *(uint *)(param_1 + 0x86990) & 0xffefffff;
        *(uint *)(param_1 + 0x86a8c) = uVar4 & 0xfffff3bf | 0x80;
        FUN_0048ef80(param_1,0x20000000,0);
        return;
      }
    }
  }
  return;
}


