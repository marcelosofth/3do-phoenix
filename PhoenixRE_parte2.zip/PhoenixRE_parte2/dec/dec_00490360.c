// FUN_00490360 @ 00490360 size=503
// callers: 
// callees: 008ff560:FUN_008ff560 0048ef80:FUN_0048ef80 00a55be0:FUN_00a55be0 

undefined2 FUN_00490360(longlong param_1,ushort param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  longlong *plVar6;
  code *pcVar7;
  longlong lVar8;
  uint uVar9;
  int iVar10;
  undefined2 uVar11;
  
  iVar10 = (param_2 + 0x40) * 0x10;
  if (*(longlong *)(param_1 + 0x966b0) == 0) {
    uVar2 = *(uint *)(param_1 + 0x966c8);
  }
  else {
    pcVar7 = *(code **)(param_1 + 0x966b8);
    plVar6 = (longlong *)(*(longlong *)(param_1 + 0x966b0) + *(longlong *)(param_1 + 0x966c0));
    if (((ulonglong)pcVar7 & 1) != 0) {
      pcVar7 = *(code **)(pcVar7 + *plVar6 + -1);
    }
    uVar2 = (*pcVar7)(plVar6,iVar10);
  }
  uVar11 = 0;
  if (uVar2 != 0) {
    uVar9 = 1 << ((byte)param_2 & 0x1f);
    if ((*(uint *)(param_1 + 0x86990) & uVar9) != 0) {
      iVar1 = iVar10 + 4;
      if (*(longlong *)(param_1 + 0x966b0) == 0) {
        uVar3 = *(uint *)(param_1 + 0x966c8);
      }
      else {
        pcVar7 = *(code **)(param_1 + 0x966b8);
        plVar6 = (longlong *)(*(longlong *)(param_1 + 0x966b0) + *(longlong *)(param_1 + 0x966c0));
        if (((ulonglong)pcVar7 & 1) != 0) {
          pcVar7 = *(code **)(pcVar7 + *plVar6 + -1);
        }
        uVar3 = (*pcVar7)(plVar6,iVar1);
      }
      uVar11 = 0;
      if (-1 < (int)uVar3) {
        if (uVar2 < 0x300000) {
          uVar11 = *(undefined2 *)(*(longlong *)(param_1 + 0x96700) + (ulonglong)(uVar2 ^ 2));
        }
        lVar8 = 0;
        if (*(longlong *)(param_1 + 0x96698) != 0) {
          pcVar7 = *(code **)(param_1 + 0x966a0);
          plVar6 = (longlong *)(*(longlong *)(param_1 + 0x96698) + *(longlong *)(param_1 + 0x966a8))
          ;
          if (((ulonglong)pcVar7 & 1) != 0) {
            pcVar7 = *(code **)(pcVar7 + *plVar6 + -1);
          }
          (*pcVar7)(plVar6,iVar10,uVar2 + 2);
          lVar8 = *(longlong *)(param_1 + 0x96698);
        }
        iVar4 = uVar3 - 6;
        if ((uVar3 & 2) == 0) {
          iVar4 = uVar3 + 2;
        }
        if (lVar8 != 0) {
          pcVar7 = *(code **)(param_1 + 0x966a0);
          plVar6 = (longlong *)(lVar8 + *(longlong *)(param_1 + 0x966a8));
          if (((ulonglong)pcVar7 & 1) != 0) {
            pcVar7 = *(code **)(pcVar7 + *plVar6 + -1);
          }
          (*pcVar7)(plVar6,iVar1,iVar4);
        }
        if (-1 < iVar4) {
          return uVar11;
        }
      }
      iVar4 = FUN_00a55be0(param_1 + 0x966b0,iVar10 + 8);
      FUN_008ff560(param_1 + 0x96698,iVar10,iVar4);
      uVar5 = FUN_00a55be0(param_1 + 0x966b0,iVar10 + 0xc);
      FUN_008ff560(param_1 + 0x96698,iVar1,uVar5);
      FUN_0048ef80(param_1,1 << ((byte)param_2 + 0x10 & 0x1f),0);
      if ((*(char *)(param_1 + 0x86680) == '\0') && (iVar4 == 0)) {
        *(uint *)(param_1 + 0x86990) = *(uint *)(param_1 + 0x86990) & ~uVar9;
      }
    }
  }
  return uVar11;
}


