// FUN_0048ede0 @ 0048ede0 size=219
// callers: 0048eef0 004a9a40 
// callees: 008ce548:_Unwind_SjLj_Register 008ce550:_Unwind_SjLj_Unregister 00483fe0:FUN_00483fe0 0041f6e0:FUN_0041f6e0 

void FUN_0048ede0(undefined8 *param_1)

{
  int *piVar1;
  undefined1 auStack_a8 [40];
  undefined8 *puStack_80;
  undefined1 auStack_78 [8];
  undefined4 uStack_70;
  undefined *puStack_48;
  undefined *puStack_40;
  undefined1 *puStack_38;
  undefined *puStack_30;
  undefined1 *puStack_28;
  undefined1 *puStack_10;
  
  puStack_38 = &stack0xfffffffffffffff8;
  puStack_28 = auStack_a8;
  puStack_48 = &DAT_008ce270;
  puStack_40 = &DAT_00cc1918;
  puStack_30 = &DAT_0048eebb;
  puStack_10 = auStack_78;
  puStack_80 = param_1;
  _Unwind_SjLj_Register(puStack_10);
  *puStack_80 = &PTR_FUN_00c247f0;
  piVar1 = (int *)puStack_80[3];
  if ((piVar1 != (int *)0x0) && (*piVar1 != 0)) {
    if (piVar1[2] < 2) {
      *piVar1 = 0;
    }
    else {
      piVar1[2] = piVar1[2] + -1;
      puStack_80[3] = 0;
    }
  }
  uStack_70 = 1;
  FUN_00483fe0(puStack_80 + 7);
  uStack_70 = 0xffffffff;
  FUN_0041f6e0(puStack_80);
  _Unwind_SjLj_Unregister(puStack_10);
  return;
}


