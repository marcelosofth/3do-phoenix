// FUN_0049fda0 @ 0049fda0 size=217
// callers: 
// callees: 0048f9f0:FUN_0048f9f0 004894c0:FUN_004894c0 0048adb0:FUN_0048adb0 00557550:FUN_00557550 004714e0:FUN_004714e0 

void FUN_0049fda0(longlong param_1,ulonglong param_2,undefined4 param_3)

{
  undefined4 uVar1;
  uint uVar2;
  
  uVar2 = (uint)param_2;
  switch(param_2 >> 0x14 & 0xfff) {
  case 0:
  case 1:
  case 2:
    *(undefined4 *)(param_1 + 0x129755c + (ulonglong)(uVar2 >> 2) * 4) = param_3;
    if (*(int *)(*(longlong *)(*(longlong *)(param_1 + 0x159f568) + 8) + (ulonglong)(uVar2 >> 2) * 4
                ) != 0) {
      FUN_00557550();
      return;
    }
    break;
  case 0x31:
    if ((uVar2 & 0xc0000) == 0x40000) {
      *(char *)(param_1 + 0x159755c + (ulonglong)(uVar2 >> 2 & 0x7fff)) = (char)param_3;
    }
    break;
  case 0x32:
    FUN_004714e0(param_1 + 0x10974f0,uVar2 & 0xfffc);
    return;
  case 0x33:
    if (uVar2 != 0x3300100) {
      FUN_0048adb0(param_1 + 0x1d8);
      return;
    }
    uVar1 = FUN_0048adb0(param_1 + 0x1d8);
    *(undefined4 *)(param_1 + 0x2c) = uVar1;
    if (*(int *)(param_1 + 0x2c) == 0) {
      FUN_004894c0(*(undefined8 *)(param_1 + 0x1097548),0);
      return;
    }
    break;
  case 0x34:
    FUN_0048f9f0(param_1 + 0x1000dc8);
    return;
  }
  return;
}


