// FUN_004a1390 @ 004a1390 size=1402
// callers: 
// callees: 00478a70:FUN_00478a70 00489550:FUN_00489550 0093b400:FUN_0093b400 008ce2b0:__dynamic_cast 0093cad0:FUN_0093cad0 004895d0:FUN_004895d0 00420030:FUN_00420030 0058ec10:FUN_0058ec10 00478af0:FUN_00478af0 008ce550:_Unwind_SjLj_Unregister 008ce548:_Unwind_SjLj_Register 

void FUN_004a1390(longlong param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  int iVar2;
  longlong lVar3;
  undefined1 auStack_c8 [32];
  longlong lStack_a8;
  int iStack_9c;
  undefined1 *puStack_98;
  undefined1 *puStack_90;
  undefined1 auStack_88 [8];
  undefined4 uStack_80;
  undefined *puStack_58;
  undefined *puStack_50;
  undefined1 *puStack_48;
  undefined *puStack_40;
  undefined1 *puStack_38;
  longlong lStack_20;
  undefined1 auStack_18 [16];
  
  puStack_48 = &stack0xfffffffffffffff8;
  puStack_38 = auStack_c8;
  puStack_58 = &DAT_008ce270;
  puStack_50 = &DAT_00cc1e24;
  puStack_90 = auStack_88;
  puStack_40 = &DAT_004a1976;
  puStack_98 = (undefined1 *)CONCAT44(puStack_98._4_4_,param_2);
  lStack_a8 = param_1;
  iStack_9c = param_3;
  _Unwind_SjLj_Register(puStack_90);
  switch((ulonglong)puStack_98 & 0xffffffff) {
  case 0:
    *(int *)(lStack_a8 + 0x159f5d0) = iStack_9c;
    *(int *)(*(longlong *)(lStack_a8 + 0x1097548) + 0x10000c8) = iStack_9c;
    uStack_80 = 0xffffffff;
    FUN_00478a70(*(undefined8 *)(lStack_a8 + 0x1097550));
    if (iStack_9c < 2) {
      FUN_0058ec10(lStack_a8,1);
    }
    break;
  case 1:
    uStack_80 = 0xffffffff;
    FUN_00478af0(*(undefined8 *)(lStack_a8 + 0x1097550),iStack_9c != 0);
    break;
  case 2:
    *(bool *)(lStack_a8 + 0x3c) = iStack_9c != 0;
    break;
  case 3:
    switch(iStack_9c) {
    default:
      *(undefined4 *)(lStack_a8 + 0x40) = 0x10;
      break;
    case 1:
      *(undefined4 *)(lStack_a8 + 0x40) = 0x20;
      break;
    case 2:
      *(undefined4 *)(lStack_a8 + 0x40) = 0x1b;
      break;
    case 3:
      *(undefined4 *)(lStack_a8 + 0x40) = 0x17;
      break;
    case 4:
      *(undefined4 *)(lStack_a8 + 0x40) = 0x14;
      break;
    case 5:
      *(undefined4 *)(lStack_a8 + 0x40) = 0x12;
      break;
    case 6:
      *(undefined4 *)(lStack_a8 + 0x40) = 0xe;
      break;
    case 7:
      *(undefined4 *)(lStack_a8 + 0x40) = 0xc;
      break;
    case 8:
      *(undefined4 *)(lStack_a8 + 0x40) = 0xb;
      break;
    case 9:
      *(undefined4 *)(lStack_a8 + 0x40) = 10;
      break;
    case 10:
      *(undefined4 *)(lStack_a8 + 0x40) = 9;
      break;
    case 0xb:
      *(undefined4 *)(lStack_a8 + 0x40) = 8;
      break;
    case 0xc:
      *(undefined4 *)(lStack_a8 + 0x40) = 7;
      break;
    case 0xd:
      *(undefined4 *)(lStack_a8 + 0x40) = 6;
      break;
    case 0xe:
      *(undefined4 *)(lStack_a8 + 0x40) = 5;
      break;
    case 0xf:
      *(undefined4 *)(lStack_a8 + 0x40) = 4;
    }
    break;
  case 4:
    iStack_9c = CONCAT31(iStack_9c._1_3_,iStack_9c != 0);
    uStack_80 = 0xffffffff;
    (**(code **)(*(longlong *)(lStack_a8 + 0x1000dc8) + 0x40))(lStack_a8 + 0x1000dc8,3);
    *(undefined1 *)(lStack_a8 + 0x1001298) = (undefined1)iStack_9c;
    *(undefined1 *)(lStack_a8 + 0x1087448) = (undefined1)iStack_9c;
    break;
  case 5:
    uStack_80 = 0xffffffff;
    FUN_00489550(*(undefined8 *)(lStack_a8 + 0x1097548),iStack_9c != 0);
    break;
  case 6:
    puStack_98 = auStack_18;
    uStack_80 = 0xffffffff;
    FUN_0093cad0(puStack_98,"XBUS/CD-Drive");
    uStack_80 = 1;
    lVar3 = FUN_00420030(lStack_a8 + 0x1000dc8,puStack_98);
    if (lVar3 == 0) {
      lStack_20 = 0;
    }
    else {
      lStack_20 = __dynamic_cast(lVar3,&PTR_PTR_vtable_00be2a10,&PTR_PTR_vtable_00be2640,0);
    }
    FUN_0093b400(puStack_98);
    switch(iStack_9c) {
    default:
      *(undefined4 *)(lStack_20 + 0x2fc) = 0x14585;
      break;
    case 1:
      *(undefined4 *)(lStack_20 + 0x2fc) = 0x28b0a;
      break;
    case 3:
      *(undefined4 *)(lStack_20 + 0x2fc) = 0xa2c2;
      break;
    case 4:
      *(undefined4 *)(lStack_20 + 0x2fc) = 0x5161;
      break;
    case 5:
      *(undefined4 *)(lStack_20 + 0x2fc) = 0x28b0;
      break;
    case 6:
      *(undefined4 *)(lStack_20 + 0x2fc) = 0x1458;
      break;
    case 7:
      *(undefined4 *)(lStack_20 + 0x2fc) = 0xa2c;
      break;
    case 8:
      *(undefined4 *)(lStack_20 + 0x2fc) = 0;
    }
    break;
  case 7:
    switch(iStack_9c) {
    case 0:
      lVar3 = *(longlong *)(lStack_a8 + 0x1097548);
      *(undefined4 *)(lVar3 + 0x10000e4) = 0;
      *(undefined4 *)(lVar3 + 0x10000e8) = 1;
      break;
    case 1:
      lVar3 = *(longlong *)(lStack_a8 + 0x1097548);
      *(undefined4 *)(lVar3 + 0x10000e4) = 1;
      *(undefined4 *)(lVar3 + 0x10000e8) = 1;
      break;
    case 2:
      lVar3 = *(longlong *)(lStack_a8 + 0x1097548);
      *(undefined4 *)(lVar3 + 0x10000e4) = 0;
      *(undefined4 *)(lVar3 + 0x10000e8) = 2;
      break;
    case 3:
      lVar3 = *(longlong *)(lStack_a8 + 0x1097548);
      *(undefined4 *)(lVar3 + 0x10000e4) = 0;
      *(undefined4 *)(lVar3 + 0x10000e8) = 4;
      break;
    case 4:
      lVar3 = *(longlong *)(lStack_a8 + 0x1097548);
      *(undefined4 *)(lVar3 + 0x10000e4) = 0;
      *(undefined4 *)(lVar3 + 0x10000e8) = 8;
      break;
    default:
      lVar3 = *(longlong *)(lStack_a8 + 0x1097548);
      *(undefined4 *)(lVar3 + 0x10000e4) = 0;
      *(undefined4 *)(lVar3 + 0x10000e8) = 0;
    }
    break;
  case 8:
    uStack_80 = 0xffffffff;
    FUN_004895d0(*(undefined8 *)(lStack_a8 + 0x1097548),iStack_9c != 0);
  }
  lVar3 = *(longlong *)(lStack_a8 + 0x1097550);
  iVar2 = *(int *)(lVar3 + 0x38);
  iVar1 = *(int *)(lVar3 + 0x3c);
  if (*(char *)(lVar3 + 0x8c) != '\0') {
    iVar2 = iVar2 * 2;
    iVar1 = iVar1 * 2;
  }
  *(int *)(lStack_a8 + 0x1000dc0) = iVar1;
  *(int *)(lStack_a8 + 0x1000dc4) = iVar2;
  _Unwind_SjLj_Unregister(puStack_90);
  return;
}


