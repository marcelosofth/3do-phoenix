// FUN_004a10d0 @ 004a10d0 size=609
// callers: 004a7f60 004a34e0 
// callees: 004a0ee0:FUN_004a0ee0 008ce550:_Unwind_SjLj_Unregister 0093cad0:FUN_0093cad0 00a61ff0:FUN_00a61ff0 0093b400:FUN_0093b400 008ce548:_Unwind_SjLj_Register 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_004a10d0(undefined8 param_1)

{
  int iVar1;
  longlong lVar2;
  longlong lVar3;
  undefined1 uVar4;
  undefined4 uVar5;
  ulonglong uVar6;
  undefined1 auStack_f8 [40];
  undefined1 *puStack_d0;
  int **ppiStack_c8;
  int **ppiStack_c0;
  undefined1 *puStack_b8;
  ulonglong uStack_b0;
  undefined1 auStack_a8 [8];
  undefined4 uStack_a0;
  undefined *puStack_78;
  undefined *puStack_70;
  undefined1 *puStack_68;
  undefined *puStack_60;
  undefined1 *puStack_58;
  code *pcStack_40;
  undefined1 auStack_38 [16];
  int *apiStack_28 [2];
  int *apiStack_18 [2];
  
  puStack_68 = &stack0xfffffffffffffff8;
  puStack_58 = auStack_f8;
  puStack_78 = &DAT_008ce270;
  puStack_70 = &DAT_00cc1e08;
  puStack_60 = &DAT_004a1335;
  puStack_b8 = auStack_a8;
  uStack_b0 = param_1;
  _Unwind_SjLj_Register(puStack_b8);
  ppiStack_c8 = apiStack_18;
  uStack_a0 = 0xffffffff;
  FUN_0093cad0(ppiStack_c8,"a48e6746bd7edec0f40cff078f0bb19f");
  pcStack_40 = *(code **)(*_DAT_00cf4050 + 0x128);
  uStack_a0 = 1;
  puStack_d0 = auStack_38;
  FUN_0093cad0(puStack_d0,&DAT_00b03a23);
  uStack_a0 = 2;
  uVar5 = FUN_004a0ee0(uStack_b0,puStack_d0);
  ppiStack_c0 = apiStack_28;
  (*pcStack_40)(ppiStack_c0,_DAT_00cf4050,uVar5);
  iVar1 = *apiStack_28[0];
  if (iVar1 == *apiStack_18[0]) {
    if ((iVar1 == 0) || (iVar1 < 1)) {
LAB_004a130d:
      FUN_0093b400(ppiStack_c0);
      FUN_0093b400(puStack_d0);
      FUN_0093b400(ppiStack_c8);
      uStack_b0 = CONCAT71(uStack_b0._1_7_,1);
      goto LAB_004a12b4;
    }
    if ((char)apiStack_28[0][3] == (char)apiStack_18[0][3]) {
      uVar6 = 0;
      do {
        if (uVar6 == iVar1 - 1) goto LAB_004a130d;
        lVar3 = uVar6 + 0xd;
        lVar2 = uVar6 + 0xd;
        uVar6 = uVar6 + 1;
      } while (*(char *)((longlong)apiStack_28[0] + lVar3) ==
               *(char *)((longlong)apiStack_18[0] + lVar2));
    }
  }
  FUN_0093b400(ppiStack_c0);
  FUN_0093b400(puStack_d0);
  FUN_0093b400(ppiStack_c8);
  uStack_a0 = 0xffffffff;
  FUN_0093cad0(ppiStack_c8,"cf11bbb5a16d7af9875cca9de9a15e09");
  pcStack_40 = *(code **)(*_DAT_00cf4050 + 0x128);
  uStack_a0 = 3;
  FUN_0093cad0(puStack_d0,&DAT_00b03a23);
  uStack_a0 = 4;
  uVar5 = FUN_004a0ee0(uStack_b0,puStack_d0);
  (*pcStack_40)(ppiStack_c0,_DAT_00cf4050,uVar5);
  uVar4 = FUN_00a61ff0(ppiStack_c0,ppiStack_c8);
  uStack_b0 = CONCAT71(uStack_b0._1_7_,uVar4);
  FUN_0093b400(ppiStack_c0);
  FUN_0093b400(puStack_d0);
  FUN_0093b400(ppiStack_c8);
LAB_004a12b4:
  _Unwind_SjLj_Unregister(puStack_b8);
  return uStack_b0 & 0xff;
}


