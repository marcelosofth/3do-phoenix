// FUN_0049fd20 @ 0049fd20 size=66
// callers: 
// callees: 005559c0:FUN_005559c0 

void FUN_0049fd20(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  undefined8 uStack_28;
  undefined8 uStack_20;
  undefined8 uStack_18;
  undefined8 uStack_10;
  
  puVar1 = *(undefined8 **)(param_2 + 0x20);
  uStack_28 = *puVar1;
  uStack_20 = puVar1[1];
  uStack_18 = puVar1[2];
  uStack_10 = puVar1[3];
  FUN_005559c0(*(undefined8 *)(param_1 + 0x159f568),&uStack_28);
  return;
}


