// FUN_0049fea0 @ 0049fea0 size=295
// callers: 
// callees: 0058e9f0:FUN_0058e9f0 004714d0:FUN_004714d0 0048f170:FUN_0048f170 0048b2a0:FUN_0048b2a0 

ulonglong FUN_0049fea0(longlong param_1,ulonglong param_2)

{
  uint uVar1;
  ulonglong uVar2;
  uint uVar3;
  
  uVar3 = (uint)param_2;
  uVar1 = (uint)(param_2 >> 0x14) & 0xfff;
  if (uVar1 == 0x31) {
    uVar2 = 0xbadacce5;
    if ((uVar3 & 0xc0000) == 0x40000) {
      uVar2 = (ulonglong)*(byte *)(param_1 + 0x159755c + (ulonglong)(uVar3 >> 2 & 0x7fff));
    }
  }
  else if (uVar1 < 0x32) {
    if (uVar1 == 2) {
      if (*(char *)(param_1 + 0x3c) == '\0') {
        FUN_0058e9f0();
      }
    }
    else if (1 < uVar1) {
      if (uVar1 != 0x30) {
        return 0xbadacce5;
      }
      if ((*(byte *)(param_1 + 0x10874d8) & 4) != 0) {
        return (ulonglong)
               *(uint *)(param_1 + 0x1097558 + (ulonglong)((uVar3 & 0xfffff) + 0x100000 >> 2) * 4);
      }
      goto LAB_0049fedb;
    }
    uVar2 = (ulonglong)*(uint *)(param_1 + 0x129755c + (ulonglong)(uVar3 >> 2) * 4);
  }
  else {
    if (uVar1 == 0x33) {
      uVar2 = FUN_0048b2a0(param_1 + 0x1d8);
      return uVar2;
    }
    if (0x32 < uVar1) {
      if (uVar1 == 0x34) {
        uVar2 = FUN_0048f170(param_1 + 0x1000dc8);
        return uVar2;
      }
      if (uVar1 != 0x60) {
        return 0xbadacce5;
      }
LAB_0049fedb:
      return (ulonglong)*(uint *)(param_1 + 0x1097558 + (param_2 & 0xffffc));
    }
    uVar2 = 0xbadacce5;
    if (((uVar3 ^ 0x3200000) & 0xffffe000) == 0) {
      uVar2 = FUN_004714d0(param_1 + 0x10974f0,uVar3 & 0x1ffc);
      return uVar2;
    }
  }
  return uVar2;
}


