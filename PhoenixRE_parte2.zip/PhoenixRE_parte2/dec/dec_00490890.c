// FUN_00490890 @ 00490890 size=2051
// callers: 004a0920 
// callees: 00474410:FUN_00474410 0048f690:FUN_0048f690 008ce290:operator.new[] 008ce278:operator.delete[] 0048ef80:FUN_0048ef80 0046d570:FUN_0046d570 008ce288:operator.new 0048f540:FUN_0048f540 004788b0:FUN_004788b0 008de420:FUN_008de420 008ce280:operator.delete 004aa150:FUN_004aa150 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490890(longlong param_1,int param_2)

{
  longlong lVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  code *pcVar7;
  uint *puVar8;
  void *pvVar9;
  longlong *plVar10;
  ulonglong uVar11;
  uint uVar12;
  int iVar13;
  int *piVar14;
  undefined4 uStack_5c;
  int iStack_58;
  int iStack_54;
  int iStack_50;
  int iStack_4c;
  
  uVar3 = param_2 + *(int *)(param_1 + 0x270);
  *(uint *)(param_1 + 0x270) = uVar3;
  uVar12 = *(uint *)(param_1 + 0x34c) << 4;
  if (uVar12 < uVar3) {
    *(uint *)(param_1 + 0x270) = uVar12;
  }
  iVar6 = *(int *)(param_1 + 0x284);
  if (iVar6 != 0) {
    if (*(int *)(param_1 + 0x33c) < *(int *)(param_1 + 0x340)) {
      iVar13 = (*(int *)(param_1 + 0x338) - *(int *)(param_1 + 0x340)) + *(int *)(param_1 + 0x33c);
    }
    else {
      iVar13 = *(int *)(param_1 + 0x33c) - *(int *)(param_1 + 0x340);
    }
    if ((iVar13 == 0) && (*(uint *)(param_1 + 0x34c) <= *(uint *)(param_1 + 0x270))) {
      if (iVar6 < 0) {
        *(byte *)(param_1 + 0x277) = *(byte *)(param_1 + 0x277) | 0x10;
        *(int *)(param_1 + 0x284) = -iVar6;
        FUN_004aa150(param_1 + 0x50);
      }
      cVar2 = (**(code **)(*_DAT_00cf4050 + 0x130))
                        (_DAT_00cf4050,*(undefined4 *)(param_1 + 0x348),
                         *(undefined4 *)(param_1 + 0x280));
      if (cVar2 != '\0') {
        *(int *)(param_1 + 0x280) = *(int *)(param_1 + 0x280) + 1;
        (**(code **)(*_DAT_00cf4050 + 0xe0))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x78),0x800);
        uVar5 = (**(code **)(*_DAT_00cf4050 + 0x138))
                          (_DAT_00cf4050,*(undefined4 *)(param_1 + 0x348),
                           *(undefined8 *)(param_1 + 0x330));
        *(undefined4 *)(param_1 + 0x340) = 0;
        *(undefined4 *)(param_1 + 0x33c) = uVar5;
        if (*(int *)(param_1 + 0x33c) < *(int *)(param_1 + 0x340)) {
          iVar6 = (*(int *)(param_1 + 0x338) - *(int *)(param_1 + 0x340)) +
                  *(int *)(param_1 + 0x33c);
        }
        else {
          iVar6 = *(int *)(param_1 + 0x33c) - *(int *)(param_1 + 0x340);
        }
        if (iVar6 == 0) {
          *(byte *)(param_1 + 0x277) = *(byte *)(param_1 + 0x277) & 0xdf;
        }
        else if ((*(byte *)(param_1 + 0x277) & 0x20) == 0) {
          *(byte *)(param_1 + 0x277) = *(byte *)(param_1 + 0x277) | 0x20;
          FUN_004aa150(param_1 + 0x50);
        }
      }
      *(int *)(param_1 + 0x284) = *(int *)(param_1 + 0x284) + -1;
      *(int *)(param_1 + 0x270) = *(int *)(param_1 + 0x270) - *(int *)(param_1 + 0x34c);
    }
  }
  FUN_0048f690(param_1);
  uVar3 = param_2 * 9 + *(int *)(param_1 + 0x96690);
  *(uint *)(param_1 + 0x96690) = uVar3;
  plVar10 = _DAT_00cf4050;
  while (_DAT_00cf4050 = plVar10, 0x9f6 < uVar3) {
    *(uint *)(param_1 + 0x96690) = uVar3 - 0x9f7;
    (**(code **)(*plVar10 + 0xd0))(plVar10,*(undefined4 *)(param_1 + 0x86670));
    uStack_5c = FUN_0046d570(param_1 + 0x4a8);
    if (*(char *)(param_1 + 0x86680) != '\0') {
LAB_00490a4a:
      iStack_50 = *(int *)(param_1 + 0x96714);
      iStack_4c = *(int *)(param_1 + 0x96718);
      if (iStack_50 < iStack_4c) {
        if ((*(int *)(param_1 + 0x96710) - iStack_4c) + iStack_50 == 0) goto LAB_00490a80;
      }
      else if (iStack_50 == iStack_4c) goto LAB_00490a80;
      piVar14 = (int *)(*(longlong *)(param_1 + 0x96708) + (longlong)*(int *)(param_1 + 0x96718) * 8
                       );
      iVar6 = *piVar14;
      iVar13 = piVar14[1];
      iStack_58 = *(int *)(param_1 + 0x96714);
      iStack_54 = *(int *)(param_1 + 0x96718);
      if (iStack_58 < iStack_54) {
        iVar4 = *(int *)(param_1 + 0x96710) - iStack_54;
      }
      else {
        iVar4 = -iStack_54;
      }
      if (iVar4 + iStack_58 != 0) {
        *(int *)(param_1 + 0x96718) =
             (*(int *)(param_1 + 0x96718) + 1) % *(int *)(param_1 + 0x96710);
      }
      if (*(longlong *)(param_1 + 0x966d0) != 0) {
        pcVar7 = *(code **)(param_1 + 0x966d8);
        plVar10 = (longlong *)(*(longlong *)(param_1 + 0x966d0) + *(longlong *)(param_1 + 0x966e0));
        if (((ulonglong)pcVar7 & 1) != 0) {
          pcVar7 = *(code **)(pcVar7 + *plVar10 + -1);
        }
        (*pcVar7)(plVar10,iVar6,(iVar13 + 2) - iVar6);
      }
      goto LAB_00490a4a;
    }
    while ((puVar8 = *(uint **)(param_1 + 0x96720), puVar8 != (uint *)0x0 &&
           (uVar3 = *puVar8, uVar3 != 0))) {
      if (1 < (int)puVar8[2]) {
        uVar12 = uVar3 + 1 + (uVar3 >> 1);
        if (uVar12 < 0x20) {
          puVar8 = operator_new(0x18);
          uVar12 = 0x20;
          uVar11 = 0x80;
        }
        else {
          puVar8 = operator_new(0x18);
          uVar11 = 0xffffffffffffffff;
          if ((ulonglong)(longlong)(int)uVar12 < 0x1fc0000000000001) {
            uVar11 = (longlong)(int)uVar12 * 4;
          }
        }
        pvVar9 = operator_new__(uVar11);
        puVar8[1] = uVar12;
        *(void **)(puVar8 + 4) = pvVar9;
        puVar8[2] = 1;
        *puVar8 = uVar3;
        piVar14 = *(int **)(param_1 + 0x96720);
        if (*piVar14 == 0) {
LAB_00490de3:
          piVar14[2] = piVar14[2] + -1;
          pvVar9 = *(void **)(param_1 + 0x96720);
          if (*(int *)((longlong)pvVar9 + 8) == 0) {
            if (*(void **)((longlong)pvVar9 + 0x10) != (void *)0x0) {
              operator_delete__(*(void **)((longlong)pvVar9 + 0x10));
              pvVar9 = *(void **)(param_1 + 0x96720);
            }
            operator_delete(pvVar9);
          }
        }
        else {
          FUN_008de420(pvVar9,*(undefined8 *)(piVar14 + 4));
          piVar14 = *(int **)(param_1 + 0x96720);
          if (piVar14 != (int *)0x0) goto LAB_00490de3;
        }
        *(uint **)(param_1 + 0x96720) = puVar8;
        uVar3 = *puVar8;
      }
      *puVar8 = uVar3 - 1;
      puVar8 = *(uint **)(param_1 + 0x96720);
      uVar3 = *puVar8;
      iVar13 = *(int *)(*(longlong *)(puVar8 + 4) + (longlong)(int)uVar3 * 4);
      iVar6 = 0;
      if (uVar3 != 0) {
        if (1 < (int)puVar8[2]) {
          uVar12 = uVar3 + 1 + (uVar3 >> 1);
          if (uVar12 < 0x20) {
            puVar8 = operator_new(0x18);
            uVar12 = 0x20;
            uVar11 = 0x80;
          }
          else {
            puVar8 = operator_new(0x18);
            uVar11 = 0xffffffffffffffff;
            if ((ulonglong)(longlong)(int)uVar12 < 0x1fc0000000000001) {
              uVar11 = (longlong)(int)uVar12 * 4;
            }
          }
          pvVar9 = operator_new__(uVar11);
          puVar8[1] = uVar12;
          *(void **)(puVar8 + 4) = pvVar9;
          puVar8[2] = 1;
          *puVar8 = uVar3;
          piVar14 = *(int **)(param_1 + 0x96720);
          if (*piVar14 == 0) {
LAB_00490cd3:
            piVar14[2] = piVar14[2] + -1;
            pvVar9 = *(void **)(param_1 + 0x96720);
            if (*(int *)((longlong)pvVar9 + 8) == 0) {
              if (*(void **)((longlong)pvVar9 + 0x10) != (void *)0x0) {
                operator_delete__(*(void **)((longlong)pvVar9 + 0x10));
                pvVar9 = *(void **)(param_1 + 0x96720);
              }
              operator_delete(pvVar9);
            }
          }
          else {
            FUN_008de420(pvVar9,*(undefined8 *)(piVar14 + 4));
            piVar14 = *(int **)(param_1 + 0x96720);
            if (piVar14 != (int *)0x0) goto LAB_00490cd3;
          }
          *(uint **)(param_1 + 0x96720) = puVar8;
          uVar3 = *puVar8;
        }
        *puVar8 = uVar3 - 1;
        iVar6 = *(int *)(*(longlong *)(*(int **)(param_1 + 0x96720) + 4) +
                        (longlong)**(int **)(param_1 + 0x96720) * 4);
      }
      if (*(longlong *)(param_1 + 0x966d0) != 0) {
        pcVar7 = *(code **)(param_1 + 0x966d8);
        plVar10 = (longlong *)(*(longlong *)(param_1 + 0x966d0) + *(longlong *)(param_1 + 0x966e0));
        if (((ulonglong)pcVar7 & 1) != 0) {
          pcVar7 = *(code **)(pcVar7 + *plVar10 + -1);
        }
        (*pcVar7)(plVar10,iVar6,(iVar13 + 2) - iVar6);
      }
    }
LAB_00490a80:
    (**(code **)(*_DAT_00cf4050 + 0xd8))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x86670));
    (**(code **)(*_DAT_00cf4050 + 0xa8))(_DAT_00cf4050,&uStack_5c,4);
    plVar10 = _DAT_00cf4050;
    uVar3 = *(uint *)(param_1 + 0x96690);
  }
  iVar6 = *(int *)(param_1 + 0x868ac);
  uVar3 = *(int *)(param_1 + 0x9668c) + param_2 * 2;
  *(uint *)(param_1 + 0x9668c) = uVar3;
  if (iVar6 + 0x40U <= uVar3) {
    do {
      *(uint *)(param_1 + 0x9668c) = uVar3 + (-0x40 - iVar6);
      FUN_0048f540(param_1);
      iVar6 = *(int *)(param_1 + 0x868ac);
      uVar3 = *(uint *)(param_1 + 0x9668c);
    } while (iVar6 + 0x40U <= uVar3);
  }
  lVar1 = param_1 + 0x122d0;
  uVar3 = param_2 * 7 + *(int *)(param_1 + 0x96694);
  *(uint *)(param_1 + 0x96694) = uVar3;
  do {
    if (uVar3 < 0x15d8) {
      return;
    }
    if (*(char *)(param_1 + 0x86678) == '\0') {
      uVar12 = *(uint *)(param_1 + 0x866c0);
      *(uint *)(param_1 + 0x96694) = uVar3 - 0x15a8;
      if ((uVar12 & 0x7ff) < 0x106) goto LAB_00490c15;
LAB_00490b59:
      *(uint *)(param_1 + 0x866c0) = ~uVar12 & 0x800;
      cVar2 = FUN_00474410(lVar1);
    }
    else {
      uVar12 = *(uint *)(param_1 + 0x866c0);
      *(uint *)(param_1 + 0x96694) = uVar3 - 0x15d7;
      if (0x137 < (uVar12 & 0x7ff)) goto LAB_00490b59;
LAB_00490c15:
      *(uint *)(param_1 + 0x866c0) = uVar12 + 1;
      cVar2 = FUN_00474410(lVar1);
    }
    if (cVar2 != '\0') {
      (**(code **)(*_DAT_00cf4050 + 0xd0))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x86674));
      FUN_004788b0(lVar1,0);
      (**(code **)(*_DAT_00cf4050 + 0xd8))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x86674));
    }
    uVar3 = *(uint *)(param_1 + 0x866c0) & 0x7ff;
    if ((uVar3 == 0x18) && (*(longlong *)(param_1 + 0x966e8) != 0)) {
      pcVar7 = *(code **)(param_1 + 0x966f0);
      if (((ulonglong)pcVar7 & 1) != 0) {
        pcVar7 = *(code **)(pcVar7 + *(longlong *)
                                      (*(longlong *)(param_1 + 0x966e8) +
                                      *(longlong *)(param_1 + 0x966f8)) + -1);
      }
      (*pcVar7)();
    }
    *(int *)(param_1 + 0x866c8) = *(int *)(param_1 + 0x866c8) * 0x41c64e6d + 0x3039;
    if (uVar3 == (*(uint *)(param_1 + 0x86694) & 0x7ff)) {
      FUN_0048ef80(param_1,1,0);
      uVar12 = *(uint *)(param_1 + 0x86698);
    }
    else {
      uVar12 = *(uint *)(param_1 + 0x86698);
    }
    if (uVar3 == (uVar12 & 0x7ff)) {
      FUN_0048ef80(param_1,2,0);
    }
    uVar3 = *(uint *)(param_1 + 0x96694);
  } while( true );
}


