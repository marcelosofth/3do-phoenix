// FUN_004a1d80 @ 004a1d80 size=658
// callers: 
// callees: 00593de0:FUN_00593de0 0093b400:FUN_0093b400 004a0d20:FUN_004a0d20 0093cad0:FUN_0093cad0 004a19a0:FUN_004a19a0 00593e70:FUN_00593e70 008ce550:_Unwind_SjLj_Unregister 00594330:FUN_00594330 008ce548:_Unwind_SjLj_Register 

undefined8 FUN_004a1d80(undefined8 param_1,longlong param_2,undefined4 param_3)

{
  int iVar1;
  undefined1 auStack_108 [32];
  undefined1 *puStack_e8;
  undefined1 *puStack_e0;
  undefined1 *puStack_d8;
  undefined8 uStack_d0;
  longlong lStack_c8;
  longlong lStack_c0;
  undefined1 auStack_b8 [8];
  undefined4 uStack_b0;
  undefined *puStack_88;
  undefined *puStack_80;
  undefined1 *puStack_78;
  undefined1 *puStack_70;
  undefined1 *puStack_68;
  undefined1 *puStack_50;
  undefined1 auStack_48 [16];
  undefined1 auStack_38 [16];
  undefined1 auStack_28 [16];
  undefined1 auStack_18 [16];
  
  puStack_78 = &stack0xfffffffffffffff8;
  puStack_68 = auStack_108;
  puStack_50 = auStack_b8;
  puStack_88 = &DAT_008ce270;
  puStack_e8 = (undefined1 *)CONCAT44(puStack_e8._4_4_,param_3);
  puStack_80 = &DAT_00cc1e5c;
  puStack_70 = &LAB_004a201b;
  uStack_d0 = param_1;
  lStack_c0 = param_2;
  _Unwind_SjLj_Register(puStack_50);
  uStack_b0 = 0xffffffff;
  FUN_0093cad0(uStack_d0,"<UndefTask>");
  iVar1 = *(int *)(lStack_c0 + 0x159f55c);
  if ((0 < iVar1) && ((longlong)iVar1 + 0x118U < 0x300000)) {
    if ((int)puStack_e8 == 0) {
      iVar1 = *(int *)(lStack_c0 + iVar1 + 0x12975f4);
    }
    else {
      iVar1 = FUN_004a0d20(lStack_c0,(ulonglong)puStack_e8 & 0xffffffff);
    }
    if (((iVar1 != 0) && (0 < iVar1)) && ((longlong)iVar1 + 0xdcU < 0x300000)) {
      puStack_e0 = (undefined1 *)(lStack_c0 + 0x129755c + (longlong)iVar1);
      puStack_e8 = auStack_48;
      uStack_b0 = 1;
      FUN_004a19a0(puStack_e8,lStack_c0,*(undefined4 *)(puStack_e0 + 0x10));
      uStack_b0 = 2;
      FUN_00593de0(uStack_d0,puStack_e8);
      FUN_0093b400(puStack_e8);
      iVar1 = *(int *)(puStack_e0 + 0x24);
      if (((iVar1 != 0) && (0 < iVar1)) && ((longlong)iVar1 + 0xdcU < 0x300000)) {
        puStack_d8 = auStack_38;
        puStack_e8 = auStack_28;
        puStack_e0 = auStack_18;
        do {
          lStack_c8 = lStack_c0 + 0x129755c + (longlong)iVar1;
          uStack_b0 = 1;
          FUN_004a19a0(puStack_d8,lStack_c0,*(undefined4 *)(lStack_c8 + 0x10));
          uStack_b0 = 3;
          FUN_00594330(puStack_e8,puStack_d8,&DAT_00b03b38);
          uStack_b0 = 4;
          FUN_00593e70(puStack_e0,puStack_e8,uStack_d0);
          uStack_b0 = 5;
          FUN_00593de0(uStack_d0,puStack_e0);
          FUN_0093b400(puStack_e0);
          FUN_0093b400(puStack_e8);
          FUN_0093b400(puStack_d8);
          iVar1 = *(int *)(lStack_c8 + 0x24);
          if ((iVar1 == 0) || (iVar1 < 1)) break;
        } while ((longlong)iVar1 + 0xdcU < 0x300000);
      }
    }
  }
  _Unwind_SjLj_Unregister(puStack_50);
  return uStack_d0;
}


