// FUN_0049fd70 @ 0049fd70 size=39
// callers: 
// callees: 0058ec10:FUN_0058ec10 

longlong * FUN_0049fd70(longlong *param_1)

{
  (**(code **)(*param_1 + 0x40))(param_1,3);
  FUN_0058ec10(param_1,0);
  return param_1 + 4;
}


