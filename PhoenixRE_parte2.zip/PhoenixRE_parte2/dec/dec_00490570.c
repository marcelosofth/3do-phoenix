// FUN_00490570 @ 00490570 size=778
// callers: 
// callees: 0045f730:FUN_0045f730 008ce278:operator.delete[] 008ce288:operator.new 008de420:FUN_008de420 008ce290:operator.new[] 008ce280:operator.delete 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00490570(longlong param_1,int param_2)

{
  int iVar1;
  longlong *plVar2;
  uint *puVar3;
  void *pvVar4;
  ulonglong uVar5;
  int iVar6;
  int *piVar7;
  uint uVar8;
  code *pcVar9;
  uint uVar10;
  
  (**(code **)(*_DAT_00cf4050 + 0xd0))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x86670));
  param_2 = param_2 + *(int *)(param_1 + 0x86688);
  if (0 < param_2) {
    do {
      iVar1 = FUN_0045f730(param_1 + 0x4a8);
      param_2 = param_2 - iVar1;
      while ((puVar3 = *(uint **)(param_1 + 0x96720), puVar3 != (uint *)0x0 &&
             (uVar8 = *puVar3, uVar8 != 0))) {
        if (1 < (int)puVar3[2]) {
          uVar10 = uVar8 + 1 + (uVar8 >> 1);
          if (uVar10 < 0x20) {
            uVar10 = 0x20;
            puVar3 = operator_new(0x18);
            uVar5 = 0x80;
          }
          else {
            puVar3 = operator_new(0x18);
            uVar5 = 0xffffffffffffffff;
            if ((ulonglong)(longlong)(int)uVar10 < 0x1fc0000000000001) {
              uVar5 = (longlong)(int)uVar10 * 4;
            }
          }
          pvVar4 = operator_new__(uVar5);
          puVar3[1] = uVar10;
          *(void **)(puVar3 + 4) = pvVar4;
          puVar3[2] = 1;
          *puVar3 = uVar8;
          piVar7 = *(int **)(param_1 + 0x96720);
          if (*piVar7 == 0) {
LAB_00490689:
            piVar7[2] = piVar7[2] + -1;
            pvVar4 = *(void **)(param_1 + 0x96720);
            if (*(int *)((longlong)pvVar4 + 8) == 0) {
              if (*(void **)((longlong)pvVar4 + 0x10) != (void *)0x0) {
                operator_delete__(*(void **)((longlong)pvVar4 + 0x10));
                pvVar4 = *(void **)(param_1 + 0x96720);
              }
              operator_delete(pvVar4);
            }
          }
          else {
            FUN_008de420(pvVar4,*(undefined8 *)(piVar7 + 4));
            piVar7 = *(int **)(param_1 + 0x96720);
            if (piVar7 != (int *)0x0) goto LAB_00490689;
          }
          *(uint **)(param_1 + 0x96720) = puVar3;
          uVar8 = *puVar3;
        }
        *puVar3 = uVar8 - 1;
        puVar3 = *(uint **)(param_1 + 0x96720);
        uVar8 = *puVar3;
        iVar1 = *(int *)(*(longlong *)(puVar3 + 4) + (longlong)(int)uVar8 * 4);
        iVar6 = 0;
        if (uVar8 != 0) {
          if (1 < (int)puVar3[2]) {
            uVar10 = uVar8 + 1 + (uVar8 >> 1);
            if (uVar10 < 0x20) {
              uVar10 = 0x20;
              puVar3 = operator_new(0x18);
              uVar5 = 0x80;
            }
            else {
              puVar3 = operator_new(0x18);
              uVar5 = 0xffffffffffffffff;
              if ((ulonglong)(longlong)(int)uVar10 < 0x1fc0000000000001) {
                uVar5 = (longlong)(int)uVar10 * 4;
              }
            }
            pvVar4 = operator_new__(uVar5);
            puVar3[1] = uVar10;
            *(void **)(puVar3 + 4) = pvVar4;
            puVar3[2] = 1;
            *puVar3 = uVar8;
            piVar7 = *(int **)(param_1 + 0x96720);
            if (*piVar7 == 0) {
LAB_00490757:
              piVar7[2] = piVar7[2] + -1;
              pvVar4 = *(void **)(param_1 + 0x96720);
              if (*(int *)((longlong)pvVar4 + 8) == 0) {
                if (*(void **)((longlong)pvVar4 + 0x10) != (void *)0x0) {
                  operator_delete__(*(void **)((longlong)pvVar4 + 0x10));
                  pvVar4 = *(void **)(param_1 + 0x96720);
                }
                operator_delete(pvVar4);
              }
            }
            else {
              FUN_008de420(pvVar4,*(undefined8 *)(piVar7 + 4));
              piVar7 = *(int **)(param_1 + 0x96720);
              if (piVar7 != (int *)0x0) goto LAB_00490757;
            }
            *(uint **)(param_1 + 0x96720) = puVar3;
            uVar8 = *puVar3;
          }
          *puVar3 = uVar8 - 1;
          iVar6 = *(int *)(*(longlong *)(*(int **)(param_1 + 0x96720) + 4) +
                          (longlong)**(int **)(param_1 + 0x96720) * 4);
        }
        if (*(longlong *)(param_1 + 0x966d0) != 0) {
          pcVar9 = *(code **)(param_1 + 0x966d8);
          plVar2 = (longlong *)(*(longlong *)(param_1 + 0x966d0) + *(longlong *)(param_1 + 0x966e0))
          ;
          if (((ulonglong)pcVar9 & 1) != 0) {
            pcVar9 = *(code **)(pcVar9 + *plVar2 + -1);
          }
          (*pcVar9)(plVar2,iVar6,(iVar1 + 2) - iVar6);
        }
      }
    } while (0 < param_2);
  }
  plVar2 = _DAT_00cf4050;
  *(int *)(param_1 + 0x86688) = param_2;
                    /* WARNING: Could not recover jumptable at 0x00490825. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + 0xd8))(plVar2,*(undefined4 *)(param_1 + 0x86670));
  return;
}


