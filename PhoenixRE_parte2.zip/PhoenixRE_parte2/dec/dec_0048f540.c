// FUN_0048f540 @ 0048f540 size=297
// callers: 00490890 
// callees: 0048ef80:FUN_0048ef80 

void FUN_0048f540(longlong param_1)

{
  longlong lVar1;
  uint *puVar2;
  int iVar3;
  byte bVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  bool bVar9;
  
  uVar6 = 0x100;
  bVar9 = true;
  uVar5 = 0;
  do {
    bVar4 = (char)uVar5 * '\x04' & 0x1c;
    uVar7 = *(uint *)(param_1 + 0x8668c +
                     (longlong)(int)((-(uint)(uVar5 < 8) & 0xfffffffe) + 0x82) * 4) >> bVar4;
    if ((((uVar7 & 4) == 0) || (bVar9)) && (bVar9 = false, (uVar7 & 1) != 0)) {
      lVar1 = param_1 + (ulonglong)(uVar6 >> 2) * 4;
      iVar3 = *(int *)(lVar1 + 0x8668c);
      uVar8 = iVar3 - 1;
      bVar9 = (short)iVar3 == 0;
      if (bVar9) {
        if ((uVar5 & 1) != 0) {
          FUN_0048ef80(param_1,1 << (10U - (char)(uVar5 >> 1) & 0x1f),0);
        }
        if ((uVar7 & 2) == 0) {
          puVar2 = (uint *)(param_1 + 0x8668c +
                           (longlong)(int)((-(uint)(uVar5 < 8) & 0xfffffffe) + 0x82) * 4);
          *puVar2 = *puVar2 & ~(1 << bVar4);
        }
        else {
          uVar8 = (uint)*(ushort *)(param_1 + 0x8668c + (ulonglong)(uVar6 + 4 >> 2) * 4);
        }
      }
      *(uint *)(lVar1 + 0x8668c) = uVar8 & 0xffff;
    }
    uVar6 = uVar6 + 8;
    uVar5 = uVar5 + 1;
  } while (uVar5 != 0x10);
  return;
}


