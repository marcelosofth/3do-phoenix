// FUN_004a0ee0 @ 004a0ee0 size=470
// callers: 004a10d0 004a9a40 004a7f60 004a34e0 
// callees: 0093cad0:FUN_0093cad0 00a61ff0:FUN_00a61ff0 0093b400:FUN_0093b400 

uint FUN_004a0ee0(undefined8 param_1,undefined8 *param_2)

{
  int iVar1;
  int *piVar2;
  longlong lVar3;
  longlong lVar4;
  char cVar5;
  uint uVar6;
  ulonglong uVar7;
  int *apiStack_28 [2];
  
  FUN_0093cad0(apiStack_28,"CD-ROM");
  piVar2 = (int *)*param_2;
  iVar1 = *piVar2;
  if (iVar1 == *apiStack_28[0]) {
    if ((iVar1 == 0) || (iVar1 < 1)) {
LAB_004a0fbe:
      FUN_0093b400(apiStack_28);
      return 0;
    }
    if ((char)piVar2[3] == (char)apiStack_28[0][3]) {
      uVar7 = 0;
      do {
        if (uVar7 == iVar1 - 1) goto LAB_004a0fbe;
        lVar4 = uVar7 + 0xd;
        lVar3 = uVar7 + 0xd;
        uVar7 = uVar7 + 1;
      } while (*(char *)((longlong)piVar2 + lVar4) == *(char *)((longlong)apiStack_28[0] + lVar3));
    }
  }
  FUN_0093b400(apiStack_28);
  FUN_0093cad0(apiStack_28,&DAT_00b03a23);
  piVar2 = (int *)*param_2;
  iVar1 = *piVar2;
  if (iVar1 == *apiStack_28[0]) {
    if ((iVar1 == 0) || (iVar1 < 1)) {
LAB_004a100e:
      FUN_0093b400(apiStack_28);
      return 1;
    }
    if ((char)piVar2[3] == (char)apiStack_28[0][3]) {
      uVar7 = 0;
      do {
        if (uVar7 == iVar1 - 1) goto LAB_004a100e;
        lVar4 = uVar7 + 0xd;
        lVar3 = uVar7 + 0xd;
        uVar7 = uVar7 + 1;
      } while (*(char *)((longlong)piVar2 + lVar4) == *(char *)((longlong)apiStack_28[0] + lVar3));
    }
  }
  FUN_0093b400(apiStack_28);
  FUN_0093cad0(apiStack_28,"FONT-ROM");
  cVar5 = FUN_00a61ff0(param_2,apiStack_28);
  FUN_0093b400(apiStack_28);
  uVar6 = 2;
  if (cVar5 == '\0') {
    FUN_0093cad0(apiStack_28,"FMV-ROM");
    piVar2 = (int *)*param_2;
    iVar1 = *piVar2;
    if (iVar1 == *apiStack_28[0]) {
      if ((iVar1 == 0) || (iVar1 < 1)) {
LAB_004a10b5:
        FUN_0093b400(apiStack_28);
        return 3;
      }
      if ((char)piVar2[3] == (char)apiStack_28[0][3]) {
        uVar7 = 0;
        do {
          if (uVar7 == iVar1 - 1) goto LAB_004a10b5;
          lVar4 = uVar7 + 0xd;
          lVar3 = uVar7 + 0xd;
          uVar7 = uVar7 + 1;
        } while (*(char *)((longlong)piVar2 + lVar4) == *(char *)((longlong)apiStack_28[0] + lVar3))
        ;
      }
    }
    FUN_0093b400(apiStack_28);
    FUN_0093cad0(apiStack_28,"NVRAM");
    cVar5 = FUN_00a61ff0(param_2,apiStack_28);
    FUN_0093b400(apiStack_28);
    uVar6 = -(uint)(cVar5 == '\0') | 4;
  }
  return uVar6;
}


