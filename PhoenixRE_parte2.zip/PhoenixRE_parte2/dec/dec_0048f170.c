// FUN_0048f170 @ 0048f170 size=909
// callers: 0049fea0 
// callees: 0047b7c0:FUN_0047b7c0 00498570:FUN_00498570 00498540:FUN_00498540 0045f8c0:FUN_0045f8c0 00498600:FUN_00498600 0047b8e0:FUN_0047b8e0 004985d0:FUN_004985d0 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_0048f170(longlong param_1,uint param_2)

{
  ushort uVar1;
  uint uVar2;
  int iVar3;
  ulonglong uVar4;
  
  param_2 = param_2 & 0xfffc;
  uVar2 = param_2 >> 0xc;
  if (uVar2 == 1) {
    if (0x17cf < param_2) {
      switch(param_2) {
      case 0x17d0:
        if (*(char *)(param_1 + 0x4d0) == '\0') {
          uVar2 = CONCAT22(*(undefined2 *)(param_1 + 0x12214),*(undefined2 *)(param_1 + 0x12216));
        }
        else {
          FUN_0047b7c0(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x4d4));
          uVar2 = CONCAT22(*(undefined2 *)(param_1 + 0x12214),*(undefined2 *)(param_1 + 0x12216));
          if (*(char *)(param_1 + 0x4d0) != '\0') {
            FUN_0047b8e0(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x4d4));
            return (ulonglong)uVar2;
          }
        }
        return (ulonglong)uVar2;
      case 0x17f0:
        uVar2 = *(int *)(param_1 + 0x12244) * 0x41c64e6d + 0x3039U & 0x7fffffff;
        *(uint *)(param_1 + 0x12244) = uVar2;
        return (ulonglong)(uVar2 >> 0x10);
      case 0x17f4:
        return (ulonglong)*(ushort *)(param_1 + 0x1223c);
      case 0x17f8:
        return (ulonglong)*(ushort *)(param_1 + 0x1226c);
      case 0x17fc:
        return (ulonglong)
               ((uint)(*(char *)(param_1 + 0x12260) == '\0') | *(uint *)(param_1 + 0x12264));
      }
    }
  }
  else if (uVar2 == 0) {
    switch(param_2 >> 8) {
    case 0:
      switch(param_2) {
      case 0:
        return 0x2022000;
      case 0x30:
        if (*(char *)(param_1 + 0x86678) == '\0') {
          uVar2 = (*(uint *)(param_1 + 0x96694) % 0x15a8) * 0x613;
          uVar4 = 0x15a8;
        }
        else {
          uVar2 = (*(uint *)(param_1 + 0x96694) % 0x15d7) * 0x620;
          uVar4 = 0x15d7;
        }
        return uVar2 / uVar4;
      case 0x40:
      case 0x44:
        return (ulonglong)*(uint *)(param_1 + 0x866cc);
      case 0x48:
      case 0x4c:
        return (ulonglong)(*(uint *)(param_1 + 0x866d4) | 0x80000000);
      case 0x50:
      case 0x54:
        return (ulonglong)*(uint *)(param_1 + 0x866dc);
      case 0x60:
      case 100:
        return (ulonglong)*(uint *)(param_1 + 0x866ec);
      case 0x68:
      case 0x6c:
        return (ulonglong)*(uint *)(param_1 + 0x866f4);
      }
      break;
    case 1:
      if (param_2 < 0x180) {
        return (ulonglong)*(ushort *)(param_1 + 0x8668c + (ulonglong)(param_2 >> 2) * 4);
      }
      break;
    case 2:
      if (param_2 == 0x204) {
LAB_0048f4a0:
        return (ulonglong)*(uint *)(param_1 + 0x8688c);
      }
      if (param_2 < 0x205) {
        if (param_2 == 0x200) goto LAB_0048f4a0;
      }
      else if ((param_2 == 0x208) || (param_2 == 0x20c)) {
        return (ulonglong)*(uint *)(param_1 + 0x86894);
      }
      break;
    case 3:
      if ((param_2 < 0x380) && ((param_2 == 0x304 || (param_2 == 0x308)))) {
        return (ulonglong)*(uint *)(param_1 + 0x86990);
      }
      break;
    case 4:
      if (param_2 != 0x404) {
        if (param_2 == 0x414) {
          return 0x4000;
        }
        if (param_2 != 0x400) break;
      }
      return (ulonglong)*(uint *)(param_1 + 0x86a8c);
    case 5:
      if ((*(byte *)(param_1 + 0x86a8c) & 0x80) != 0) {
        if (0xb < (param_2 >> 4) - 0x54) {
          uVar4 = FUN_004985d0(param_1 + 0x28);
          return uVar4;
        }
        switch(param_2 >> 4) {
        default:
          uVar4 = FUN_00498570();
          return uVar4;
        case 0x58:
        case 0x59:
        case 0x5a:
        case 0x5b:
          uVar4 = FUN_00498600();
          return uVar4;
        case 0x5c:
        case 0x5d:
        case 0x5e:
        case 0x5f:
          uVar4 = FUN_00498540(param_1 + 0x28);
          return uVar4;
        }
      }
    }
  }
  else if ((uVar2 == 3) && (uVar2 = param_2 >> 8, 0x37 < uVar2)) {
    if (uVar2 < 0x3c) {
      uVar2 = param_2 >> 1 & 0xfe;
      iVar3 = FUN_0045f8c0(param_1 + 0x4a8,uVar2 + 0x300);
      uVar1 = FUN_0045f8c0(param_1 + 0x4a8,uVar2 + 0x301);
      return (ulonglong)(iVar3 << 0x10 | (uint)uVar1);
    }
    if (uVar2 < 0x40) {
      uVar1 = FUN_0045f8c0(param_1 + 0x4a8,(param_2 - 0x3c00 >> 2) + 0x300);
      return (ulonglong)uVar1;
    }
  }
  return (ulonglong)*(uint *)(param_1 + 0x8668c + (ulonglong)(param_2 >> 2) * 4);
}


