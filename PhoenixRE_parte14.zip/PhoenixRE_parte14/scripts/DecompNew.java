import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.app.cmd.disassemble.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.*;
import ghidra.program.model.symbol.*;
import java.io.*;
import java.util.*;
public class DecompNew extends GhidraScript {
    @Override
    public void run() throws Exception {
        String[] a = getScriptArgs();
        String out = a[0];
        DecompInterface di = new DecompInterface();
        di.openProgram(currentProgram);
        for (int i = 1; i < a.length; i++) {
            Address ad = toAddr(a[i]);
            Function f = getFunctionAt(ad);
            if (f == null) {
                new DisassembleCommand(ad, null, true).applyTo(currentProgram, monitor);
                f = createFunction(ad, null);
            }
            if (f == null) { println("FAIL " + a[i]); continue; }
            DecompileResults r = di.decompileFunction(f, 180, monitor);
            TreeSet<String> callees = new TreeSet<>();
            for (Address ia : f.getBody().getAddresses(true)) {
                Instruction in = getInstructionAt(ia);
                if (in == null) continue;
                for (Reference rf : in.getReferencesFrom())
                    if (rf.getReferenceType().isCall()) callees.add(rf.getToAddress().toString());
            }
            try (PrintWriter w = new PrintWriter(new FileWriter(out + "/dec_" + f.getEntryPoint() + ".c"))) {
                w.println("// FUN @ " + f.getEntryPoint() + " size=" + f.getBody().getNumAddresses());
                w.println("// callees: " + callees);
                w.println(r.decompileCompleted() ? r.getDecompiledFunction().getC() : "// decompile failed: " + r.getErrorMessage());
            }
            println("OK " + a[i] + " " + f.getBody().getNumAddresses() + " " + callees);
        }
    }
}
