// FUN @ 00948300 size=1
// callees: []

void FUN_00948300(longlong *param_1,char param_2)

{
  int iVar1;
  int *piVar2;
  longlong lVar3;
  
  piVar2 = (int *)*param_1;
  if ((piVar2 != (int *)0x0) && (*piVar2 != 0)) {
    iVar1 = piVar2[2];
    if (iVar1 < 2) {
      if (param_2 == '\0') {
        *piVar2 = 0;
        return;
      }
      piVar2[2] = iVar1 + -1;
      lVar3 = *param_1;
      if (*(int *)(lVar3 + 8) == 0) {
        if (*(longlong *)(lVar3 + 0x10) != 0) {
          func_0x008ce278(*(longlong *)(lVar3 + 0x10) + -8);
          lVar3 = *param_1;
        }
        func_0x008ce280(lVar3);
      }
      *param_1 = 0;
    }
    else {
      piVar2[2] = iVar1 + -1;
      *param_1 = 0;
    }
  }
  return;
}


