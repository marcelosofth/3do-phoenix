// FUN @ 00704200 size=1
// callees: []

void FUN_00704200(longlong param_1)

{
  uint *puVar1;
  ulonglong *puVar2;
  int *piVar3;
  undefined8 *puVar4;
  longlong lVar5;
  ulonglong *puVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  uint uVar11;
  ulonglong uVar12;
  longlong lVar13;
  
  if (*(int *)(param_1 + 0x1000278) <= (int)(*(byte *)(param_1 + 0x1000283) & 0xf)) {
    return;
  }
  piVar3 = *(int **)(param_1 + 0x30);
  if (piVar3 == (int *)0x0) {
    piVar3 = (int *)func_0x008ce288(0x18);
    puVar4 = (undefined8 *)func_0x008ce290(0x2008);
    *puVar4 = 0x20;
    puVar9 = puVar4 + 1;
    do {
      *(undefined4 *)((longlong)puVar9 + 4) = 0;
      puVar10 = puVar9 + 0x20;
      *(undefined4 *)puVar9 = 0;
      puVar9 = puVar10;
    } while (puVar10 != puVar4 + 0x401);
    *(undefined8 **)(piVar3 + 4) = puVar4 + 1;
    piVar3[1] = 0x20;
    piVar3[2] = 1;
    *piVar3 = 0;
    *(int **)(param_1 + 0x30) = piVar3;
  }
  if (piVar3[2] < 2) {
    iVar7 = *piVar3;
    if (iVar7 < piVar3[1]) {
      puVar8 = (undefined4 *)((longlong)iVar7 * 0x100 + *(longlong *)(piVar3 + 4));
      *puVar8 = *(undefined4 *)(param_1 + 0x1000260);
      puVar8[1] = *(undefined4 *)(param_1 + 0x1000264);
      *(undefined8 *)(puVar8 + 2) = *(undefined8 *)(param_1 + 0x1000268);
      puVar8[4] = *(undefined4 *)(param_1 + 0x1000270);
      puVar8[5] = *(undefined4 *)(param_1 + 0x1000274);
      puVar8[6] = *(undefined4 *)(param_1 + 0x1000278);
      puVar8[7] = *(undefined4 *)(param_1 + 0x100027c);
      puVar8[8] = *(undefined4 *)(param_1 + 0x1000280);
      puVar8[9] = *(undefined4 *)(param_1 + 0x1000284);
      puVar8[10] = *(undefined4 *)(param_1 + 0x1000288);
      puVar8[0xb] = *(undefined4 *)(param_1 + 0x100028c);
      puVar8[0xc] = *(undefined4 *)(param_1 + 0x1000290);
      puVar8[0xd] = *(undefined4 *)(param_1 + 0x1000294);
      puVar8[0xe] = *(undefined4 *)(param_1 + 0x1000298);
      puVar8[0xf] = *(undefined4 *)(param_1 + 0x100029c);
      puVar8[0x10] = *(undefined4 *)(param_1 + 0x10002a0);
      puVar8[0x11] = *(undefined4 *)(param_1 + 0x10002a4);
      puVar8[0x12] = *(undefined4 *)(param_1 + 0x10002a8);
      puVar8[0x13] = *(undefined4 *)(param_1 + 0x10002ac);
      puVar8[0x14] = *(undefined4 *)(param_1 + 0x10002b0);
      puVar8[0x15] = *(undefined4 *)(param_1 + 0x10002b4);
      *(undefined8 *)(puVar8 + 0x16) = *(undefined8 *)(param_1 + 0x10002b8);
      *(undefined8 *)(puVar8 + 0x18) = *(undefined8 *)(param_1 + 0x10002c0);
      *(undefined8 *)(puVar8 + 0x1a) = *(undefined8 *)(param_1 + 0x10002c8);
      *(undefined8 *)(puVar8 + 0x1c) = *(undefined8 *)(param_1 + 0x10002d0);
      *(undefined8 *)(puVar8 + 0x1e) = *(undefined8 *)(param_1 + 0x10002d8);
      *(undefined8 *)(puVar8 + 0x20) = *(undefined8 *)(param_1 + 0x10002e0);
      *(undefined8 *)(puVar8 + 0x22) = *(undefined8 *)(param_1 + 0x10002e8);
      *(undefined8 *)(puVar8 + 0x24) = *(undefined8 *)(param_1 + 0x10002f0);
      puVar8[0x26] = *(undefined4 *)(param_1 + 0x10002f8);
      puVar8[0x27] = *(undefined4 *)(param_1 + 0x10002fc);
      *(undefined8 *)(puVar8 + 0x28) = *(undefined8 *)(param_1 + 0x1000300);
      *(undefined8 *)(puVar8 + 0x2a) = *(undefined8 *)(param_1 + 0x1000308);
      *(undefined8 *)(puVar8 + 0x2c) = *(undefined8 *)(param_1 + 0x1000310);
      *(undefined8 *)(puVar8 + 0x2e) = *(undefined8 *)(param_1 + 0x1000318);
      *(undefined8 *)(puVar8 + 0x30) = *(undefined8 *)(param_1 + 0x1000320);
      *(undefined8 *)(puVar8 + 0x32) = *(undefined8 *)(param_1 + 0x1000328);
      *(undefined8 *)(puVar8 + 0x34) = *(undefined8 *)(param_1 + 0x1000330);
      *(undefined8 *)(puVar8 + 0x36) = *(undefined8 *)(param_1 + 0x1000338);
      puVar8[0x38] = *(undefined4 *)(param_1 + 0x1000340);
      puVar8[0x39] = *(undefined4 *)(param_1 + 0x1000344);
      puVar8[0x3a] = *(undefined4 *)(param_1 + 0x1000348);
      puVar8[0x3b] = *(undefined4 *)(param_1 + 0x100034c);
      puVar8[0x3c] = *(undefined4 *)(param_1 + 0x1000350);
      puVar8[0x3d] = *(undefined4 *)(param_1 + 0x1000354);
      puVar8[0x3e] = *(undefined4 *)(param_1 + 0x1000358);
      puVar8[0x3f] = *(undefined4 *)(param_1 + 0x100035c);
      **(int **)(param_1 + 0x30) = **(int **)(param_1 + 0x30) + 1;
      return;
    }
  }
  else {
    iVar7 = *piVar3;
  }
  uVar11 = iVar7 + 2 + (iVar7 + 1U >> 1);
  if (uVar11 < 0x20) {
    puVar1 = (uint *)func_0x008ce288(0x18);
    lVar13 = 0x1f;
    lVar5 = 0x2008;
    uVar12 = 0x20;
    uVar11 = 0x20;
  }
  else {
    puVar1 = (uint *)func_0x008ce288(0x18);
    uVar12 = (ulonglong)(int)uVar11;
    if (uVar12 < 0x7f000000000001) {
      lVar13 = uVar12 - 1;
      lVar5 = uVar12 * 0x100 + 8;
    }
    else {
      lVar13 = uVar12 - 1;
      lVar5 = -1;
    }
  }
  puVar2 = (ulonglong *)func_0x008ce290(lVar5);
  lVar5 = 0;
  puVar6 = puVar2 + 1;
  *puVar2 = uVar12;
  puVar2 = puVar6;
  do {
    lVar5 = lVar5 + 1;
    *(undefined4 *)((longlong)puVar2 + 4) = 0;
    *(undefined4 *)puVar2 = 0;
    puVar2 = puVar2 + 0x20;
  } while (lVar5 != lVar13 + 1);
  *(ulonglong **)(puVar1 + 4) = puVar6;
  puVar1[1] = uVar11;
  puVar1[2] = 1;
  *puVar1 = iVar7 + 1U;
  iVar7 = 0;
  if (**(int **)(param_1 + 0x30) != 0) {
    FUN_008dd210(puVar6,*(undefined8 *)(*(int **)(param_1 + 0x30) + 4));
    puVar6 = *(ulonglong **)(puVar1 + 4);
    iVar7 = **(int **)(param_1 + 0x30);
  }
  puVar6 = puVar6 + (longlong)iVar7 * 0x20;
  *(undefined4 *)puVar6 = *(undefined4 *)(param_1 + 0x1000260);
  *(undefined4 *)((longlong)puVar6 + 4) = *(undefined4 *)(param_1 + 0x1000264);
  puVar6[1] = *(ulonglong *)(param_1 + 0x1000268);
  *(undefined4 *)(puVar6 + 2) = *(undefined4 *)(param_1 + 0x1000270);
  *(undefined4 *)((longlong)puVar6 + 0x14) = *(undefined4 *)(param_1 + 0x1000274);
  *(undefined4 *)(puVar6 + 3) = *(undefined4 *)(param_1 + 0x1000278);
  *(undefined4 *)((longlong)puVar6 + 0x1c) = *(undefined4 *)(param_1 + 0x100027c);
  *(undefined4 *)(puVar6 + 4) = *(undefined4 *)(param_1 + 0x1000280);
  *(undefined4 *)((longlong)puVar6 + 0x24) = *(undefined4 *)(param_1 + 0x1000284);
  *(undefined4 *)(puVar6 + 5) = *(undefined4 *)(param_1 + 0x1000288);
  *(undefined4 *)((longlong)puVar6 + 0x2c) = *(undefined4 *)(param_1 + 0x100028c);
  *(undefined4 *)(puVar6 + 6) = *(undefined4 *)(param_1 + 0x1000290);
  *(undefined4 *)((longlong)puVar6 + 0x34) = *(undefined4 *)(param_1 + 0x1000294);
  *(undefined4 *)(puVar6 + 7) = *(undefined4 *)(param_1 + 0x1000298);
  *(undefined4 *)((longlong)puVar6 + 0x3c) = *(undefined4 *)(param_1 + 0x100029c);
  *(undefined4 *)(puVar6 + 8) = *(undefined4 *)(param_1 + 0x10002a0);
  *(undefined4 *)((longlong)puVar6 + 0x44) = *(undefined4 *)(param_1 + 0x10002a4);
  *(undefined4 *)(puVar6 + 9) = *(undefined4 *)(param_1 + 0x10002a8);
  *(undefined4 *)((longlong)puVar6 + 0x4c) = *(undefined4 *)(param_1 + 0x10002ac);
  *(undefined4 *)(puVar6 + 10) = *(undefined4 *)(param_1 + 0x10002b0);
  *(undefined4 *)((longlong)puVar6 + 0x54) = *(undefined4 *)(param_1 + 0x10002b4);
  puVar6[0xb] = *(ulonglong *)(param_1 + 0x10002b8);
  puVar6[0xc] = *(ulonglong *)(param_1 + 0x10002c0);
  puVar6[0xd] = *(ulonglong *)(param_1 + 0x10002c8);
  puVar6[0xe] = *(ulonglong *)(param_1 + 0x10002d0);
  puVar6[0xf] = *(ulonglong *)(param_1 + 0x10002d8);
  puVar6[0x10] = *(ulonglong *)(param_1 + 0x10002e0);
  puVar6[0x11] = *(ulonglong *)(param_1 + 0x10002e8);
  puVar6[0x12] = *(ulonglong *)(param_1 + 0x10002f0);
  *(undefined4 *)(puVar6 + 0x13) = *(undefined4 *)(param_1 + 0x10002f8);
  *(undefined4 *)((longlong)puVar6 + 0x9c) = *(undefined4 *)(param_1 + 0x10002fc);
  puVar6[0x14] = *(ulonglong *)(param_1 + 0x1000300);
  puVar6[0x15] = *(ulonglong *)(param_1 + 0x1000308);
  puVar6[0x16] = *(ulonglong *)(param_1 + 0x1000310);
  puVar6[0x17] = *(ulonglong *)(param_1 + 0x1000318);
  puVar6[0x18] = *(ulonglong *)(param_1 + 0x1000320);
  puVar6[0x19] = *(ulonglong *)(param_1 + 0x1000328);
  puVar6[0x1a] = *(ulonglong *)(param_1 + 0x1000330);
  puVar6[0x1b] = *(ulonglong *)(param_1 + 0x1000338);
  *(undefined4 *)(puVar6 + 0x1c) = *(undefined4 *)(param_1 + 0x1000340);
  *(undefined4 *)((longlong)puVar6 + 0xe4) = *(undefined4 *)(param_1 + 0x1000344);
  *(undefined4 *)(puVar6 + 0x1d) = *(undefined4 *)(param_1 + 0x1000348);
  *(undefined4 *)((longlong)puVar6 + 0xec) = *(undefined4 *)(param_1 + 0x100034c);
  *(undefined4 *)(puVar6 + 0x1e) = *(undefined4 *)(param_1 + 0x1000350);
  *(undefined4 *)((longlong)puVar6 + 0xf4) = *(undefined4 *)(param_1 + 0x1000354);
  *(undefined4 *)(puVar6 + 0x1f) = *(undefined4 *)(param_1 + 0x1000358);
  *(undefined4 *)((longlong)puVar6 + 0xfc) = *(undefined4 *)(param_1 + 0x100035c);
  if (*(longlong *)(param_1 + 0x30) != 0) {
    piVar3 = (int *)(*(longlong *)(param_1 + 0x30) + 8);
    *piVar3 = *piVar3 + -1;
    lVar13 = *(longlong *)(param_1 + 0x30);
    if (*(int *)(lVar13 + 8) == 0) {
      if (*(longlong *)(lVar13 + 0x10) != 0) {
        func_0x008ce278(*(longlong *)(lVar13 + 0x10) + -8);
        lVar13 = *(longlong *)(param_1 + 0x30);
      }
      func_0x008ce280(lVar13);
    }
  }
  *(uint **)(param_1 + 0x30) = puVar1;
  return;
}


