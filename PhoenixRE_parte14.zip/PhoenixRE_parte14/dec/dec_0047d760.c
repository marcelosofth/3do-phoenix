// FUN @ 0047d760 size=1
// callees: []

undefined8 *
FUN_0047d760(longlong param_1,int param_2,int param_3,uint param_4,int param_5,uint *param_6)

{
  byte bVar1;
  longlong lVar2;
  undefined1 uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong lVar9;
  longlong lVar10;
  uint uStack_74;
  longlong lStack_70;
  int iStack_68;
  
  puVar7 = (undefined8 *)func_0x008ce288(0x80);
  lVar9 = -1;
  if ((ulonglong)(longlong)(int)(param_4 * param_3) < 0x1fc0000000000001) {
    lVar9 = (longlong)(int)(param_4 * param_3) * 4;
  }
  uVar8 = func_0x008ce290(lVar9);
  *(uint *)(puVar7 + 0xc) = param_4;
  puVar7[0xf] = uVar8;
  *(int *)((longlong)puVar7 + 0x5c) = param_3;
  *puVar7 = *(undefined8 *)param_6;
  puVar7[1] = *(undefined8 *)(param_6 + 2);
  puVar7[2] = *(undefined8 *)(param_6 + 4);
  puVar7[3] = *(undefined8 *)(param_6 + 6);
  puVar7[4] = *(undefined8 *)(param_6 + 8);
  puVar7[5] = *(undefined8 *)(param_6 + 10);
  puVar7[6] = *(undefined8 *)(param_6 + 0xc);
  puVar7[7] = *(undefined8 *)(param_6 + 0xe);
  puVar7[8] = *(undefined8 *)(param_6 + 0x10);
  puVar7[9] = *(undefined8 *)(param_6 + 0x12);
  uVar8 = *(undefined8 *)(param_6 + 0x14);
  *(undefined1 *)((longlong)puVar7 + 0x65) = 0;
  puVar7[10] = uVar8;
  *(int *)(puVar7 + 0xb) = param_5;
  uVar3 = FUN_0047ccf0(param_1);
  *(undefined1 *)((longlong)puVar7 + 100) = uVar3;
  bVar1 = (&UNK_00b030a0)[(ulonglong)(*param_6 & 7) * 4];
  uVar4 = 0x20;
  if ((bVar1 < 0x21) && (uVar4 = 1, bVar1 != 0)) {
    uVar4 = (uint)bVar1;
  }
  *(uint *)(param_1 + 0x1000234) = uVar4;
  if (0 < (int)param_4) {
    uStack_74 = 0;
    lStack_70 = 0;
    lVar9 = (ulonglong)(param_3 - 1) * 4 + 4;
    iStack_68 = param_2;
    do {
      *(undefined4 *)(param_1 + 0x100022c) = 0;
      *(undefined4 *)(param_1 + 0x1000230) = 0;
      *(int *)(param_1 + 0x1000228) = iStack_68;
      lVar10 = lStack_70 * 4;
      if (0 < param_3) {
        do {
          if ((*(byte *)((longlong)param_6 + 0x11) & 8) == 0) {
            lVar2 = puVar7[0xf];
            uVar6 = FUN_0059c2f0(param_1 + 0x1000228);
            uVar6 = FUN_0047ca50(param_1,uVar6);
            *(undefined4 *)(lVar10 + lVar2) = uVar6;
          }
          else {
            lVar2 = puVar7[0xf];
            uVar6 = FUN_0059c4d0(param_1 + 0x1000228,2);
            uVar6 = FUN_0047ca50(param_1,uVar6);
            *(undefined4 *)(lVar10 + lVar2) = uVar6;
          }
          if (*(char *)((longlong)puVar7 + 100) != '\0') {
            lVar2 = puVar7[0xf];
            uVar4 = *(uint *)(lVar10 + lVar2);
            uVar5 = FUN_0047d0d0(param_1,uVar4,0);
            *(uint *)(lVar10 + lVar2) = uVar5 | uVar4 & 0x80000000;
          }
          lVar10 = lVar10 + 4;
        } while (lVar10 != lVar9);
      }
      if ((*(byte *)((longlong)param_6 + 0x11) & 8) == 0) {
        iStack_68 = iStack_68 + param_5;
      }
      else if ((uStack_74 & 1) == 0) {
        iStack_68 = iStack_68 + 2;
      }
      else {
        iStack_68 = iStack_68 + param_5 + -2;
      }
      uStack_74 = uStack_74 + 1;
      lVar9 = lVar9 + (longlong)param_3 * 4;
      lStack_70 = lStack_70 + param_3;
    } while (uStack_74 != param_4);
  }
  return puVar7;
}


