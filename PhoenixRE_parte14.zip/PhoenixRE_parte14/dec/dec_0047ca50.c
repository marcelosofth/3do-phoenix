// FUN @ 0047ca50 size=1
// callees: []

ulonglong FUN_0047ca50(longlong param_1,ulonglong param_2)

{
  ulonglong uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar2 = *(uint *)(param_1 + 0x1000280);
  uVar1 = param_2 & 0xffffffff;
  uVar3 = (uint)param_2;
  switch(uVar2 & 7) {
  default:
    uVar2 = *(uint *)(param_1 + 0x100027c);
    uVar1 = (ulonglong)
            *(ushort *)(param_1 + 0x1000300 + (ulonglong)((uVar3 & 1) + (uVar2 & 0xf) * 2) * 2);
    break;
  case 2:
    uVar2 = *(uint *)(param_1 + 0x100027c);
    uVar1 = (ulonglong)
            *(ushort *)(param_1 + 0x1000300 + (ulonglong)((uVar3 & 3) + (uVar2 & 0xe) * 2) * 2);
    break;
  case 3:
    uVar2 = *(uint *)(param_1 + 0x100027c);
    uVar1 = (ulonglong)
            *(ushort *)(param_1 + 0x1000300 + (ulonglong)((uVar3 & 0xf) + (uVar2 & 8) * 2) * 2);
    break;
  case 4:
    uVar1 = (ulonglong)
            ((uVar3 >> 5 & 1) * 0x8000 +
            (*(ushort *)(param_1 + 0x1000300 + (ulonglong)(uVar3 & 0x1f) * 2) & 0x7fff));
    uVar2 = *(uint *)(param_1 + 0x100027c);
    break;
  case 5:
    if ((uVar2 & 0x10) == 0) {
      uVar4 = (uint)(uVar1 >> 5) & 7;
      uVar2 = *(uint *)(param_1 + 0x100027c);
      uVar1 = (ulonglong)
              ((uVar4 * 8 | uVar4 << 6 | uVar4) << 0x10 |
              (uint)*(ushort *)(param_1 + 0x1000300 + (ulonglong)(uVar3 & 0x1f) * 2));
    }
    else {
      if ((uVar2 & 8) == 0) {
        uVar3 = (uVar3 & 0x1c) << 5 | (uVar3 & 3) << 3 | (uVar3 & 0xe0) << 7 | (uVar3 & 1) * 2 |
                (uVar3 & 2) >> 1 | (uVar3 & 2) * 2 | (uVar3 & 0x18) << 2 | (uVar3 & 0xc0) << 4;
      }
      else {
        uVar3 = (uVar3 & 0x1c) << 5 | (uVar3 & 3) << 3 | (uVar3 & 0xe0) << 7;
      }
      uVar2 = *(uint *)(param_1 + 0x100027c);
      uVar1 = (ulonglong)((uVar2 & 0x80) << 8 | uVar3);
    }
    break;
  case 6:
  case 7:
    if ((uVar2 & 0x10) == 0) {
      uVar1 = (ulonglong)
              (uVar3 & 0x8000 | (uVar3 & 0x3fe0) << 0xb |
              *(ushort *)(param_1 + 0x1000300 + (ulonglong)(uVar3 & 0x1f) * 2) & 0x7fff);
    }
    uVar2 = *(uint *)(param_1 + 0x100027c);
  }
  if (((uVar2 & 0x20) == 0) && ((uVar1 & 0x7fff) == 0)) {
    uVar1 = uVar1 | 0x80000000;
  }
  return uVar1;
}


