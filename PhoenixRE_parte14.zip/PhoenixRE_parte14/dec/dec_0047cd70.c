// FUN @ 0047cd70 size=1
// callees: []

uint * FUN_0047cd70(uint *param_1,longlong param_2)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  char cVar4;
  uint uVar5;
  longlong lVar6;
  uint uVar7;
  ulonglong uVar8;
  uint uVar9;
  uint uVar10;
  uint *puVar11;
  
  uVar5 = *(uint *)(param_2 + 0x1000214);
  uVar10 = *(uint *)(param_2 + 0x1000218);
  param_1[2] = 0;
  uVar1 = *(uint *)(param_2 + 0x1000210);
  param_1[3] = 0;
  uVar9 = uVar5 & 7;
  param_1[4] = uVar10 & 0x800;
  *param_1 = uVar9;
  param_1[1] = uVar1 & 0x20;
  switch(uVar9) {
  default:
    param_1[5] = 2;
    iVar2 = (uVar1 & 0xf) * 2;
    uVar3 = *(undefined4 *)(param_2 + 0x10000f0 + (ulonglong)(iVar2 + 0x21) * 4);
    *(short *)(param_1 + 6) =
         (short)*(undefined4 *)(param_2 + 0x10000f0 + (ulonglong)(iVar2 + 0x20) * 4);
    *(short *)((longlong)param_1 + 0x1a) = (short)uVar3;
    break;
  case 2:
    param_1[5] = 4;
    iVar2 = (uVar1 & 0xe) * 2;
    uVar5 = iVar2 + 0x20;
    puVar11 = param_1 + 6;
    do {
      uVar8 = (ulonglong)uVar5;
      uVar5 = uVar5 + 1;
      *(short *)puVar11 = (short)*(undefined4 *)(param_2 + 0x10000f0 + uVar8 * 4);
      puVar11 = (uint *)((longlong)puVar11 + 2);
    } while (uVar5 != iVar2 + 0x24U);
    break;
  case 3:
    param_1[5] = 0x10;
    iVar2 = (uVar1 & 8) * 2;
    uVar5 = iVar2 + 0x20;
    puVar11 = param_1 + 6;
    do {
      uVar8 = (ulonglong)uVar5;
      uVar5 = uVar5 + 1;
      *(short *)puVar11 = (short)*(undefined4 *)(param_2 + 0x10000f0 + uVar8 * 4);
      puVar11 = (uint *)((longlong)puVar11 + 2);
    } while (uVar5 != iVar2 + 0x30U);
    break;
  case 4:
    param_1[5] = 0x20;
    lVar6 = 0;
    do {
      *(short *)((longlong)param_1 + lVar6 + 0x18) =
           (short)*(undefined4 *)(param_2 + 0x1000170 + lVar6 * 2);
      lVar6 = lVar6 + 2;
    } while (lVar6 != 0x40);
    break;
  case 5:
    if ((uVar5 & 0x10) == 0) {
      param_1[5] = 0x20;
      lVar6 = 0;
      do {
        *(short *)((longlong)param_1 + lVar6 + 0x18) =
             (short)*(undefined4 *)(param_2 + 0x1000170 + lVar6 * 2);
        lVar6 = lVar6 + 2;
      } while (lVar6 != 0x40);
    }
    else {
      param_1[5] = 0;
      *param_1 = (-(uint)((uVar5 & 8) == 0) & 0xfffffff8) + 0x1d;
      param_1[1] = uVar1 & 0xa0;
    }
    break;
  case 6:
  case 7:
    if ((uVar5 & 0x10) == 0) {
      param_1[5] = 0x20;
      lVar6 = 0;
      do {
        *(short *)((longlong)param_1 + lVar6 + 0x18) =
             (short)*(undefined4 *)(param_2 + 0x1000170 + lVar6 * 2);
        lVar6 = lVar6 + 2;
      } while (lVar6 != 0x40);
    }
    else {
      param_1[5] = 0;
      *param_1 = uVar9 | 0x10;
    }
  }
  cVar4 = FUN_0047ccf0(param_2);
  if (cVar4 != '\0') {
    uVar5 = param_1[4] | 1;
    param_1[4] = uVar5;
    if ((uVar1 & 0x100) == 0) {
      uVar10 = param_1[1];
      param_1[2] = *(uint *)(param_2 + 0x1000110);
    }
    else {
      uVar10 = uVar1 & 0x180 | param_1[1];
      param_1[1] = uVar10;
      if ((uVar1 & 0x80) == 0) {
        param_1[2] = (uint)*(ushort *)(param_2 + 0x1000110);
      }
      else {
        param_1[2] = (uint)*(ushort *)(param_2 + 0x1000112);
      }
    }
    uVar9 = *(uint *)(param_2 + 0x1000100);
    uVar7 = uVar9 & 0xc0000000 | param_1[3];
    param_1[3] = uVar7;
    if ((int)uVar9 < 0) {
      iVar2 = *(int *)(param_2 + 0x10002fc);
      uVar5 = iVar2 * 2 | uVar5;
      param_1[4] = uVar5;
      if (iVar2 == 0) {
        uVar5 = *(uint *)(param_2 + 0x1000134) & 0x8000 | uVar5;
      }
      else if (iVar2 == 2) {
        uVar5 = *(uint *)(param_2 + 0x1000130) & 0x8000 | uVar5;
      }
    }
    uVar5 = *(int *)(param_2 + 0x10002f8) * 8 | uVar5;
    param_1[4] = uVar5;
    param_1[3] = uVar9 & 0x30000000 | uVar7;
    if ((uVar9 >> 0x1c & 3) == 3) {
      iVar2 = *(int *)(param_2 + 0x10002fc);
      uVar5 = iVar2 * 2 | uVar5;
      param_1[4] = uVar5;
      if (iVar2 == 0) {
        param_1[4] = (*(uint *)(param_2 + 0x1000130) & 0x8000) * 2 | uVar5;
      }
      else if (iVar2 == 2) {
        param_1[4] = (*(uint *)(param_2 + 0x1000134) & 0x8000) * 2 | uVar5;
      }
    }
    param_1[1] = uVar1 & 0xc10 | uVar10;
  }
  return param_1;
}


