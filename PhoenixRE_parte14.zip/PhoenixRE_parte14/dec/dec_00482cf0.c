// FUN @ 00482cf0 size=1
// callees: []

undefined8 FUN_00482cf0(longlong param_1,longlong param_2)

{
  uint uVar1;
  uint *puVar2;
  int *piVar3;
  undefined8 uVar4;
  longlong lVar5;
  int iVar6;
  undefined4 *puVar7;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 auStack_50 [2];
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  
  if (*(int *)(*(longlong *)(param_1 + 0x1000268) + 0x6c) < 0) {
    uStack_58 = 0;
    if ((**(uint **)(*(longlong *)(param_1 + 0x1000268) + 0x78) & 0x8000) == 0) {
      uStack_54 = 0;
    }
    else {
      uStack_54 = 0x3f800000;
    }
  }
  else {
    uStack_58 = 0x3f800000;
  }
  *(undefined4 *)(param_2 + 0x20) = *(undefined4 *)(param_1 + 0x10000d8);
  uStack_48 = *(undefined4 *)(param_1 + 0x10000dc);
  if (*(undefined4 **)(param_2 + 0x28) == (undefined4 *)0x0) {
    uStack_44 = 0;
  }
  else {
    uStack_44 = **(undefined4 **)(param_2 + 0x28);
  }
  puVar7 = &uStack_58;
  uStack_40 = 0x10002;
  FUN_009489e0(param_2 + 0x30,&uStack_48);
  do {
    piVar3 = *(int **)(param_2 + 0x28);
    if (piVar3 == (int *)0x0) {
      piVar3 = (int *)func_0x008ce288(0x18);
      uVar4 = func_0x008ce290(0x80);
      piVar3[1] = 0x20;
      *(undefined8 *)(piVar3 + 4) = uVar4;
      piVar3[2] = 1;
      *piVar3 = 0;
      *(int **)(param_2 + 0x28) = piVar3;
    }
    if (piVar3[2] < 2) {
      iVar6 = *piVar3;
      if (piVar3[1] <= iVar6) goto code_r0x00482d73;
      *(undefined4 *)(*(longlong *)(piVar3 + 4) + (longlong)iVar6 * 4) = *puVar7;
      **(int **)(param_2 + 0x28) = **(int **)(param_2 + 0x28) + 1;
    }
    else {
      iVar6 = *piVar3;
code_r0x00482d73:
      uVar1 = iVar6 + 2 + (iVar6 + 1U >> 1);
      if (uVar1 < 0x20) {
        uVar1 = 0x20;
        puVar2 = (uint *)func_0x008ce288(0x18);
        lVar5 = 0x80;
      }
      else {
        puVar2 = (uint *)func_0x008ce288(0x18);
        lVar5 = -1;
        if ((ulonglong)(longlong)(int)uVar1 < 0x1fc0000000000001) {
          lVar5 = (longlong)(int)uVar1 * 4;
        }
      }
      lVar5 = func_0x008ce290(lVar5);
      puVar2[1] = uVar1;
      *(longlong *)(puVar2 + 4) = lVar5;
      puVar2[2] = 1;
      *puVar2 = iVar6 + 1U;
      iVar6 = 0;
      if (**(int **)(param_2 + 0x28) != 0) {
        FUN_008de2d0(lVar5,*(undefined8 *)(*(int **)(param_2 + 0x28) + 4));
        lVar5 = *(longlong *)(puVar2 + 4);
        iVar6 = **(int **)(param_2 + 0x28);
      }
      *(undefined4 *)(lVar5 + (longlong)iVar6 * 4) = *puVar7;
      if (*(longlong *)(param_2 + 0x28) != 0) {
        piVar3 = (int *)(*(longlong *)(param_2 + 0x28) + 8);
        *piVar3 = *piVar3 + -1;
        lVar5 = *(longlong *)(param_2 + 0x28);
        if (*(int *)(lVar5 + 8) == 0) {
          if (*(longlong *)(lVar5 + 0x10) != 0) {
            func_0x008ce278();
            lVar5 = *(longlong *)(param_2 + 0x28);
          }
          func_0x008ce280(lVar5);
        }
      }
      *(uint **)(param_2 + 0x28) = puVar2;
    }
    puVar7 = puVar7 + 1;
    if (puVar7 == auStack_50) {
      return 0;
    }
  } while( true );
}


