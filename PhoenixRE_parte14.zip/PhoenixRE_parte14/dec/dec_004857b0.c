// FUN @ 004857b0 size=1
// callees: []

int FUN_004857b0(longlong *param_1,int param_2,int param_3,int param_4,int param_5)

{
  longlong *plVar1;
  uint uVar2;
  int *piVar3;
  code *pcVar4;
  int iVar5;
  int *piVar6;
  longlong lVar7;
  longlong *plStack_98;
  code *pcStack_90;
  undefined8 uStack_88;
  undefined4 uStack_78;
  int iStack_74;
  int iStack_70;
  int *piStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  
  piVar6 = (int *)param_1[0xe];
  plVar1 = param_1 + 0xe;
  if ((piVar6 != (int *)0x0) && (*piVar6 != 0)) {
    if (piVar6[2] < 2) {
      *piVar6 = 0;
    }
    else {
      piVar6[2] = piVar6[2] + -1;
      param_1[0xe] = 0;
    }
  }
  lVar7 = 0;
  (**(code **)(*param_1 + 0x68))(param_1,plVar1,param_2,0x10003,0);
  uVar2 = *(uint *)(param_1 + 0x200042);
  piVar6 = (int *)param_1[0xe];
  while( true ) {
    if ((piVar6 == (int *)0x0) || (*piVar6 <= (int)lVar7)) {
      piVar6 = (int *)func_0x008ce288(0x1c);
      piVar6[2] = param_5;
      *piVar6 = param_2;
      piVar6[1] = param_4;
      piVar6[3] = param_3;
      piVar6[4] = uVar2 & 0x20;
      *(undefined1 *)(piVar6 + 5) = 0;
      iVar5 = FUN_00481f30(param_1,param_2,param_3,0,0,param_4,param_5);
      uStack_78 = 0;
      piVar6[6] = iVar5;
      uStack_5c = 0;
      uStack_58 = 0;
      iStack_70 = param_5 * param_3;
      if (0x300000 < (uint)(param_5 * param_3 + param_2)) {
        iStack_70 = 0x300000 - param_2;
      }
      uStack_60 = 0x10003;
      pcStack_90 = FUN_004898c0;
      uStack_88 = 0;
      plStack_98 = param_1;
      iStack_74 = param_2;
      piStack_68 = piVar6;
      (**(code **)(*param_1 + 0x48))(param_1,&uStack_78,&plStack_98);
      return piVar6[6];
    }
    FUN_00943830(plVar1);
    piVar6 = (int *)param_1[0xe];
    piVar3 = *(int **)(*(longlong *)(piVar6 + 4) + 0x10 + lVar7 * 0x28);
    if ((((piVar3[2] == param_5) && (piVar3[1] == param_4)) && (piVar3[4] == (uVar2 & 0x20))) &&
       ((*piVar3 == param_2 && (piVar3[3] == param_3)))) break;
    lVar7 = lVar7 + 1;
  }
  pcVar4 = *(code **)(*param_1 + 0x58);
  FUN_00943830(plVar1);
  (*pcVar4)(param_1,lVar7 * 0x28 + *(longlong *)(param_1[0xe] + 0x10));
  return piVar3[6];
}


