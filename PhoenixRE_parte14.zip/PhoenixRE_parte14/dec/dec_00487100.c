// FUN @ 00487100 size=1
// callees: []

ulonglong FUN_00487100(longlong *param_1,longlong param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  uint uVar7;
  int iVar8;
  longlong lVar9;
  uint uVar10;
  uint uVar11;
  undefined1 auStack_398 [32];
  uint uStack_378;
  int *piStack_370;
  longlong *plStack_368;
  undefined8 uStack_360;
  longlong *plStack_358;
  code *pcStack_350;
  int *piStack_348;
  int iStack_33c;
  int **ppiStack_338;
  int *piStack_330;
  int *piStack_328;
  uint uStack_320;
  uint uStack_31c;
  undefined1 *puStack_318;
  int *piStack_310;
  longlong **pplStack_308;
  undefined4 *puStack_300;
  longlong lStack_2f8;
  undefined4 uStack_2f0;
  uint uStack_2ec;
  int **ppiStack_2e8;
  uint uStack_2e0;
  undefined4 uStack_2dc;
  undefined4 uStack_2d8;
  undefined4 uStack_2d4;
  undefined4 uStack_2d0;
  undefined4 uStack_2cc;
  undefined4 uStack_2c8;
  undefined4 uStack_2c4;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 uStack_2b8;
  undefined4 uStack_2b4;
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  longlong lStack_2a8;
  longlong lStack_2a0;
  longlong lStack_298;
  longlong lStack_290;
  longlong lStack_288;
  longlong lStack_280;
  longlong lStack_278;
  longlong lStack_270;
  undefined4 uStack_268;
  undefined4 uStack_264;
  undefined4 uStack_260;
  undefined4 uStack_25c;
  undefined4 uStack_258;
  undefined4 uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined1 auStack_248 [8];
  undefined4 uStack_240;
  undefined *puStack_218;
  undefined *puStack_210;
  undefined1 *puStack_208;
  undefined *puStack_200;
  undefined1 *puStack_1f8;
  undefined4 uStack_1e0;
  undefined4 uStack_1dc;
  int *apiStack_1d8 [2];
  longlong *plStack_1c8;
  code *pcStack_1c0;
  undefined8 uStack_1b8;
  undefined4 uStack_1a8;
  int iStack_1a4;
  int iStack_1a0;
  longlong lStack_198;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  undefined8 uStack_188;
  int iStack_178;
  int iStack_174;
  int iStack_170;
  int iStack_16c;
  int iStack_168;
  longlong *plStack_118;
  code *pcStack_110;
  longlong lStack_108;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  undefined8 uStack_f8;
  longlong lStack_78;
  longlong lStack_70;
  longlong lStack_68;
  longlong lStack_60;
  longlong lStack_58;
  longlong lStack_50;
  longlong lStack_48;
  longlong lStack_40;
  undefined1 auStack_18 [8];
  
  puStack_1f8 = auStack_398;
  puStack_318 = auStack_248;
  puStack_218 = &DAT_008ce270;
  puStack_210 = &UNK_00cc16d8;
  puStack_208 = auStack_18;
  puStack_200 = &UNK_004886c4;
  plStack_368 = param_1;
  lStack_2f8 = param_2;
  uStack_2f0 = param_3;
  func_0x008ce548(puStack_318);
  uStack_31c = *(uint *)(&UNK_00b030a0 +
                        (ulonglong)(*(uint *)((longlong)plStack_368 + 0x1000214) & 7) * 4);
  if ((int)uStack_31c < 8) {
    uVar10 = *(uint *)(plStack_368 + 0x200043);
    uVar7 = uVar10 >> 0x18;
  }
  else {
    uVar10 = *(uint *)(plStack_368 + 0x200043);
    uVar7 = (uVar10 & 0x3ff0000) >> 0x10;
  }
  uStack_320 = uVar7 * 4 + 8;
  iVar4 = ((*(uint *)((longlong)plStack_368 + 0x1000214) & 0xffc0) >> 6) + 1;
  iVar8 = (uVar10 & 0x7ff) + 1;
  uStack_360 = (code *)CONCAT44(uStack_360._4_4_,iVar8);
  *(int *)(plStack_368 + 0x20004f) = iVar8;
  if ((uVar10 & 0x800) == 0) {
    *(int *)((longlong)plStack_368 + 0x1000274) = iVar4;
  }
  else {
    iVar4 = iVar4 * 2;
    *(int *)((longlong)plStack_368 + 0x1000274) = iVar4;
  }
  plStack_358 = (longlong *)CONCAT44(plStack_358._4_4_,iVar4);
  piStack_310 = &iStack_178;
  FUN_0047cd70(piStack_310,plStack_368);
  iStack_33c = ((int)plStack_358 + -1) * uStack_320 + ((int)((int)uStack_360 * uStack_31c + 7) >> 3)
  ;
  plStack_358 = plStack_368 + 0x20000f;
  piVar5 = (int *)plStack_368[0x20000f];
  if ((piVar5 != (int *)0x0) && (*piVar5 != 0)) {
    if (piVar5[2] < 2) {
      *piVar5 = 0;
    }
    else {
      piVar5[2] = piVar5[2] + -1;
      plStack_368[0x20000f] = 0;
    }
  }
  uStack_378 = 0;
  uStack_240 = 0xffffffff;
  (**(code **)(*plStack_368 + 0x68))
            (plStack_368,plStack_358,*(undefined4 *)((longlong)plStack_368 + 0x10001fc),0x10001);
  piVar5 = (int *)plStack_368[0x20000f];
  if ((piVar5 != (int *)0x0) && (*piVar5 != 0)) {
    for (uStack_360 = (code *)0x0; (int)uStack_360 < *piVar5; uStack_360 = uStack_360 + 1) {
      uStack_240 = 0xffffffff;
      FUN_00943830(plStack_358);
      pcStack_350 = (code *)((longlong)uStack_360 * 0x28);
      piVar5 = (int *)plStack_368[0x20000f];
      if (*(uint *)(pcStack_350 + *(longlong *)((int *)plStack_368[0x20000f] + 4) + 4) <=
          *(uint *)((longlong)plStack_368 + 0x10001fc)) {
        FUN_00943830(plStack_358);
        piStack_348 = (int *)CONCAT44(piStack_348._4_4_,
                                      *(undefined4 *)
                                       (pcStack_350 +
                                       *(longlong *)(plStack_368[0x20000f] + 0x10) + 4));
        FUN_00943830(plStack_358);
        piVar5 = (int *)plStack_368[0x20000f];
        if ((uint)(iStack_33c + *(int *)((longlong)plStack_368 + 0x10001fc)) <=
            (uint)piStack_348 +
            *(int *)(pcStack_350 + *(longlong *)((int *)plStack_368[0x20000f] + 4) + 8)) {
          uStack_240 = 0xffffffff;
          FUN_00943830(plStack_358);
          piStack_348 = (int *)plStack_368[0x20000f];
          piVar2 = *(int **)(pcStack_350 + *(longlong *)(piStack_348 + 4) + 0x10);
          plStack_368[0x20004d] = (longlong)piVar2;
          piVar5 = piStack_348;
          if ((((piVar2[0x16] == uStack_320) && (iStack_178 == *piVar2)) &&
              (iStack_174 == piVar2[1])) &&
             (((iStack_170 == piVar2[2] && (iStack_16c == piVar2[3])) &&
              ((iStack_168 == piVar2[4] &&
               (cVar3 = FUN_0047c330(piVar2,piStack_310), piVar5 = piStack_348, cVar3 != '\0'))))))
          {
            uStack_240 = 0xffffffff;
            piStack_348 = (int *)CONCAT44(piStack_348._4_4_,
                                          *(undefined4 *)((longlong)plStack_368 + 0x10001fc));
            FUN_00943830(plStack_358);
            piVar5 = (int *)plStack_368[0x20000f];
            uVar11 = (uint)piStack_348 - *(int *)(pcStack_350 + *(longlong *)(piVar5 + 4) + 4);
            uVar7 = uVar11 / uStack_320;
            uVar10 = uVar11 % uStack_320;
            if ((*(byte *)((longlong)plStack_368 + 0x1000219) & 8) != 0) {
              uVar7 = (uVar7 * 2 + 1) - (uint)((uVar11 & 2) == 0);
              uVar11 = uVar10 + 3;
              if (-1 < (int)uVar10) {
                uVar11 = uVar10;
              }
              uVar10 = (uVar10 & 1) + ((int)uVar11 >> 2) * 2;
            }
            iVar4 = (int)(uVar10 * 8) / (int)uStack_31c;
            if ((((int)(uVar10 * 8) % (int)uStack_31c == 0) &&
                ((int)plStack_368[0x20004f] + iVar4 <= *(int *)(plStack_368[0x20004d] + 0x5c))) &&
               ((int)(*(int *)((longlong)plStack_368 + 0x1000274) + uVar7) <=
                *(int *)(plStack_368[0x20004d] + 0x60))) {
              *(int *)(plStack_368 + 0x20004c) = iVar4;
              *(uint *)((longlong)plStack_368 + 0x1000264) = uVar7;
              uStack_360 = *(code **)(*plStack_368 + 0x58);
              uStack_240 = 0xffffffff;
              FUN_00943830(plStack_358);
              (*uStack_360)(plStack_368,pcStack_350 + *(longlong *)(plStack_368[0x20000f] + 0x10));
              iVar4 = *(int *)((longlong)plStack_368 + 0x1000274) * (int)plStack_368[0x20004f];
              goto code_r0x00487675;
            }
          }
        }
      }
    }
  }
  *(undefined4 *)(plStack_368 + 0x20004c) = 0;
  *(undefined4 *)((longlong)plStack_368 + 0x1000264) = 0;
  piStack_370 = piStack_310;
  uStack_240 = 0xffffffff;
  uStack_378 = uStack_320;
  lStack_198 = FUN_0047d760(plStack_368,*(undefined4 *)((longlong)plStack_368 + 0x10001fc),
                            (int)plStack_368[0x20004f],
                            *(undefined4 *)((longlong)plStack_368 + 0x1000274));
  uStack_1a8 = 0;
  uStack_18c = 0;
  iStack_1a4 = *(int *)((longlong)plStack_368 + 0x10001fc);
  plStack_368[0x20004d] = lStack_198;
  uStack_188 = 0;
  if (0x2fffff < (uint)(iStack_33c + -1 + iStack_1a4)) {
    iStack_33c = 0x300000 - iStack_1a4;
  }
  pplStack_308 = &plStack_118;
  uStack_190 = 0x10001;
  pcStack_110 = FUN_00489930;
  puStack_300 = &uStack_1a8;
  plStack_118 = plStack_368;
  lStack_108 = 0;
  uStack_240 = 0xffffffff;
  iStack_1a0 = iStack_33c;
  (**(code **)(*plStack_368 + 0x48))(plStack_368,puStack_300,pplStack_308);
  if ((*(byte *)((longlong)plStack_368 + 0x1000219) & 8) != 0) {
    iVar4 = *(int *)((longlong)plStack_368 + 0x1000274) * (int)plStack_368[0x20004f];
code_r0x00487675:
    iVar4 = iVar4 * uStack_31c;
    if (iVar4 < 0) {
      iVar4 = iVar4 + 7;
    }
    plStack_368 = (longlong *)CONCAT44(plStack_368._4_4_,iVar4 >> 3);
    goto code_r0x0048768b;
  }
  piVar5 = (int *)plStack_368[0x20000f];
  if ((piVar5 != (int *)0x0) && (*piVar5 != 0)) {
    if (piVar5[2] < 2) {
      *piVar5 = 0;
    }
    else {
      piVar5[2] = piVar5[2] + -1;
      plStack_368[0x20000f] = 0;
    }
  }
  uStack_378 = 0;
  uStack_240 = 0xffffffff;
  (**(code **)(*plStack_368 + 0x68))
            (plStack_368,plStack_358,*(undefined4 *)((longlong)plStack_368 + 0x10001fc),0x10001);
  ppiStack_2e8 = apiStack_1d8;
  apiStack_1d8[0] = (int *)0x0;
  uStack_360 = (code *)((ulonglong)uStack_360 & 0xffffffff00000000);
  piStack_348 = (int *)CONCAT44(piStack_348._4_4_,*(undefined4 *)((longlong)plStack_368 + 0x10001fc)
                               );
  uStack_2ec = *(uint *)(plStack_368 + 0x20004f);
  uStack_2e0 = *(uint *)((longlong)plStack_368 + 0x1000274);
  piVar5 = (int *)plStack_368[0x20000f];
code_r0x004877e7:
  if (piVar5 == (int *)0x0) goto code_r0x00487922;
code_r0x004877f0:
  if ((int)uStack_360 < *piVar5) {
    do {
      uStack_240 = 1;
      FUN_00943830(plStack_358);
      ppiStack_338 = (int **)(longlong)(int)uStack_360;
      piVar5 = (int *)plStack_368[0x20000f];
      pcStack_350 = (code *)((longlong)ppiStack_338 * 0x28);
      if (iStack_33c + (uint)piStack_348 <= *(uint *)(pcStack_350 + *(longlong *)(piVar5 + 4) + 4))
      {
code_r0x004877e2:
        uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)uStack_360 + 1);
        goto code_r0x004877e7;
      }
      FUN_00943830(plStack_358);
      piStack_330 = (int *)CONCAT44(piStack_330._4_4_,
                                    *(undefined4 *)
                                     (pcStack_350 + *(longlong *)(plStack_368[0x20000f] + 0x10) + 4)
                                   );
      FUN_00943830(plStack_358);
      piVar5 = (int *)plStack_368[0x20000f];
      if ((uint)((int)piStack_330 + *(int *)(pcStack_350 + *(longlong *)(piVar5 + 4) + 8)) <=
          (uint)piStack_348) goto code_r0x004877e2;
      uStack_240 = 1;
      FUN_00943830(plStack_358);
      piVar5 = (int *)plStack_368[0x20000f];
      piStack_330 = *(int **)(pcStack_350 + *(longlong *)(piVar5 + 4) + 0x10);
      piStack_328 = piVar5;
      if ((int *)plStack_368[0x20004d] == piStack_330) {
code_r0x00487c21:
        uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)uStack_360 + 1);
        goto code_r0x004877e7;
      }
      if (piStack_330[0x16] == uStack_320) {
        if (((iStack_178 != *piStack_330) || (iStack_174 != piStack_330[1])) ||
           (iStack_170 != piStack_330[2])) goto code_r0x00487c21;
        if ((iStack_16c != piStack_330[3]) || (iStack_168 != piStack_330[4])) goto code_r0x00487900;
        cVar3 = FUN_0047c330(piStack_330,piStack_310);
        if (cVar3 == '\0') {
          uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)uStack_360 + 1);
          piVar5 = piStack_328;
        }
        else {
          uStack_240 = 1;
          FUN_00943830(plStack_358);
          uStack_240 = 1;
          uVar10 = *(uint *)(pcStack_350 + *(longlong *)(plStack_368[0x20000f] + 0x10) + 4);
          if ((uint)piStack_348 <=
              *(uint *)(pcStack_350 + *(longlong *)(plStack_368[0x20000f] + 0x10) + 4)) {
            uVar10 = (uint)piStack_348;
          }
          piStack_328 = (int *)CONCAT44(piStack_328._4_4_,uVar10);
          FUN_00943830(plStack_358);
          piVar5 = (int *)plStack_368[0x20000f];
          uVar10 = ((uint)(*(int *)(pcStack_350 + *(longlong *)(piVar5 + 4) + 4) - (int)piStack_328)
                   % uStack_320) * 8;
          uVar7 = uVar10 / uStack_31c;
          if (uVar10 % uStack_31c != 0) goto code_r0x004882d0;
          uVar10 = (((uint)piStack_348 - (int)piStack_328) % uStack_320) * 8;
          uVar11 = uVar10 / uStack_31c;
          if (uVar10 % uStack_31c == 0) {
            iVar4 = 0;
            if (uStack_320 < (piStack_330[0x17] + uVar7) * uStack_31c + 7 >> 3) {
              iVar4 = uStack_320 - (uVar7 * uStack_31c >> 3);
            }
            if (uStack_320 < uStack_31c * (*(int *)(plStack_368[0x20004d] + 0x5c) + uVar11) + 7 >> 3
               ) {
              iVar4 = uStack_320 - (uVar11 * uStack_31c >> 3);
            }
            uVar10 = (int)piStack_328 - iVar4;
            piStack_328 = (int *)CONCAT44(piStack_328._4_4_,uVar10);
            if (uVar10 < 0x300000) {
              uStack_240 = 1;
              FUN_00943830(plStack_358);
              piVar5 = (int *)plStack_368[0x20000f];
              uVar10 = ((uint)(*(int *)(pcStack_350 + *(longlong *)(piVar5 + 4) + 4) -
                              (int)piStack_328) % uStack_320) * 8;
              uVar7 = uVar10 / uStack_31c;
              if (uVar10 % uStack_31c == 0) {
                uVar10 = (((uint)piStack_348 - (int)piStack_328) % uStack_320) * 8;
                uVar11 = uVar10 / uStack_31c;
                if (uVar10 % uStack_31c == 0) {
                  uVar10 = piStack_330[0x17] + uVar7;
                  if (uStack_320 < uStack_31c * uVar10 + 7 >> 3) {
code_r0x004882d0:
                    uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)uStack_360 + 1);
                  }
                  else if (uStack_320 <
                           (*(int *)(plStack_368[0x20004d] + 0x5c) + uVar11) * uStack_31c + 7 >> 3)
                  {
                    uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)uStack_360 + 1);
                  }
                  else if (uVar11 < uVar10) {
                    uVar11 = uStack_2ec + uVar11;
                    if (uVar11 <= uVar7) goto code_r0x004882d0;
                    uStack_2ec = uVar10;
                    if (uVar10 <= uVar11) {
                      uStack_2ec = uVar11;
                    }
                    uVar10 = ((uint)piStack_348 - (int)piStack_328) / uStack_320 + uStack_2e0;
                    uStack_2e0 = (uint)(*(int *)(pcStack_350 + *(longlong *)(piVar5 + 4) + 4) -
                                       (int)piStack_328) / uStack_320 + piStack_330[0x18];
                    uStack_240 = 1;
                    if (uStack_2e0 <= uVar10) {
                      uStack_2e0 = uVar10;
                    }
                    iStack_33c = (uStack_2e0 - 1) * uStack_320 + (uStack_2ec * uStack_31c + 7 >> 3);
                    FUN_00943830(plStack_358);
                    FUN_009439e0(ppiStack_2e8,
                                 pcStack_350 + *(longlong *)(plStack_368[0x20000f] + 0x10));
                    piVar5 = (int *)plStack_368[0x20000f];
                    if (piVar5 == (int *)0x0) {
                      uStack_360 = (code *)((ulonglong)uStack_360._4_4_ << 0x20);
                      piStack_348 = (int *)CONCAT44(piStack_348._4_4_,(int)piStack_328);
                      goto code_r0x00487922;
                    }
                    if ((int)uStack_360 < *piVar5) {
                      FUN_00943830(plStack_358);
                      iVar4 = *(int *)plStack_368[0x20000f];
                      iVar8 = 1;
                      if (iVar4 <= (int)uStack_360) {
                        iVar8 = iVar4 - (int)uStack_360;
                      }
                      *(int *)plStack_368[0x20000f] = iVar4 - iVar8;
                      piVar5 = (int *)plStack_368[0x20000f];
                      if ((int)uStack_360 < *piVar5) {
                        lVar9 = ((longlong)ppiStack_338 + (longlong)iVar8) * 0x28;
                        do {
                          uStack_360._0_4_ = (int)uStack_360 + 1;
                          puVar1 = (undefined4 *)(*(longlong *)(piVar5 + 4) + lVar9);
                          puVar6 = (undefined4 *)
                                   (*(longlong *)(piVar5 + 4) + lVar9 + (longlong)iVar8 * -0x28);
                          lVar9 = lVar9 + 0x28;
                          *puVar6 = *puVar1;
                          puVar6[1] = puVar1[1];
                          puVar6[2] = puVar1[2];
                          *(undefined8 *)(puVar6 + 4) = *(undefined8 *)(puVar1 + 4);
                          puVar6[6] = puVar1[6];
                          puVar6[7] = puVar1[7];
                          *(undefined8 *)(puVar6 + 8) = *(undefined8 *)(puVar1 + 8);
                          piVar5 = (int *)plStack_368[0x20000f];
                        } while ((int)uStack_360 < *piVar5);
                        uStack_360 = (code *)((ulonglong)uStack_360._4_4_ << 0x20);
                        piStack_348 = (int *)CONCAT44(piStack_348._4_4_,(int)piStack_328);
                      }
                      else {
                        uStack_360 = (code *)((ulonglong)uStack_360._4_4_ << 0x20);
                        piStack_348 = (int *)CONCAT44(piStack_348._4_4_,(int)piStack_328);
                      }
                    }
                    else {
                      uStack_360 = (code *)((ulonglong)uStack_360._4_4_ << 0x20);
                      piStack_348 = (int *)CONCAT44(piStack_348._4_4_,(int)piStack_328);
                    }
                  }
                  else {
                    uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)uStack_360 + 1);
                  }
                }
                else {
                  uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)uStack_360 + 1);
                }
                goto code_r0x004877e7;
              }
            }
            uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)uStack_360 + 1);
          }
          else {
            uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)uStack_360 + 1);
          }
        }
        goto code_r0x004877e7;
      }
code_r0x00487900:
      uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)uStack_360 + 1);
      if (piVar5 != (int *)0x0) goto code_r0x004877f0;
code_r0x00487922:
      if (-1 < (int)uStack_360) break;
    } while( true );
  }
  if ((apiStack_1d8[0] != (int *)0x0) && (*apiStack_1d8[0] != 0)) {
    if ((char)uStack_2f0 == '\0') {
      if ((char)plStack_368[8] != '\0') {
        uStack_2d0 = (undefined4)plStack_368[0x200052];
        uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)plStack_368[0x20004c]);
        pcStack_350 = (code *)plStack_368[0x20004d];
        plStack_358 = (longlong *)
                      CONCAT44(plStack_358._4_4_,*(undefined4 *)((longlong)plStack_368 + 0x1000264))
        ;
        uStack_2c4 = *(undefined4 *)((longlong)plStack_368 + 0x100029c);
        ppiStack_338 = (int **)CONCAT44(ppiStack_338._4_4_,(int)plStack_368[0x20004e]);
        piStack_330 = (int *)CONCAT44(piStack_330._4_4_,
                                      *(undefined4 *)((longlong)plStack_368 + 0x1000274));
        uStack_2f0 = *(undefined4 *)((longlong)plStack_368 + 0x100027c);
        piStack_328 = (int *)CONCAT44(piStack_328._4_4_,(int)plStack_368[0x20004f]);
        uStack_2dc = *(undefined4 *)((longlong)plStack_368 + 0x1000284);
        ppiStack_2e8 = (int **)CONCAT44(ppiStack_2e8._4_4_,(int)plStack_368[0x200050]);
        uStack_2d8 = (undefined4)plStack_368[0x200051];
        uStack_2d4 = *(undefined4 *)((longlong)plStack_368 + 0x100028c);
        uStack_2cc = *(undefined4 *)((longlong)plStack_368 + 0x1000294);
        uStack_2c8 = (undefined4)plStack_368[0x200053];
        uStack_2c0 = (undefined4)plStack_368[0x200054];
        uStack_2bc = *(undefined4 *)((longlong)plStack_368 + 0x10002a4);
        uStack_2b4 = *(undefined4 *)((longlong)plStack_368 + 0x10002ac);
        uStack_2b8 = (undefined4)plStack_368[0x200055];
        uStack_2b0 = (undefined4)plStack_368[0x200056];
        lStack_2a8 = plStack_368[0x200057];
        uStack_268 = (undefined4)plStack_368[0x20005f];
        lStack_2a0 = plStack_368[0x200058];
        lStack_298 = plStack_368[0x200059];
        uStack_2ac = *(undefined4 *)((longlong)plStack_368 + 0x10002b4);
        uStack_264 = *(undefined4 *)((longlong)plStack_368 + 0x10002fc);
        lStack_290 = plStack_368[0x20005a];
        lStack_288 = plStack_368[0x20005b];
        lStack_280 = plStack_368[0x20005c];
        lStack_278 = plStack_368[0x20005d];
        lStack_270 = plStack_368[0x20005e];
        lStack_78 = plStack_368[0x200060];
        lStack_70 = plStack_368[0x200061];
        lStack_68 = plStack_368[0x200062];
        lStack_60 = plStack_368[0x200063];
        uStack_260 = (undefined4)plStack_368[0x200068];
        lStack_58 = plStack_368[0x200064];
        lStack_50 = plStack_368[0x200065];
        lStack_48 = plStack_368[0x200066];
        lStack_40 = plStack_368[0x200067];
        uStack_25c = *(undefined4 *)((longlong)plStack_368 + 0x1000344);
        uStack_254 = *(undefined4 *)((longlong)plStack_368 + 0x100034c);
        uStack_258 = (undefined4)plStack_368[0x200069];
        uStack_250 = (undefined4)plStack_368[0x20006a];
        uStack_1e0 = (undefined4)plStack_368[0x20006b];
        uStack_24c = *(undefined4 *)((longlong)plStack_368 + 0x1000354);
        uStack_1dc = *(undefined4 *)((longlong)plStack_368 + 0x100035c);
        uStack_240 = 1;
        FUN_00703e40(plStack_368,0);
        piVar5 = (int *)plStack_368[6];
        if ((piVar5 != (int *)0x0) && (*piVar5 != 0)) {
          if (piVar5[2] < 2) {
            *piVar5 = 0;
          }
          else {
            piVar5[2] = piVar5[2] + -1;
            plStack_368[6] = 0;
          }
        }
        *(int *)(plStack_368 + 0x20004c) = (int)uStack_360;
        *(int *)((longlong)plStack_368 + 0x1000264) = (int)plStack_358;
        plStack_368[0x20004d] = (longlong)pcStack_350;
        *(undefined4 *)(plStack_368 + 0x20004e) = ppiStack_338._0_4_;
        *(int *)((longlong)plStack_368 + 0x1000274) = (int)piStack_330;
        *(int *)(plStack_368 + 0x20004f) = (int)piStack_328;
        *(undefined4 *)((longlong)plStack_368 + 0x100027c) = uStack_2f0;
        *(undefined4 *)(plStack_368 + 0x200050) = ppiStack_2e8._0_4_;
        *(undefined4 *)((longlong)plStack_368 + 0x1000284) = uStack_2dc;
        *(undefined4 *)(plStack_368 + 0x200051) = uStack_2d8;
        *(undefined4 *)((longlong)plStack_368 + 0x100028c) = uStack_2d4;
        *(undefined4 *)(plStack_368 + 0x200052) = uStack_2d0;
        *(undefined4 *)((longlong)plStack_368 + 0x1000294) = uStack_2cc;
        *(undefined4 *)(plStack_368 + 0x200053) = uStack_2c8;
        *(undefined4 *)((longlong)plStack_368 + 0x100029c) = uStack_2c4;
        *(undefined4 *)(plStack_368 + 0x200054) = uStack_2c0;
        *(undefined4 *)((longlong)plStack_368 + 0x10002a4) = uStack_2bc;
        *(undefined4 *)(plStack_368 + 0x200055) = uStack_2b8;
        *(undefined4 *)((longlong)plStack_368 + 0x10002ac) = uStack_2b4;
        *(undefined4 *)(plStack_368 + 0x200056) = uStack_2b0;
        plStack_368[0x200057] = lStack_2a8;
        plStack_368[0x200058] = lStack_2a0;
        *(undefined4 *)((longlong)plStack_368 + 0x10002b4) = uStack_2ac;
        *(undefined4 *)(plStack_368 + 0x20005f) = uStack_268;
        *(undefined4 *)((longlong)plStack_368 + 0x10002fc) = uStack_264;
        plStack_368[0x200059] = lStack_298;
        plStack_368[0x20005a] = lStack_290;
        plStack_368[0x20005b] = lStack_288;
        plStack_368[0x20005c] = lStack_280;
        plStack_368[0x20005d] = lStack_278;
        plStack_368[0x20005e] = lStack_270;
        plStack_368[0x200060] = lStack_78;
        plStack_368[0x200061] = lStack_70;
        plStack_368[0x200062] = lStack_68;
        plStack_368[0x200063] = lStack_60;
        plStack_368[0x200064] = lStack_58;
        plStack_368[0x200065] = lStack_50;
        plStack_368[0x200066] = lStack_48;
        plStack_368[0x200067] = lStack_40;
        *(undefined4 *)(plStack_368 + 0x200068) = uStack_260;
        *(undefined4 *)((longlong)plStack_368 + 0x1000344) = uStack_25c;
        *(undefined4 *)(plStack_368 + 0x200069) = uStack_258;
        *(undefined4 *)((longlong)plStack_368 + 0x100034c) = uStack_254;
        *(undefined4 *)(plStack_368 + 0x20006a) = uStack_250;
        *(undefined4 *)((longlong)plStack_368 + 0x1000354) = uStack_24c;
        *(undefined4 *)(plStack_368 + 0x20006b) = uStack_1e0;
        *(undefined4 *)((longlong)plStack_368 + 0x100035c) = uStack_1dc;
      }
      if (((1 < (int)plStack_368[0x200019]) && ((int *)plStack_368[0xc] != (int *)0x0)) &&
         (*(int *)plStack_368[0xc] != 0)) {
        if (lStack_2f8 != 0) {
          *(undefined1 *)(lStack_2f8 + 0x4c) = 1;
        }
        uStack_240 = 1;
        (**(code **)(*plRam0000000000cf4050 + 0x88))(plRam0000000000cf4050,plStack_368 + 9,0);
        FUN_00943e90(plStack_368 + 0xc,0);
        FUN_00948300(plStack_368 + 0x20006c,0);
      }
    }
    uStack_240 = 1;
    (**(code **)(*plStack_368 + 0x50))(plStack_368,puStack_300);
    ppiStack_338 = apiStack_1d8;
    uStack_360 = (code *)((ulonglong)uStack_360 & 0xffffffff00000000);
    plStack_358 = (longlong *)0x0;
    do {
      if (apiStack_1d8[0] == (int *)0x0) {
        if (-1 < (int)uStack_360) goto code_r0x00487aa0;
      }
      else if (*apiStack_1d8[0] <= (int)uStack_360) goto code_r0x00487aa0;
      pcStack_350 = *(code **)(*plStack_368 + 0x50);
      uStack_240 = 1;
      FUN_00943830(ppiStack_338);
      (*pcStack_350)(plStack_368,(longlong)plStack_358 + *(longlong *)(apiStack_1d8[0] + 4));
      uStack_360 = (code *)CONCAT44(uStack_360._4_4_,(int)uStack_360 + 1);
      plStack_358 = plStack_358 + 5;
    } while( true );
  }
code_r0x00487bc5:
  iVar4 = *(int *)((longlong)plStack_368 + 0x1000274) * (int)plStack_368[0x20004f] * uStack_31c;
  if (iVar4 < 0) {
    iVar4 = iVar4 + 7;
  }
  plStack_368 = (longlong *)CONCAT44(plStack_368._4_4_,iVar4 >> 3);
  FUN_00943990(apiStack_1d8);
code_r0x0048768b:
  func_0x008ce550(puStack_318);
  return (ulonglong)plStack_368 & 0xffffffff;
code_r0x00487aa0:
  uStack_240 = 1;
  piStack_370 = piStack_310;
  uStack_378 = uStack_320;
  lStack_108 = FUN_0047d760(plStack_368,(ulonglong)piStack_348 & 0xffffffff,uStack_2ec,uStack_2e0);
  uStack_fc = 0;
  uStack_f8 = 0;
  plStack_118 = (longlong *)((longlong)piStack_348 << 0x20);
  plStack_368[0x20004d] = lStack_108;
  iVar4 = iStack_33c;
  if (0x2fffff < iStack_33c + -1 + (uint)piStack_348) {
    iVar4 = 0x300000 - (uint)piStack_348;
  }
  pcStack_110 = (code *)CONCAT44(pcStack_110._4_4_,iVar4);
  pcStack_1c0 = FUN_00489930;
  uStack_100 = 0x10001;
  uStack_1b8 = 0;
  plStack_1c8 = plStack_368;
  uStack_240 = 1;
  (**(code **)(*plStack_368 + 0x48))(plStack_368,pplStack_308,&plStack_1c8);
  uVar10 = *(int *)((longlong)plStack_368 + 0x10001fc) - (uint)piStack_348;
  *(uint *)((longlong)plStack_368 + 0x1000264) = uVar10 / uStack_320;
  *(uint *)(plStack_368 + 0x20004c) = ((uVar10 % uStack_320) * 8) / uStack_31c;
  goto code_r0x00487bc5;
}


