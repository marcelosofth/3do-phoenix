// FUN @ 0047c330 size=1
// callees: []

undefined8 FUN_0047c330(longlong param_1,longlong param_2)

{
  short *psVar1;
  int iVar2;
  longlong lVar3;
  
  iVar2 = *(int *)(param_2 + 0x14);
  if (iVar2 != *(int *)(param_1 + 0x14)) {
    return 0;
  }
  if (0 < iVar2) {
    if (*(short *)(param_2 + 0x18) != *(short *)(param_1 + 0x18)) {
      return 0;
    }
    lVar3 = 0;
    while (lVar3 != (ulonglong)(iVar2 - 1) * 2) {
      psVar1 = (short *)(param_2 + 0x1a + lVar3);
      lVar3 = lVar3 + 2;
      if (*psVar1 != *(short *)(param_1 + 0x18 + lVar3)) {
        return 0;
      }
    }
  }
  return 1;
}


