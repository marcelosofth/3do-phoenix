// FUN @ 00943e90 size=1
// callees: []

undefined8 * FUN_00943e90(undefined8 *param_1,char param_2)

{
  int *piVar1;
  
  piVar1 = (int *)*param_1;
  if ((piVar1 != (int *)0x0) && (*piVar1 != 0)) {
    if (piVar1[2] < 2) {
      if (param_2 == '\0') {
        *piVar1 = 0;
        return param_1;
      }
      FUN_00943c80(param_1);
    }
    else {
      piVar1[2] = piVar1[2] + -1;
      *param_1 = 0;
    }
  }
  return param_1;
}


