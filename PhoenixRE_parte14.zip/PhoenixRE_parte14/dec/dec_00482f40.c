// FUN @ 00482f40 size=1
// callees: []

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_00482f40(longlong param_1,longlong param_2)

{
  bool bVar1;
  uint uVar2;
  uint uVar3;
  uint *puVar4;
  int *piVar5;
  undefined8 uVar6;
  uint uVar7;
  longlong lVar8;
  int iVar9;
  byte bVar10;
  uint uVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  float *pfVar14;
  float *pfVar15;
  uint uVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  undefined1 uStack_131;
  undefined4 uStack_118;
  uint uStack_114;
  undefined4 uStack_110;
  float afStack_108 [24];
  undefined8 uStack_a8;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 uStack_48;
  
  uVar3 = *(uint *)(param_1 + 0x1000210);
  pfVar14 = afStack_108;
  for (lVar8 = 0xc; lVar8 != 0; lVar8 = lVar8 + -1) {
    pfVar14[0] = 0.0;
    pfVar14[1] = 0.0;
    pfVar14 = pfVar14 + 2;
  }
  puVar12 = &uStack_a8;
  puVar13 = puVar12;
  for (lVar8 = 0xc; lVar8 != 0; lVar8 = lVar8 + -1) {
    *puVar13 = 0;
    puVar13 = puVar13 + 1;
  }
  if ((uVar3 & 0x100) == 0) {
    uVar19 = *(uint *)(param_1 + 0x1000110);
    uVar7 = uVar19 & 0xffff;
    uVar2 = uVar19 >> 0x10;
    if (uVar7 == uVar2) {
code_r0x00483bc0:
      bVar10 = 0;
      goto code_r0x0048341a;
    }
    lVar8 = *(longlong *)(param_1 + 0x1000268);
    bVar10 = 0;
    bVar1 = false;
    if ((lVar8 == 0) || (bVar1 = false, -1 < *(int *)(lVar8 + 0x6c))) goto code_r0x00483421;
    bVar1 = true;
    bVar10 = (byte)(**(uint **)(lVar8 + 0x78) >> 0xf) & 1;
    if ((uVar3 & 0x400) != 0) goto code_r0x0048342a;
code_r0x00482fe2:
    uStack_64 = 0x3f800000;
    uVar17 = 0;
    uVar11 = 0;
    uStack_88 = 0x3f800000;
code_r0x00482ffd:
    uVar18 = uVar19 & 0x8000;
    if (uVar18 != 0) goto code_r0x0048300d;
code_r0x00483517:
    uStack_9c = 0;
  }
  else {
    uVar19 = *(uint *)(param_1 + 0x1000110);
    bVar10 = (byte)(uVar3 >> 7) & 1;
    uVar7 = uVar19 & 0xffff;
    uVar2 = uVar19 >> 0x10;
    if (uVar7 == uVar2) goto code_r0x00483bc0;
code_r0x0048341a:
    bVar1 = true;
    lVar8 = *(longlong *)(param_1 + 0x1000268);
code_r0x00483421:
    if ((uVar3 & 0x400) == 0) goto code_r0x00482fe2;
code_r0x0048342a:
    if ((uVar19 & 8) == 0) {
      uStack_88 = 0x3f800000;
    }
    if ((uVar2 & 8) == 0) {
      uStack_64 = 0x3f800000;
    }
    if ((uVar19 & 4) != 0) {
      uStack_94 = 0x3f800000;
    }
    if ((uVar2 & 4) != 0) {
      uStack_70 = 0x3f800000;
    }
    uVar16 = (int)uVar7 >> 4 & 3;
    uVar11 = (int)uVar7 >> 1 & 1;
    uVar17 = (int)uVar2 >> 1 & 1;
    if (uVar16 == 3) {
      uStack_a8._0_4_ = 1.0;
    }
    else {
      afStack_108[0] = (float)((double)uVar16 * _UNK_00b03100);
      afStack_108[1] = afStack_108[0];
      afStack_108[2] = afStack_108[0];
    }
    uVar16 = (int)uVar2 >> 4 & 3;
    if (uVar16 == 3) {
      uStack_84 = 0x3f800000;
      goto code_r0x00482ffd;
    }
    uStack_84 = 0;
    uVar18 = uVar19 & 0x8000;
    afStack_108[0xc] = (float)((double)uVar16 * _UNK_00b03100);
    afStack_108[0xd] = afStack_108[0xc];
    afStack_108[0xe] = afStack_108[0xc];
    if (uVar18 == 0) goto code_r0x00483517;
code_r0x0048300d:
    uStack_9c = 0x3f800000;
  }
  if ((uVar2 & 0x8000) == 0) {
    uStack_78 = 0;
  }
  else {
    uStack_78 = 0x3f800000;
  }
  afStack_108[5] = 0.125;
  uVar16 = (int)uVar7 >> 0xd & 3;
  afStack_108[8] = 1.0;
  if (uVar16 == 2) {
    uStack_a8._4_4_ = 0x3f800000;
    uStack_a0 = 0x3f800000;
  }
  else {
    if (uVar16 == 3) {
      uStack_a8._4_4_ = 0x3f800000;
    }
    else if (uVar16 == 1) {
      if ((lVar8 == 0) || (*(int *)(lVar8 + 0x6c) < 0)) {
        uStack_a8._4_4_ = 0x3e99999a;
      }
      else {
        uStack_a8._4_4_ = 0;
      }
    }
    else {
      uStack_a8._4_4_ = 0x3e99999a;
      afStack_108[5] = (float)((double)(((int)uVar7 >> 10 & 7U) + 1) * _UNK_00b03108);
    }
    uStack_a0 = 0;
    afStack_108[8] = (float)((double)((((int)uVar7 >> 8) - 1U & 3) + 1) * _UNK_00b03100);
  }
  afStack_108[0x11] = 0.125;
  uVar16 = (int)uVar2 >> 0xd & 3;
  afStack_108[0x14] = 1.0;
  if (uVar16 == 2) {
    uStack_80 = 0x3f800000;
    uStack_7c = 0x3f800000;
  }
  else {
    if (uVar16 == 3) {
      uStack_80 = 0x3f800000;
    }
    else if (uVar16 == 1) {
      if ((lVar8 == 0) || (*(int *)(lVar8 + 0x6c) < 0)) {
        uStack_80 = 0x3e99999a;
      }
      else {
        uStack_80 = 0;
      }
    }
    else {
      uStack_80 = 0x3e99999a;
      afStack_108[0x11] = (float)((double)(((int)uVar2 >> 10 & 7U) + 1) * _UNK_00b03108);
    }
    uStack_7c = 0;
    afStack_108[0x14] = (float)((double)((((int)uVar2 >> 8) - 1U & 3) + 1) * _UNK_00b03100);
  }
  afStack_108[0xb] = 0.0;
  uVar16 = (int)uVar7 >> 6 & 3;
  if (uVar16 == 2) {
    uStack_98 = 0x3f800000;
  }
  else if (uVar16 == 3) {
    uStack_98 = 0x3e99999a;
  }
  else {
    uStack_98 = 0;
    if (uVar16 == 1) {
      afStack_108[0xb] = (float)((double)((int)uVar7 >> 1 & 0x1f) * _UNK_00b03110);
    }
  }
  afStack_108[0x17] = 0.0;
  uVar7 = (int)uVar2 >> 6 & 3;
  if (uVar7 == 2) {
    uStack_74 = 0x3f800000;
  }
  else if (uVar7 == 3) {
    uStack_74 = 0x3e99999a;
  }
  else {
    uStack_74 = 0;
    if (uVar7 == 1) {
      afStack_108[0x17] = (float)((double)((int)uVar2 >> 1 & 0x1f) * _UNK_00b03110);
    }
  }
  if ((uVar3 & 0x800) == 0) {
    if (uVar11 == 0) {
      uStack_90 = 0x3f800000;
    }
    else {
      uStack_90 = 0x3e99999a;
    }
    if (uVar17 == 0) {
      uStack_6c = 0x3f800000;
    }
    else {
      uStack_6c = 0x3e99999a;
    }
  }
  else {
    uStack_6c = 0;
    uStack_90 = 0;
  }
  if ((uVar19 & 1) == 0) {
    uStack_8c = 0;
  }
  else {
    uStack_8c = 0x3f800000;
  }
  if ((uVar2 & 1) == 0) {
    uStack_68 = 0;
  }
  else {
    uStack_68 = 0x3f800000;
  }
  if (bVar1) {
    uStack_60 = 0;
    if (bVar10 != 0) goto code_r0x00483376;
code_r0x00483a64:
    uStack_5c = 0;
    if (lVar8 == 0) goto code_r0x00483a78;
code_r0x0048338a:
    uStack_58 = 0;
  }
  else {
    uStack_60 = 0x3f800000;
    if (bVar10 == 0) goto code_r0x00483a64;
code_r0x00483376:
    uStack_5c = 0x3f800000;
    if (lVar8 != 0) goto code_r0x0048338a;
code_r0x00483a78:
    if ((uVar3 & 0x20) == 0) {
      uStack_58 = 0x3e99999a;
    }
    else {
      uStack_58 = 0x3f800000;
    }
  }
  if ((uVar3 & 0x40) != 0) {
    uStack_54 = 0;
    if ((lVar8 != 0) && (*(int *)(lVar8 + 0x6c) < 0)) {
      if ((**(uint **)(lVar8 + 0x78) & 0x8000) == 0) {
        uStack_54 = 0x3f800000;
      }
      else {
        uStack_54 = 0x3f19999a;
      }
    }
    if (((uVar3 & 0x200) == 0) && ((*(byte *)(param_1 + 0x1000219) & 0x40) != 0)) {
      uVar3 = *(uint *)(param_1 + 0x1000100);
      uStack_131 = 0;
    }
    else {
      uVar3 = *(uint *)(param_1 + 0x1000100);
      if ((uVar3 & 0x8000000) == 0) {
        uStack_131 = 0;
      }
      else {
        uStack_54 = 0x3e99999a;
        uStack_131 = 1;
      }
    }
    goto code_r0x004835b3;
  }
  if (((uVar3 & 0x200) == 0) && ((*(byte *)(param_1 + 0x1000219) & 0x40) != 0)) {
    uVar3 = *(uint *)(param_1 + 0x1000100);
code_r0x004838c7:
    bVar10 = *(byte *)(param_1 + 0x1000135);
  }
  else {
    uVar3 = *(uint *)(param_1 + 0x1000100);
    if ((uVar3 & 0x8000000) == 0) goto code_r0x004838c7;
    bVar10 = *(byte *)(param_1 + 0x1000131);
  }
  if ((bVar10 & 0x80) == 0) {
    uStack_54 = 0x3f800000;
    uStack_131 = 0;
  }
  else {
    uStack_54 = 0x3f19999a;
    uStack_131 = 0;
  }
code_r0x004835b3:
  uStack_4c = 0;
  uStack_50 = 0;
  if ((uVar3 & 0x1000000) != 0) {
    if ((uVar18 != 0) || (uVar16 == 2)) {
      uStack_50 = 0x3f800000;
    }
    if (((uVar2 & 0x8000) != 0) || (uVar7 == 2)) {
      uStack_4c = 0x3f800000;
    }
  }
  if (-1 < (int)uVar3) {
    if ((uVar3 & 0x40000000) == 0) {
      uStack_54 = 0x3f800000;
    }
    else {
      uStack_54 = 0x3f19999a;
    }
  }
  *(undefined4 *)(param_2 + 0x20) = *(undefined4 *)(param_1 + 0x10000cc);
  uStack_118 = *(undefined4 *)(param_1 + 0x10000d0);
  if (*(undefined4 **)(param_2 + 0x28) == (undefined4 *)0x0) {
    uStack_114 = 0;
  }
  else {
    uStack_114 = **(undefined4 **)(param_2 + 0x28);
  }
  uStack_110 = 0x30018;
  afStack_108[3] = afStack_108[5];
  afStack_108[4] = afStack_108[5];
  afStack_108[6] = afStack_108[8];
  afStack_108[7] = afStack_108[8];
  afStack_108[9] = afStack_108[0xb];
  afStack_108[10] = afStack_108[0xb];
  afStack_108[0xf] = afStack_108[0x11];
  afStack_108[0x10] = afStack_108[0x11];
  afStack_108[0x12] = afStack_108[0x14];
  afStack_108[0x13] = afStack_108[0x14];
  afStack_108[0x15] = afStack_108[0x17];
  afStack_108[0x16] = afStack_108[0x17];
  FUN_009489e0(param_2 + 0x30,&uStack_118);
  puVar4 = *(uint **)(param_2 + 0x28);
  pfVar14 = afStack_108;
  do {
    while( true ) {
      if (puVar4 == (uint *)0x0) {
        puVar4 = (uint *)func_0x008ce288(0x18);
        uVar6 = func_0x008ce290(0x80);
        puVar4[1] = 0x20;
        *(undefined8 *)(puVar4 + 4) = uVar6;
        puVar4[2] = 1;
        *puVar4 = 0;
        *(uint **)(param_2 + 0x28) = puVar4;
      }
      if ((int)puVar4[2] < 2) break;
      uVar3 = *puVar4;
code_r0x00483672:
      uVar19 = uVar3 + 2 + (uVar3 + 1 >> 1);
      if (uVar19 < 0x20) {
        puVar4 = (uint *)func_0x008ce288(0x18);
        uVar19 = 0x20;
        lVar8 = 0x80;
      }
      else {
        puVar4 = (uint *)func_0x008ce288(0x18);
        lVar8 = -1;
        if ((ulonglong)(longlong)(int)uVar19 < 0x1fc0000000000001) {
          lVar8 = (longlong)(int)uVar19 * 4;
        }
      }
      lVar8 = func_0x008ce290(lVar8);
      puVar4[1] = uVar19;
      *(longlong *)(puVar4 + 4) = lVar8;
      puVar4[2] = 1;
      *puVar4 = uVar3 + 1;
      iVar9 = 0;
      if (**(int **)(param_2 + 0x28) != 0) {
        FUN_008de2d0(lVar8,*(undefined8 *)(*(int **)(param_2 + 0x28) + 4));
        lVar8 = *(longlong *)(puVar4 + 4);
        iVar9 = **(int **)(param_2 + 0x28);
      }
      *(float *)(lVar8 + (longlong)iVar9 * 4) = *pfVar14;
      if (*(longlong *)(param_2 + 0x28) != 0) {
        piVar5 = (int *)(*(longlong *)(param_2 + 0x28) + 8);
        *piVar5 = *piVar5 + -1;
        lVar8 = *(longlong *)(param_2 + 0x28);
        if (*(int *)(lVar8 + 8) == 0) {
          if (*(longlong *)(lVar8 + 0x10) != 0) {
            func_0x008ce278();
            lVar8 = *(longlong *)(param_2 + 0x28);
          }
          func_0x008ce280(lVar8);
        }
      }
      pfVar14 = pfVar14 + 1;
      *(uint **)(param_2 + 0x28) = puVar4;
      if (pfVar14 == (float *)&uStack_a8) goto code_r0x00483760;
    }
    uVar3 = *puVar4;
    if ((int)puVar4[1] <= (int)uVar3) goto code_r0x00483672;
    pfVar15 = pfVar14 + 1;
    *(float *)(*(longlong *)(puVar4 + 4) + (longlong)(int)uVar3 * 4) = *pfVar14;
    **(int **)(param_2 + 0x28) = **(int **)(param_2 + 0x28) + 1;
    puVar4 = *(uint **)(param_2 + 0x28);
    pfVar14 = pfVar15;
  } while (pfVar15 != (float *)&uStack_a8);
code_r0x00483760:
  uStack_118 = *(undefined4 *)(param_1 + 0x10000d4);
  if (puVar4 == (uint *)0x0) {
    uStack_114 = 0;
  }
  else {
    uStack_114 = *puVar4;
  }
  uStack_110 = 0x10018;
  FUN_009489e0(param_2 + 0x30,&uStack_118);
  do {
    piVar5 = *(int **)(param_2 + 0x28);
    if (piVar5 == (int *)0x0) {
      piVar5 = (int *)func_0x008ce288(0x18);
      uVar6 = func_0x008ce290(0x80);
      piVar5[1] = 0x20;
      *(undefined8 *)(piVar5 + 4) = uVar6;
      piVar5[2] = 1;
      *piVar5 = 0;
      *(int **)(param_2 + 0x28) = piVar5;
    }
    if (piVar5[2] < 2) {
      iVar9 = *piVar5;
      if (piVar5[1] <= iVar9) goto code_r0x004837b2;
      *(undefined4 *)(*(longlong *)(piVar5 + 4) + (longlong)iVar9 * 4) = *(undefined4 *)puVar12;
      **(int **)(param_2 + 0x28) = **(int **)(param_2 + 0x28) + 1;
    }
    else {
      iVar9 = *piVar5;
code_r0x004837b2:
      uVar3 = iVar9 + 2 + (iVar9 + 1U >> 1);
      if (uVar3 < 0x20) {
        uVar3 = 0x20;
        puVar4 = (uint *)func_0x008ce288(0x18);
        lVar8 = 0x80;
      }
      else {
        puVar4 = (uint *)func_0x008ce288(0x18);
        lVar8 = -1;
        if ((ulonglong)(longlong)(int)uVar3 < 0x1fc0000000000001) {
          lVar8 = (longlong)(int)uVar3 * 4;
        }
      }
      lVar8 = func_0x008ce290(lVar8);
      puVar4[1] = uVar3;
      *(longlong *)(puVar4 + 4) = lVar8;
      puVar4[2] = 1;
      *puVar4 = iVar9 + 1U;
      iVar9 = 0;
      if (**(int **)(param_2 + 0x28) != 0) {
        FUN_008de2d0(lVar8,*(undefined8 *)(*(int **)(param_2 + 0x28) + 4));
        lVar8 = *(longlong *)(puVar4 + 4);
        iVar9 = **(int **)(param_2 + 0x28);
      }
      *(undefined4 *)(lVar8 + (longlong)iVar9 * 4) = *(undefined4 *)puVar12;
      if (*(longlong *)(param_2 + 0x28) != 0) {
        piVar5 = (int *)(*(longlong *)(param_2 + 0x28) + 8);
        *piVar5 = *piVar5 + -1;
        lVar8 = *(longlong *)(param_2 + 0x28);
        if (*(int *)(lVar8 + 8) == 0) {
          if (*(longlong *)(lVar8 + 0x10) != 0) {
            func_0x008ce278();
            lVar8 = *(longlong *)(param_2 + 0x28);
          }
          func_0x008ce280(lVar8);
        }
      }
      *(uint **)(param_2 + 0x28) = puVar4;
    }
    puVar12 = (undefined8 *)((longlong)puVar12 + 4);
    if (puVar12 == &uStack_48) {
      return uStack_131;
    }
  } while( true );
}


