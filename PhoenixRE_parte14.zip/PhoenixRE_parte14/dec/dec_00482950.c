// FUN @ 00482950 size=1
// callees: []

int FUN_00482950(longlong param_1)

{
  bool bVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  int iStack_c8;
  int iStack_c4;
  int iStack_b8;
  int iStack_b4;
  int iStack_a8;
  int iStack_a4;
  int iStack_98;
  int iStack_94;
  int iStack_88;
  int iStack_84;
  int iStack_78;
  int iStack_74;
  int iStack_70;
  int iStack_6c;
  int iStack_68;
  int iStack_64;
  int aiStack_58 [8];
  
  uVar8 = *(uint *)(param_1 + 0x1000110);
  uVar7 = uVar8 >> 0x10;
  uVar10 = *(uint *)(param_1 + 0x1000100) & 0x1000000;
  uVar3 = (int)(uVar8 & 0xffff) >> 6;
  if (uVar10 == 0) {
    bVar1 = false;
    if ((uVar3 & 3) == 2) goto code_r0x00482c0b;
code_r0x0048299c:
    if ((uVar8 & 0x8000) != 0) {
      bVar1 = true;
    }
  }
  else {
    uVar3 = uVar3 & 3;
    if ((uVar8 & 0x8000) != 0) {
      bVar1 = true;
      if (uVar3 != 2) goto code_r0x0048299c;
code_r0x00482c0b:
      bVar1 = true;
      goto code_r0x0048299c;
    }
    bVar1 = false;
    if (uVar3 == 2) goto code_r0x00482c0b;
  }
  if (uVar10 == 0) {
    if (((int)uVar7 >> 6 & 3U) == 2) goto code_r0x00482bdf;
  }
  else {
    uVar8 = (int)uVar7 >> 6 & 3;
    if ((uVar7 & 0x8000) == 0) {
      if (uVar8 != 2) goto code_r0x004829cf;
    }
    else {
      bVar1 = true;
      if (uVar8 != 2) goto code_r0x004829c5;
    }
code_r0x00482bdf:
    bVar1 = true;
  }
code_r0x004829c5:
  if ((uVar7 & 0x8000) != 0) {
    bVar1 = true;
  }
code_r0x004829cf:
  uVar8 = *(byte *)(param_1 + 0x1000217) & 0xf;
  iVar6 = 0;
  if ((int)uVar8 < *(int *)(param_1 + 0x1000278)) {
    iVar6 = *(int *)(param_1 + 0x1000278) - uVar8;
    piVar4 = aiStack_58;
    do {
      piVar4[1] = 0;
      piVar5 = piVar4 + 2;
      *piVar4 = 0;
      piVar4 = piVar5;
    } while (piVar5 != (int *)&stack0xffffffffffffffc8);
    iStack_c4 = (int)*(double *)(param_1 + 0x10002f0);
    iStack_c8 = (int)*(double *)(param_1 + 0x10002e8);
    iStack_b4 = iStack_c4 + (*(int *)(param_1 + 0x10002a4) * iVar6 >> 0x10);
    iVar9 = *(int *)(param_1 + 0x1000274);
    iStack_b8 = iStack_c8 + (*(int *)(param_1 + 0x10002a0) * iVar6 >> 0x10);
    aiStack_58[6] = iStack_c8 + (*(int *)(param_1 + 0x10002a8) * iVar9 >> 0x10);
    iStack_a8 = ((*(int *)(param_1 + 0x1000298) * iVar9 + *(int *)(param_1 + 0x10002a0)) * iVar6 >>
                0x10) + aiStack_58[6];
    aiStack_58[7] = (*(int *)(param_1 + 0x10002ac) * iVar9 >> 0x10) + iStack_c4;
    iStack_a4 = ((*(int *)(param_1 + 0x100029c) * iVar9 + *(int *)(param_1 + 0x10002a4)) * iVar6 >>
                0x10) + aiStack_58[7];
    aiStack_58[0] = iStack_c8;
    aiStack_58[1] = iStack_c4;
    aiStack_58[2] = iStack_b8;
    aiStack_58[3] = iStack_b4;
    aiStack_58[4] = iStack_a8;
    aiStack_58[5] = iStack_a4;
    iVar2 = FUN_004821b0(param_1,&iStack_c8,&iStack_b8,&iStack_a8,0);
    iStack_78 = aiStack_58[4];
    iStack_74 = aiStack_58[5];
    iStack_88 = aiStack_58[6];
    iStack_84 = aiStack_58[7];
    iStack_98 = aiStack_58[0];
    iStack_94 = aiStack_58[1];
    iVar6 = FUN_004821b0(param_1,&iStack_98,&iStack_88,&iStack_78,0);
    iVar2 = iVar2 + iVar6;
    iVar9 = 0;
    if ((*(int *)(param_1 + 0x10000e4) == 1) &&
       (((*(byte *)(param_1 + 0x1000347) & 4) == 0 ||
        (iVar9 = 0, (*(uint *)(param_1 + 0x100027c) & 0x180000) == 0)))) {
      iStack_78 = aiStack_58[0];
      iStack_74 = aiStack_58[1];
      iStack_70 = aiStack_58[6];
      iStack_6c = aiStack_58[7];
      iStack_68 = aiStack_58[4];
      iStack_64 = aiStack_58[5];
      uVar8 = FUN_008de650(&iStack_78,3);
      uVar3 = FUN_008de650(aiStack_58,3);
      iVar6 = ((((uVar8 ^ (int)uVar8 >> 0x1f) - ((int)uVar8 >> 0x1f)) +
               ((uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f))) - iVar2) * 2;
      iVar9 = 0;
      if (-1 < iVar6) {
        iVar9 = iVar6;
      }
    }
    iVar6 = iVar9 + iVar2 * 4;
    if (!bVar1) {
      iVar6 = iVar9 + iVar2 * 2;
    }
  }
  return iVar6;
}


