// FUN @ 004860d0 size=1
// callees: []

void FUN_004860d0(longlong *param_1,longlong param_2,undefined4 param_3,undefined4 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  uint *puVar3;
  double dVar4;
  double dVar5;
  char cVar6;
  int iVar7;
  undefined4 uVar8;
  undefined1 *puVar9;
  int *piVar10;
  longlong lVar11;
  undefined8 uVar12;
  uint uVar13;
  int iVar14;
  int iVar15;
  uint uVar16;
  uint *puVar17;
  int iStack_d4;
  int iStack_c8;
  uint uStack_b8;
  uint uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a8;
  undefined4 uStack_a4;
  uint uStack_a0;
  int iStack_9c;
  double dStack_98;
  double dStack_90;
  double dStack_88;
  
  iVar7 = (int)param_1[0x20004f];
  uVar13 = *(byte *)((longlong)param_1 + 0x1000217) & 0xf;
  if (iVar7 <= (int)uVar13) {
    return;
  }
  piVar10 = (int *)param_1[0xe];
  plVar1 = param_1 + 0xe;
  iVar15 = iVar7 - uVar13;
  if ((piVar10 != (int *)0x0) && (*piVar10 != 0)) {
    if (piVar10[2] < 2) {
      *piVar10 = 0;
    }
    else {
      piVar10[2] = piVar10[2] + -1;
      param_1[0xe] = 0;
    }
  }
  if ((int)param_1[0x200025] - 0x100000U < 0x200000) {
    (**(code **)(*param_1 + 0x68))(param_1,plVar1,(int)param_1[0x200025],0x10002,0);
  }
  if (((int *)param_1[0xe] == (int *)0x0) || (*(int *)param_1[0xe] == 0)) {
    iStack_c8 = 0;
    puVar17 = (uint *)0x0;
    iStack_d4 = 0;
  }
  else {
    FUN_00943830(plVar1);
    puVar17 = *(uint **)(*(longlong *)(param_1[0xe] + 0x10) + 0x10);
    (**(code **)(*param_1 + 0x78))(param_1,param_1,0x10100,puVar17);
    iVar14 = *(uint *)(param_1 + 0x200025) - *puVar17;
    lVar11 = CONCAT44(iVar14 >> 0x1f,iVar14 >> 1);
    iStack_c8 = (int)(lVar11 % (longlong)(int)(puVar17[1] * 2)) >> 1;
    iStack_d4 = ((int)(lVar11 / (longlong)(int)(puVar17[1] * 2)) * 2 -
                (uint)((*(uint *)(param_1 + 0x200025) & 2) == 0)) + (uint)((*puVar17 & 2) == 0);
  }
  if (param_1[0x20004d] == 0) {
    piVar10 = (int *)param_1[0xe];
    if ((piVar10 != (int *)0x0) && (*piVar10 != 0)) {
      if (piVar10[2] < 2) {
        *piVar10 = 0;
      }
      else {
        piVar10[2] = piVar10[2] + -1;
        param_1[0xe] = 0;
      }
    }
    if (*(int *)((longlong)param_1 + 0x10001fc) - 0x200000U < 0x100000) {
      (**(code **)(*param_1 + 0x68))
                (param_1,plVar1,*(int *)((longlong)param_1 + 0x10001fc),0x10002,0);
    }
    if (((int *)param_1[0xe] != (int *)0x0) && (*(int *)param_1[0xe] != 0)) {
      plVar2 = param_1 + 0xd;
      FUN_00943830(plVar1);
      puVar3 = *(uint **)(*(longlong *)(param_1[0xe] + 0x10) + 0x10);
      (**(code **)(*param_1 + 0x78))(param_1,param_1,0x10100,puVar3);
      uVar16 = puVar3[1];
      iVar7 = *(uint *)((longlong)param_1 + 0x10001fc) - *puVar3;
      lVar11 = CONCAT44(iVar7 >> 0x1f,iVar7 >> 1);
      iVar7 = ((int)(lVar11 / (longlong)(int)(uVar16 * 2)) * 2 -
              (uint)((*(uint *)((longlong)param_1 + 0x10001fc) & 2) == 0)) +
              (uint)((*puVar3 & 2) == 0);
      puVar9 = (undefined1 *)FUN_008eefc0(param_1 + 9);
      piVar10 = (int *)param_1[0xd];
      if ((piVar10 != (int *)0x0) && (*piVar10 != 0)) {
        if (piVar10[2] < 2) {
          *piVar10 = 0;
        }
        else {
          piVar10[2] = piVar10[2] + -1;
          param_1[0xd] = 0;
        }
      }
      uStack_b8 = puVar3[8];
      if ((*(int **)(puVar9 + 0x38) == (int *)0x0) || (**(int **)(puVar9 + 0x38) == 0)) {
        *puVar9 = 0;
        dStack_98 = (double)CONCAT44(dStack_98._4_4_,1);
        FUN_0094e670(puVar9 + 0x10,&dStack_98);
        FUN_0094e670(puVar9 + 0x18,&uStack_b8);
      }
      if (puVar17 == (uint *)0x0) {
        FUN_008fe5e0(puVar9,*(undefined4 *)(param_2 + 0x20));
      }
      else {
        FUN_008fe5e0(puVar9,puVar17[8]);
      }
      uStack_b4 = puVar3[8];
      if ((*(int **)(puVar9 + 0x38) == (int *)0x0) || (**(int **)(puVar9 + 0x38) == 0)) {
        *puVar9 = 0;
        dStack_98 = (double)CONCAT44(dStack_98._4_4_,1);
        FUN_0094e670(puVar9 + 0x10,&dStack_98);
        FUN_0094e670(puVar9 + 0x18,&uStack_b4);
      }
      FUN_00482f40(param_1,puVar9);
      FUN_00483c90(param_1,plVar2,param_3,param_4,iVar15);
      FUN_009485b0(plVar2);
      piVar10 = (int *)param_1[0xd];
      if ((piVar10 == (int *)0x0) || (*piVar10 == 0)) {
        uVar12 = 0;
      }
      else {
        uVar12 = *(undefined8 *)(piVar10 + 4);
      }
      cVar6 = FUN_00484b40(param_1,uVar12);
      if (cVar6 != '\0') {
        puVar9[1] = 1;
      }
      dStack_88 = 0.0;
      iVar14 = uVar13 + ((int)(lVar11 % (longlong)(int)(uVar16 * 2)) >> 1);
      dVar4 = (double)iVar14;
      dStack_98 = dVar4;
      dStack_90 = (double)iVar7;
      FUN_00948750(plVar2,&dStack_98);
      dVar5 = (double)(iVar14 + iVar15);
      dStack_88 = 0.0;
      dStack_98 = dVar5;
      dStack_90 = (double)iVar7;
      FUN_00948750(plVar2,&dStack_98);
      dStack_88 = 0.0;
      dStack_90 = (double)(*(int *)((longlong)param_1 + 0x1000274) + iVar7);
      dStack_98 = dVar5;
      FUN_00948750(plVar2,&dStack_98);
      dStack_88 = 0.0;
      dStack_90 = (double)(*(int *)((longlong)param_1 + 0x1000274) + iVar7);
      dStack_98 = dVar4;
      FUN_00948750(plVar2,&dStack_98);
      FUN_00483c90(param_1,plVar2,iStack_c8,iStack_d4,iVar15);
      FUN_009485b0(plVar2);
      FUN_00948750(plVar2,*(longlong *)(param_1[0xd] + 0x10) + 0x60);
      FUN_009485b0(plVar2);
      FUN_00948750(plVar2,*(longlong *)(param_1[0xd] + 0x10) + 0x78);
      FUN_009485b0(plVar2);
      FUN_00948750(plVar2,*(longlong *)(param_1[0xd] + 0x10) + 0x90);
      FUN_009485b0(plVar2);
      FUN_00948750(plVar2,*(longlong *)(param_1[0xd] + 0x10) + 0xa8);
      if (param_1[0x200051] != 0) {
        FUN_00484fd0(param_1,plVar2);
      }
      *(undefined4 *)(puVar9 + 8) = 8;
      iVar7 = (-(uint)((*(uint *)(param_1 + 0x200042) & 0x20000) == 0) & 3) + 8;
      *(int *)(puVar9 + 8) = iVar7;
      if ((*(byte *)((longlong)param_1 + 0x1000212) & 4) == 0) {
        iVar7 = 9;
      }
      *(int *)(puVar9 + 8) = iVar7;
      FUN_008fe160(puVar9,plVar2,1);
      return;
    }
    plVar1 = param_1 + 0xd;
    uVar8 = FUN_004857b0(param_1,*(undefined4 *)((longlong)param_1 + 0x10001fc),
                         (*(ushort *)((longlong)param_1 + 0x100021a) & 0x3ff) + 2,
                         (int)param_1[0x20004f],*(undefined4 *)((longlong)param_1 + 0x1000274));
    puVar9 = (undefined1 *)FUN_008eefc0(param_1 + 9);
    piVar10 = (int *)param_1[0xd];
    if ((piVar10 != (int *)0x0) && (*piVar10 != 0)) {
      if (piVar10[2] < 2) {
        *piVar10 = 0;
      }
      else {
        piVar10[2] = piVar10[2] + -1;
        param_1[0xd] = 0;
      }
    }
    uStack_b0 = uVar8;
    if ((*(int **)(puVar9 + 0x38) == (int *)0x0) || (**(int **)(puVar9 + 0x38) == 0)) {
      *puVar9 = 0;
      dStack_98 = (double)((ulonglong)dStack_98 & 0xffffffff00000000);
      FUN_0094e670(puVar9 + 0x10,&dStack_98);
      FUN_0094e670(puVar9 + 0x18,&uStack_b0);
    }
    if (puVar17 == (uint *)0x0) {
      FUN_008fe5e0(puVar9,*(undefined4 *)(param_2 + 0x20));
    }
    else {
      FUN_008fe5e0(puVar9,puVar17[8]);
    }
    uStack_ac = uVar8;
    if ((*(int **)(puVar9 + 0x38) == (int *)0x0) || (**(int **)(puVar9 + 0x38) == 0)) {
      *puVar9 = 0;
      dStack_98 = (double)((ulonglong)dStack_98 & 0xffffffff00000000);
      FUN_0094e670(puVar9 + 0x10,&dStack_98);
      FUN_0094e670(puVar9 + 0x18,&uStack_ac);
    }
    FUN_00482f40(param_1,puVar9);
    FUN_00483c90(param_1,plVar1,param_3,param_4,iVar15);
    FUN_009485b0(plVar1);
    piVar10 = (int *)param_1[0xd];
    if ((piVar10 == (int *)0x0) || (*piVar10 == 0)) {
      uVar12 = 0;
    }
    else {
      uVar12 = *(undefined8 *)(piVar10 + 4);
    }
    cVar6 = FUN_00484b40(param_1,uVar12);
    if (cVar6 != '\0') {
      puVar9[1] = 1;
    }
    dStack_90 = 0.0;
    dStack_88 = 0.0;
    dStack_98 = (double)uVar13;
    FUN_00948750(plVar1,&dStack_98);
    dStack_90 = 0.0;
    dStack_88 = 0.0;
    dStack_98 = (double)iVar7;
    FUN_00948750(plVar1,&dStack_98);
    dStack_90 = (double)*(int *)((longlong)param_1 + 0x1000274);
    dStack_88 = 0.0;
    dStack_98 = (double)iVar7;
    FUN_00948750(plVar1,&dStack_98);
    dStack_90 = (double)*(int *)((longlong)param_1 + 0x1000274);
    dStack_88 = 0.0;
    dStack_98 = (double)uVar13;
    FUN_00948750(plVar1,&dStack_98);
    FUN_00483c90(param_1,plVar1,iStack_c8,iStack_d4,iVar15);
    FUN_009485b0(plVar1);
    FUN_00948750(plVar1,*(longlong *)(param_1[0xd] + 0x10) + 0x60);
    FUN_009485b0(plVar1);
    FUN_00948750(plVar1,*(longlong *)(param_1[0xd] + 0x10) + 0x78);
    FUN_009485b0(plVar1);
    FUN_00948750(plVar1,*(longlong *)(param_1[0xd] + 0x10) + 0x90);
    FUN_009485b0(plVar1);
    FUN_00948750(plVar1,*(longlong *)(param_1[0xd] + 0x10) + 0xa8);
    if (param_1[0x200051] != 0) {
      FUN_00484fd0(param_1,plVar1);
    }
    *(undefined4 *)(puVar9 + 8) = 0xc;
    iVar7 = (-(uint)((*(uint *)(param_1 + 0x200042) & 0x20000) == 0) & 3) + 0xc;
    *(int *)(puVar9 + 8) = iVar7;
    if ((*(byte *)((longlong)param_1 + 0x1000212) & 4) == 0) {
      iVar7 = 0xd;
    }
    *(int *)(puVar9 + 8) = iVar7;
    FUN_008fe160(puVar9,plVar1,1);
    plVar1 = plRam0000000000cf4050;
    *(undefined1 *)(param_2 + 0x4c) = 1;
    (**(code **)(*plVar1 + 0x88))(plVar1,param_1 + 9,0);
    FUN_00943e90(param_1 + 0xc,0);
    FUN_00948300(param_1 + 0x20006c,0);
    return;
  }
  plVar1 = param_1 + 0xd;
  FUN_00481320(param_1);
  puVar9 = (undefined1 *)FUN_008eefc0(param_1 + 9);
  piVar10 = (int *)param_1[0xd];
  if ((piVar10 != (int *)0x0) && (*piVar10 != 0)) {
    if (piVar10[2] < 2) {
      *piVar10 = 0;
    }
    else {
      piVar10[2] = piVar10[2] + -1;
      param_1[0xd] = 0;
    }
  }
  uStack_a8 = *(undefined4 *)(param_1[0x20004d] + 0x68);
  piVar10 = *(int **)(puVar9 + 0x38);
  if ((piVar10 == (int *)0x0) || (*piVar10 == 0)) {
    *puVar9 = 0;
    dStack_98 = (double)((ulonglong)dStack_98 & 0xffffffff00000000);
    FUN_0094e670(puVar9 + 0x10,&dStack_98);
    FUN_0094e670(puVar9 + 0x18,&uStack_a8);
    piVar10 = *(int **)(puVar9 + 0x38);
  }
  if (puVar17 == (uint *)0x0) {
    uStack_a4 = *(undefined4 *)(param_2 + 0x20);
    if ((piVar10 == (int *)0x0) || (*piVar10 == 0)) {
      *puVar9 = 0;
      dStack_98 = (double)CONCAT44(dStack_98._4_4_,1);
      FUN_0094e670(puVar9 + 0x10,&dStack_98);
      FUN_0094e670(puVar9 + 0x18,&uStack_a4);
    }
  }
  else {
    uStack_a0 = puVar17[8];
    if ((piVar10 == (int *)0x0) || (*piVar10 == 0)) {
      *puVar9 = 0;
      dStack_98 = (double)CONCAT44(dStack_98._4_4_,1);
      FUN_0094e670(puVar9 + 0x10,&dStack_98);
      FUN_0094e670(puVar9 + 0x18,&uStack_a0);
      lVar11 = param_1[0x20004d];
      iVar14 = *(int *)(lVar11 + 0x6c);
      iVar7 = iStack_9c;
      goto joined_r0x00486274;
    }
  }
  lVar11 = param_1[0x20004d];
  iVar14 = *(int *)(lVar11 + 0x6c);
  iVar7 = iStack_9c;
joined_r0x00486274:
  iStack_9c = iVar14;
  if ((-1 < iStack_9c) &&
     ((*(int **)(puVar9 + 0x38) == (int *)0x0 || (iVar7 = iStack_9c, **(int **)(puVar9 + 0x38) == 0)
      ))) {
    *puVar9 = 0;
    dStack_98 = (double)((ulonglong)dStack_98 & 0xffffffff00000000);
    FUN_0094e670(puVar9 + 0x10,&dStack_98);
    FUN_0094e670(puVar9 + 0x18,&iStack_9c);
    lVar11 = param_1[0x20004d];
    iVar7 = iStack_9c;
  }
  iStack_9c = iVar7;
  if (*(char *)(lVar11 + 100) == '\0') {
    cVar6 = FUN_00482f40(param_1,puVar9);
  }
  else {
    cVar6 = FUN_00482cf0();
  }
  if (cVar6 == '\0') {
    uVar16 = 8;
  }
  else {
    uVar16 = 0xc;
  }
  FUN_00483c90(param_1,plVar1,param_3,param_4,iVar15);
  FUN_009485b0(plVar1);
  piVar10 = (int *)param_1[0xd];
  if ((piVar10 == (int *)0x0) || (*piVar10 == 0)) {
    uVar12 = 0;
  }
  else {
    uVar12 = *(undefined8 *)(piVar10 + 4);
  }
  cVar6 = FUN_00484b40(param_1,uVar12);
  if (cVar6 != '\0') {
    puVar9[1] = 1;
  }
  if (*(int *)(param_1[0x20004d] + 0x70) == 1) {
    dStack_90 = (double)*(int *)((longlong)param_1 + 0x1000264);
    dStack_88 = 0.0;
    dStack_98 = (double)(int)((int)param_1[0x20004c] + uVar13);
    FUN_00948750(plVar1,&dStack_98);
    dStack_90 = (double)*(int *)((longlong)param_1 + 0x1000264);
    dStack_88 = 0.0;
    dStack_98 = (double)(int)((int)param_1[0x20004c] + uVar13 + iVar15);
    FUN_00948750(plVar1,&dStack_98);
    dStack_88 = 0.0;
    dStack_98 = (double)(int)((int)param_1[0x20004c] + uVar13 + iVar15);
    dStack_90 = (double)(*(int *)((longlong)param_1 + 0x1000264) +
                        *(int *)((longlong)param_1 + 0x1000274));
    FUN_00948750(plVar1,&dStack_98);
    dStack_88 = 0.0;
    dStack_98 = (double)(int)(uVar13 + (int)param_1[0x20004c]);
    dStack_90 = (double)(*(int *)((longlong)param_1 + 0x1000264) +
                        *(int *)((longlong)param_1 + 0x1000274));
    FUN_00948750(plVar1,&dStack_98);
  }
  else {
    dStack_88 = (double)*(int *)(param_1[0x20004d] + 0x70);
    dStack_90 = (double)*(int *)((longlong)param_1 + 0x1000264) * dStack_88;
    dStack_98 = (double)(int)((int)param_1[0x20004c] + uVar13) * dStack_88;
    dStack_88 = dStack_88 * 0.0;
    FUN_00948750(plVar1,&dStack_98);
    dStack_88 = (double)*(int *)(param_1[0x20004d] + 0x70);
    dStack_90 = (double)*(int *)((longlong)param_1 + 0x1000264) * dStack_88;
    dStack_98 = (double)(int)((int)param_1[0x20004c] + uVar13 + iVar15) * dStack_88;
    dStack_88 = dStack_88 * 0.0;
    FUN_00948750(plVar1,&dStack_98);
    dStack_88 = (double)*(int *)(param_1[0x20004d] + 0x70);
    dStack_90 = (double)(*(int *)((longlong)param_1 + 0x1000264) +
                        *(int *)((longlong)param_1 + 0x1000274)) * dStack_88;
    dStack_98 = (double)(int)((int)param_1[0x20004c] + uVar13 + iVar15) * dStack_88;
    dStack_88 = dStack_88 * 0.0;
    FUN_00948750(plVar1,&dStack_98);
    dStack_90 = (double)*(int *)(param_1[0x20004d] + 0x70);
    dStack_88 = dStack_90 * 0.0;
    dStack_98 = (double)(int)(uVar13 + (int)param_1[0x20004c]) * dStack_90;
    dStack_90 = (double)(*(int *)((longlong)param_1 + 0x1000264) +
                        *(int *)((longlong)param_1 + 0x1000274)) * dStack_90;
    FUN_00948750(plVar1,&dStack_98);
  }
  FUN_00483c90(param_1,plVar1,iStack_c8,iStack_d4,iVar15);
  if (-1 < *(int *)(param_1[0x20004d] + 0x6c)) {
    uVar16 = 0xc;
    FUN_009485b0(plVar1);
    FUN_00948750(plVar1,*(longlong *)(param_1[0xd] + 0x10) + 0x60);
    FUN_009485b0(plVar1);
    FUN_00948750(plVar1,*(longlong *)(param_1[0xd] + 0x10) + 0x78);
    FUN_009485b0(plVar1);
    FUN_00948750(plVar1,*(longlong *)(param_1[0xd] + 0x10) + 0x90);
    FUN_009485b0(plVar1);
    FUN_00948750(plVar1,*(longlong *)(param_1[0xd] + 0x10) + 0xa8);
  }
  if (param_1[0x200051] != 0) {
    FUN_00484fd0(param_1,plVar1);
  }
  *(uint *)(puVar9 + 8) = uVar16;
  uVar13 = *(uint *)(param_1 + 0x200042);
  if ((uVar13 & 0x20000) == 0) {
    *(uint *)(puVar9 + 8) = uVar16 | 3;
    uVar13 = *(uint *)(param_1 + 0x200042);
  }
  if ((uVar13 & 0x40000) == 0) {
    *(uint *)(puVar9 + 8) = uVar16 | 1;
  }
  if ((*(int *)(param_1[0x20004d] + 0x5c) == 1) && (*(int *)(param_1[0x20004d] + 0x60) == 1)) {
    FUN_008fe160(puVar9,plVar1,0);
  }
  else {
    FUN_008fe160(puVar9,plVar1,1);
  }
  return;
}


