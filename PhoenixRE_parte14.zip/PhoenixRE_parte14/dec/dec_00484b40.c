// FUN @ 00484b40 size=1
// callees: []

undefined8 FUN_00484b40(longlong param_1,double *param_2)

{
  longlong lVar1;
  longlong lVar2;
  char cVar3;
  double *pdVar4;
  undefined8 uVar5;
  double *pdVar6;
  int *piVar7;
  int iVar8;
  undefined8 uVar9;
  longlong lVar10;
  longlong lVar11;
  longlong lVar12;
  double adStack_88 [9];
  
  pdVar6 = adStack_88;
  do {
    pdVar6[1] = 0.0;
    pdVar4 = pdVar6 + 2;
    *pdVar6 = 0.0;
    pdVar6 = pdVar4;
  } while (pdVar4 != adStack_88 + 8);
  adStack_88[0] = *param_2;
  lVar2 = param_1 + 0x1000360;
  lVar10 = 0x10;
  lVar12 = 0x30;
  adStack_88[1] = param_2[1];
  iVar8 = 0;
  lVar11 = 0x20;
  adStack_88[2] = param_2[3];
  adStack_88[3] = param_2[4];
  adStack_88[4] = param_2[6];
  adStack_88[5] = param_2[7];
  adStack_88[6] = param_2[9];
  adStack_88[7] = param_2[10];
  piVar7 = *(int **)(param_1 + 0x1000360);
  do {
    if (piVar7 == (int *)0x0) {
      if (-1 < iVar8) {
code_r0x00484d50:
        uVar9 = 0;
code_r0x00484d52:
        uVar5 = FUN_00948390(lVar2,adStack_88);
        uVar5 = FUN_00948390(uVar5,adStack_88 + 2);
        uVar5 = FUN_00948390(uVar5,adStack_88 + 4);
        FUN_00948390(uVar5,adStack_88 + 6);
        return uVar9;
      }
    }
    else if (*piVar7 >> 2 <= iVar8) goto code_r0x00484d50;
    lVar1 = lVar10 + -0x10;
    FUN_00948170(lVar2);
    piVar7 = *(int **)(param_1 + 0x1000360);
    cVar3 = FUN_0047c7e0(adStack_88,lVar1 + *(longlong *)(piVar7 + 4));
    if (cVar3 == '\0') {
      FUN_00948170(lVar2);
      pdVar6 = (double *)(lVar1 + *(longlong *)(*(longlong *)(param_1 + 0x1000360) + 0x10));
      if (((int)*pdVar6 == (int)adStack_88[0]) && ((int)pdVar6[1] == (int)adStack_88[1])) {
        FUN_00948170(lVar2);
        pdVar6 = (double *)(lVar10 + *(longlong *)(*(longlong *)(param_1 + 0x1000360) + 0x10));
        if (((int)*pdVar6 != (int)adStack_88[2]) || ((int)pdVar6[1] != (int)adStack_88[3]))
        goto code_r0x00484caf;
        FUN_00948170(lVar2);
        pdVar6 = (double *)(lVar11 + *(longlong *)(*(longlong *)(param_1 + 0x1000360) + 0x10));
        if (((int)*pdVar6 != (int)adStack_88[4]) || ((int)pdVar6[1] != (int)adStack_88[5]))
        goto code_r0x00484caf;
        FUN_00948170(lVar2);
        pdVar6 = (double *)(lVar12 + *(longlong *)(*(longlong *)(param_1 + 0x1000360) + 0x10));
        if (((int)*pdVar6 != (int)adStack_88[6]) || ((int)pdVar6[1] != (int)adStack_88[7]))
        goto code_r0x00484caf;
      }
      else {
code_r0x00484caf:
        FUN_00948170(lVar2);
        pdVar6 = (double *)(lVar1 + *(longlong *)(*(longlong *)(param_1 + 0x1000360) + 0x10));
        if (((int)*pdVar6 == (int)adStack_88[4]) && ((int)pdVar6[1] == (int)adStack_88[5])) {
          FUN_00948170(lVar2);
          pdVar6 = (double *)(lVar10 + *(longlong *)(*(longlong *)(param_1 + 0x1000360) + 0x10));
          if (((int)*pdVar6 == (int)adStack_88[6]) && ((int)pdVar6[1] == (int)adStack_88[7])) {
            FUN_00948170(lVar2);
            pdVar6 = (double *)(lVar11 + *(longlong *)(*(longlong *)(param_1 + 0x1000360) + 0x10));
            if (((int)*pdVar6 == (int)adStack_88[0]) && ((int)pdVar6[1] == (int)adStack_88[1])) {
              FUN_00948170(lVar2);
              pdVar6 = (double *)(lVar12 + *(longlong *)(*(longlong *)(param_1 + 0x1000360) + 0x10))
              ;
              if (((int)*pdVar6 == (int)adStack_88[2]) && ((int)pdVar6[1] == (int)adStack_88[3]))
              goto code_r0x00484ea0;
            }
          }
        }
        cVar3 = FUN_00484390(param_1,iVar8,adStack_88,adStack_88 + 2,adStack_88 + 4);
        if ((cVar3 == '\0') &&
           (cVar3 = FUN_00484390(param_1,iVar8,adStack_88,adStack_88 + 4,adStack_88 + 6),
           cVar3 == '\0')) {
          piVar7 = *(int **)(param_1 + 0x1000360);
          goto code_r0x00484c22;
        }
      }
code_r0x00484ea0:
      uVar9 = 1;
      FUN_00948300(lVar2,0);
      goto code_r0x00484d52;
    }
code_r0x00484c22:
    iVar8 = iVar8 + 1;
    lVar10 = lVar10 + 0x40;
    lVar11 = lVar11 + 0x40;
    lVar12 = lVar12 + 0x40;
  } while( true );
}


