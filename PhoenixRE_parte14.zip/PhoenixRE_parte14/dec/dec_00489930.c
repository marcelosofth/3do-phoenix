// FUN @ 00489930 size=1
// callees: []

undefined8 FUN_00489930(longlong param_1,longlong param_2,char param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  
  if (param_3 != '\0') {
    uVar2 = 1;
    if ((*(int *)(param_1 + 0x10000ec) != 0) && (*(char *)(param_1 + 0x40) != '\0')) {
      FUN_009439e0(param_1 + 0x38);
      uVar2 = 0;
    }
    return uVar2;
  }
  lVar1 = *(longlong *)(param_2 + 0x10);
  if (*(char *)(lVar1 + 0x65) != '\0') {
    (**(code **)(*plRam0000000000cf4050 + 0x68))
              (plRam0000000000cf4050,*(undefined4 *)(lVar1 + 0x68));
    if (-1 < *(int *)(lVar1 + 0x6c)) {
      (**(code **)(*plRam0000000000cf4050 + 0x68))();
    }
  }
  if (*(longlong *)(lVar1 + 0x78) != 0) {
    func_0x008ce278();
  }
  func_0x008ce280(lVar1);
  return 1;
}


