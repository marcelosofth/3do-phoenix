// FUN @ 00483c90 size=1
// callees: []

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00483c90(longlong param_1,undefined8 param_2,int param_3,int param_4,int param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  double dVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  double dStack_b8;
  double dStack_b0;
  undefined8 uStack_a8;
  longlong alStack_98 [11];
  
  dVar4 = _UNK_00b03118;
  plVar5 = alStack_98;
  do {
    plVar5[1] = 0;
    plVar6 = plVar5 + 2;
    *plVar5 = 0;
    plVar5 = plVar6;
  } while (plVar6 != alStack_98 + 8);
  lVar11 = (longlong)*(int *)(param_1 + 0x1000274);
  iVar1 = *(int *)(param_1 + 0x1000290);
  iVar2 = *(int *)(param_1 + 0x10002ac);
  iVar3 = *(int *)(param_1 + 0x1000294);
  lVar10 = (longlong)param_5;
  alStack_98[0] = ((longlong)param_3 * 0x10000 + (longlong)*(int *)(param_1 + 0x10002b0)) * 0x10;
  alStack_98[1] = ((longlong)param_4 * 0x10000 + (longlong)*(int *)(param_1 + 0x10002b4)) * 0x10;
  lVar9 = *(int *)(param_1 + 0x10002a8) * lVar11 * 0x10 + alStack_98[0];
  lVar8 = iVar2 * lVar11 * 0x10 + alStack_98[1];
  lVar12 = iVar1 * lVar10 + alStack_98[0];
  lVar13 = (*(int *)(param_1 + 0x1000288) * lVar11 + (longlong)iVar1) * lVar10 + lVar9;
  lVar7 = lVar10 * iVar3 + alStack_98[1];
  lVar10 = lVar10 * (lVar11 * *(int *)(param_1 + 0x100028c) + (longlong)iVar3) + lVar8;
  alStack_98[2] = lVar12;
  alStack_98[3] = lVar7;
  alStack_98[4] = lVar13;
  alStack_98[5] = lVar10;
  alStack_98[6] = lVar9;
  alStack_98[7] = lVar8;
  if (*(longlong *)(param_1 + 0x1000288) == 0) {
    if (iVar1 == 0) {
      if (iVar3 != 0) goto code_r0x00483edd;
    }
    else if (iVar3 == 0) {
code_r0x00483edd:
      if (*(int *)(param_1 + 0x10002a8) == 0) {
        if (iVar2 != 0) goto code_r0x00483ef5;
      }
      else if (iVar2 == 0) {
code_r0x00483ef5:
        dStack_b8 = (double)(alStack_98[0] >> 0x14);
        uStack_a8 = 0;
        dStack_b0 = (double)(alStack_98[1] >> 0x14);
        FUN_00948750(param_2,&dStack_b8,alStack_98[0] >> 0x14,alStack_98[1] >> 0x14,lVar10);
        dStack_b8 = (double)(lVar12 >> 0x14);
        uStack_a8 = 0;
        dStack_b0 = (double)(lVar7 >> 0x14);
        FUN_00948750(param_2,&dStack_b8);
        dStack_b8 = (double)(lVar13 >> 0x14);
        uStack_a8 = 0;
        dStack_b0 = (double)(lVar10 >> 0x14);
        FUN_00948750(param_2,&dStack_b8);
        dStack_b8 = (double)(lVar9 >> 0x14);
        dStack_b0 = (double)(lVar8 >> 0x14);
        goto code_r0x00483e9d;
      }
    }
  }
  uStack_a8 = 0;
  dStack_b8 = (double)alStack_98[0] * _UNK_00b03118;
  dStack_b0 = (double)alStack_98[1] * _UNK_00b03118;
  FUN_00948750(param_2,&dStack_b8,alStack_98[0],alStack_98[1],lVar10);
  uStack_a8 = 0;
  dStack_b8 = (double)lVar12 * dVar4;
  dStack_b0 = (double)lVar7 * dVar4;
  FUN_00948750(param_2,&dStack_b8);
  uStack_a8 = 0;
  dStack_b8 = (double)lVar13 * dVar4;
  dStack_b0 = (double)lVar10 * dVar4;
  FUN_00948750(param_2,&dStack_b8);
  dStack_b8 = (double)lVar9 * dVar4;
  dStack_b0 = (double)lVar8 * dVar4;
code_r0x00483e9d:
  uStack_a8 = 0;
  FUN_00948750(param_2,&dStack_b8);
  return;
}


