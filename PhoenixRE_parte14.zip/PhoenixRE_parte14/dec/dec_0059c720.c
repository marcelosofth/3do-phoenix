// FUN @ 0059c720 size=1
// callees: []

uint FUN_0059c720(int *param_1,byte param_2)

{
  byte bVar1;
  byte bVar2;
  uint uVar3;
  int iVar5;
  longlong *plVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  code *pcVar4;
  
  uVar8 = 0x20;
  if ((param_2 < 0x21) && (uVar8 = 1, param_2 != 0)) {
    uVar8 = (uint)param_2;
  }
  param_1[3] = uVar8;
  uVar3 = 0;
  iVar9 = *param_1;
  uVar8 = param_1[3];
  if (iVar9 != 0) {
    iVar10 = param_1[2];
    iVar5 = 8 - iVar10;
    if (iVar5 <= (int)uVar8) {
      uVar3 = 0;
      if (iVar10 != 0) {
        iVar11 = param_1[1];
        if (*(longlong *)(param_1 + 4) == 0) {
          bVar2 = *(byte *)(param_1 + 10);
        }
        else {
          pcVar4 = *(code **)(param_1 + 6);
          plVar6 = (longlong *)(*(longlong *)(param_1 + 4) + *(longlong *)(param_1 + 8));
          if (((ulonglong)pcVar4 & 1) != 0) {
            pcVar4 = *(code **)(pcVar4 + *plVar6 + -1);
          }
          bVar2 = (*pcVar4)(plVar6,iVar9 + iVar11);
          iVar10 = param_1[2];
          iVar11 = param_1[1];
          iVar5 = 8 - iVar10;
        }
        bVar1 = (&UNK_00b11171)[iVar5];
        param_1[1] = iVar11 + 1;
        uVar8 = (uVar8 - 8) + iVar10;
        uVar3 = (uint)(bVar2 & bVar1);
      }
      if (7 < (int)uVar8) {
        iVar9 = param_1[1];
        uVar7 = uVar8;
        do {
          if (*(longlong *)(param_1 + 4) == 0) {
            bVar2 = *(byte *)(param_1 + 10);
          }
          else {
            pcVar4 = *(code **)(param_1 + 6);
            plVar6 = (longlong *)(*(longlong *)(param_1 + 4) + *(longlong *)(param_1 + 8));
            if (((ulonglong)pcVar4 & 1) != 0) {
              pcVar4 = *(code **)(pcVar4 + *plVar6 + -1);
            }
            bVar2 = (*pcVar4)(plVar6,*param_1 + iVar9);
            iVar9 = param_1[1];
          }
          uVar7 = uVar7 - 8;
          iVar9 = iVar9 + 1;
          uVar3 = (uint)bVar2 | uVar3 << 8;
          param_1[1] = iVar9;
        } while (7 < (int)uVar7);
        uVar8 = uVar8 & 7;
      }
      if (uVar8 != 0) {
        if (*(longlong *)(param_1 + 4) == 0) {
          bVar2 = *(byte *)(param_1 + 10);
        }
        else {
          pcVar4 = *(code **)(param_1 + 6);
          plVar6 = (longlong *)(*(longlong *)(param_1 + 4) + *(longlong *)(param_1 + 8));
          if (((ulonglong)pcVar4 & 1) != 0) {
            pcVar4 = *(code **)(pcVar4 + *plVar6 + -1);
          }
          bVar2 = (*pcVar4)(plVar6,param_1[1] + *param_1);
        }
        uVar3 = (int)(uint)bVar2 >> (8 - (byte)uVar8 & 0x1f) | uVar3 << ((byte)uVar8 & 0x1f);
      }
      param_1[2] = uVar8;
      return uVar3;
    }
    if (*(longlong *)(param_1 + 4) == 0) {
      bVar2 = *(byte *)(param_1 + 10);
    }
    else {
      pcVar4 = *(code **)(param_1 + 6);
      plVar6 = (longlong *)(*(longlong *)(param_1 + 4) + *(longlong *)(param_1 + 8));
      if (((ulonglong)pcVar4 & 1) != 0) {
        pcVar4 = *(code **)(pcVar4 + *plVar6 + -1);
      }
      bVar2 = (*pcVar4)(plVar6,iVar9 + param_1[1]);
      iVar10 = param_1[2];
      uVar8 = param_1[3];
      iVar5 = 8 - iVar10;
    }
    param_1[2] = iVar10 + uVar8;
    uVar3 = (uint)((&UNK_00b11171)[(int)uVar8] & bVar2 >> ((char)iVar5 - (char)uVar8 & 0x1fU));
  }
  return uVar3;
}


