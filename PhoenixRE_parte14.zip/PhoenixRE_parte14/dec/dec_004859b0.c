// FUN @ 004859b0 size=1
// callees: []

int FUN_004859b0(longlong *param_1)

{
  longlong *plVar1;
  int *piVar2;
  code *pcVar3;
  undefined8 *puVar4;
  char cVar5;
  undefined1 uVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  uint uVar10;
  int *piVar11;
  longlong lVar12;
  undefined8 uVar13;
  int iVar14;
  ulonglong uVar15;
  longlong lVar16;
  int iVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  int iVar21;
  uint uStack_108;
  int iStack_104;
  int iStack_100;
  longlong *plStack_f8;
  code *pcStack_f0;
  undefined8 uStack_e8;
  undefined4 uStack_d8;
  int iStack_d4;
  int iStack_d0;
  longlong lStack_c8;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined8 uStack_b8;
  int iStack_a8;
  int iStack_a4;
  int iStack_a0;
  int iStack_9c;
  int iStack_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  undefined8 uStack_88;
  undefined8 uStack_80;
  undefined8 uStack_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined8 uStack_60;
  undefined8 uStack_58;
  
  uStack_108 = *(uint *)((longlong)param_1 + 0x10001fc);
  *(undefined4 *)(param_1 + 0x20004c) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1000264) = 0;
  plVar1 = param_1 + 0x20000f;
  *(uint *)((longlong)param_1 + 0x1000274) =
       ((*(uint *)((longlong)param_1 + 0x1000214) & 0xffc0) >> 6) + 1;
  FUN_0047cd70(&iStack_a8,param_1);
  piVar11 = (int *)param_1[0x20000f];
  uVar19 = uStack_108;
  if ((piVar11 != (int *)0x0) && (*piVar11 != 0)) {
    if (piVar11[2] < 2) {
      *piVar11 = 0;
      uVar19 = *(uint *)((longlong)param_1 + 0x10001fc);
    }
    else {
      piVar11[2] = piVar11[2] + -1;
      uVar19 = *(uint *)((longlong)param_1 + 0x10001fc);
      param_1[0x20000f] = 0;
    }
  }
  (**(code **)(*param_1 + 0x68))(param_1,plVar1,uVar19,0x10001,0);
  piVar11 = (int *)param_1[0x20000f];
  if ((piVar11 != (int *)0x0) && (*piVar11 != 0)) {
    lVar16 = 0;
    for (iVar17 = 0; iVar17 < *piVar11; iVar17 = iVar17 + 1) {
      FUN_00943830(plVar1);
      piVar11 = (int *)param_1[0x20000f];
      if (*(int *)(*(longlong *)(piVar11 + 4) + 4 + lVar16) ==
          *(int *)((longlong)param_1 + 0x10001fc)) {
        FUN_00943830(plVar1);
        piVar11 = (int *)param_1[0x20000f];
        piVar2 = *(int **)(*(longlong *)(piVar11 + 4) + 0x10 + lVar16);
        param_1[0x20004d] = (longlong)piVar2;
        if (((((piVar2[0x16] == 0) && (piVar2[0x18] == *(int *)((longlong)param_1 + 0x1000274))) &&
             (iStack_a8 == *piVar2)) && ((iStack_a4 == piVar2[1] && (iStack_a0 == piVar2[2])))) &&
           ((iStack_9c == piVar2[3] &&
            ((iStack_98 == piVar2[4] && (cVar5 = FUN_0047c330(piVar2,&iStack_a8), cVar5 != '\0')))))
           ) {
          *(int *)(param_1 + 0x20004f) = piVar2[0x17];
          pcVar3 = *(code **)(*param_1 + 0x58);
          FUN_00943830(plVar1);
          (*pcVar3)(param_1,lVar16 + *(longlong *)(param_1[0x20000f] + 0x10));
          FUN_00943830(plVar1);
          return *(int *)(*(longlong *)(param_1[0x20000f] + 0x10) + 8 + lVar16);
        }
      }
      lVar16 = lVar16 + 0x28;
    }
  }
  uVar19 = *(uint *)(&UNK_00b030a0 + (ulonglong)(*(uint *)((longlong)param_1 + 0x1000214) & 7) * 4);
  if (*(int *)((longlong)param_1 + 0x1000274) < 1) {
    iStack_100 = 0;
  }
  else {
    iStack_100 = 0;
    uVar18 = uVar19 & 0xff;
    plVar1 = param_1 + 0x200045;
    iStack_104 = 0;
    uVar10 = uStack_108;
    do {
      *(uint *)(param_1 + 0x200045) = uVar10;
      *(undefined4 *)((longlong)param_1 + 0x100022c) = 0;
      *(undefined4 *)(param_1 + 0x200046) = 0;
      iVar17 = FUN_0059c720(plVar1,((7 < (int)uVar19) + '\x01') * '\b');
      uStack_108 = uVar10 + 8 + iVar17 * 4;
      iVar21 = iStack_104 * 0x800;
      iVar17 = 0;
code_r0x00485c22:
      do {
        iVar14 = iVar17;
        iVar7 = FUN_0059c720(plVar1,2);
        if (uStack_108 <= *(int *)((longlong)param_1 + 0x100022c) + uVar10) {
          FUN_0059c720(plVar1,6);
          break;
        }
        iVar8 = FUN_0059c720(plVar1,6);
        uVar20 = iVar8 + 1;
        iVar17 = iVar14;
        if (iVar7 == 1) {
          if (iVar8 != -1) {
            do {
              if (0x7ff < iVar17) break;
              uVar9 = FUN_0059c720(plVar1,uVar18);
              uVar9 = FUN_0047ca50(param_1,uVar9);
              iVar7 = iVar21 + iVar17;
              iVar17 = iVar17 + 1;
              *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0x78) = uVar9;
            } while ((uint)(iVar17 - iVar14) < uVar20);
          }
          goto code_r0x00485c22;
        }
        if (1 < iVar7) {
          if (iVar7 == 2) {
            if (iVar8 != -1) {
              do {
                if (0x7ff < iVar17) break;
                iVar7 = iVar21 + iVar17;
                iVar17 = iVar17 + 1;
                *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0x78) = 0x80000000;
              } while ((uint)(iVar17 - iVar14) < uVar20);
            }
          }
          else if (iVar7 == 3) {
            uVar9 = FUN_0059c720(plVar1,uVar18);
            uVar9 = FUN_0047ca50(param_1,uVar9);
            if (iVar8 != -1) {
              do {
                if (0x7ff < iVar17) break;
                iVar7 = iVar21 + iVar17;
                iVar17 = iVar17 + 1;
                *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0x78) = uVar9;
              } while ((uint)(iVar17 - iVar14) < uVar20);
            }
          }
          goto code_r0x00485c22;
        }
      } while (iVar7 != 0);
      iVar17 = iVar14;
      if (iVar14 < 0x800) {
        do {
          iVar7 = iVar21 + iVar17;
          iVar17 = iVar17 + 1;
          *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0x78) = 0x80000000;
        } while (iVar17 != 0x800);
      }
      if (iVar14 <= iStack_100) {
        iVar14 = iStack_100;
      }
      iStack_104 = iStack_104 + 1;
      uVar10 = uStack_108;
      iStack_100 = iVar14;
    } while (iStack_104 < *(int *)((longlong)param_1 + 0x1000274));
  }
  *(int *)(param_1 + 0x20004f) = iStack_100;
  lVar12 = func_0x008ce288(0x80);
  param_1[0x20004d] = lVar12;
  uVar15 = (ulonglong)(*(int *)((longlong)param_1 + 0x1000274) * (int)param_1[0x20004f]);
  lVar16 = -1;
  if (uVar15 < 0x1fc0000000000001) {
    lVar16 = uVar15 * 4;
  }
  uVar13 = func_0x008ce290(lVar16);
  *(undefined8 *)(lVar12 + 0x78) = uVar13;
  *(undefined4 *)(param_1[0x20004d] + 0x60) = *(undefined4 *)((longlong)param_1 + 0x1000274);
  *(int *)(param_1[0x20004d] + 0x5c) = (int)param_1[0x20004f];
  puVar4 = (undefined8 *)param_1[0x20004d];
  *puVar4 = CONCAT44(iStack_a4,iStack_a8);
  puVar4[1] = CONCAT44(iStack_9c,iStack_a0);
  puVar4[2] = CONCAT44(uStack_94,iStack_98);
  puVar4[3] = uStack_90;
  puVar4[4] = uStack_88;
  puVar4[5] = uStack_80;
  puVar4[6] = uStack_78;
  puVar4[7] = uStack_70;
  puVar4[8] = uStack_68;
  puVar4[9] = uStack_60;
  puVar4[10] = uStack_58;
  *(undefined4 *)(param_1[0x20004d] + 0x58) = 0;
  *(undefined1 *)(param_1[0x20004d] + 0x65) = 0;
  lVar16 = param_1[0x20004d];
  uVar6 = FUN_0047ccf0(param_1);
  *(undefined1 *)(lVar16 + 100) = uVar6;
  lStack_c8 = param_1[0x20004d];
  if (*(char *)(lStack_c8 + 100) == '\0') {
    if (0 < *(int *)((longlong)param_1 + 0x1000274)) {
      iVar17 = (int)param_1[0x20004f];
      iVar21 = 0;
      do {
        if (0 < iVar17) {
          iVar14 = 0;
          do {
            iVar7 = iVar21 * 0x800 + iVar14;
            iVar17 = iVar17 * iVar21 + iVar14;
            iVar14 = iVar14 + 1;
            *(undefined4 *)(*(longlong *)(lStack_c8 + 0x78) + (longlong)iVar17 * 4) =
                 *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0x78);
            iVar17 = (int)param_1[0x20004f];
            lStack_c8 = param_1[0x20004d];
          } while (iVar14 < iVar17);
        }
        iVar21 = iVar21 + 1;
      } while (iVar21 < *(int *)((longlong)param_1 + 0x1000274));
    }
  }
  else if (0 < *(int *)((longlong)param_1 + 0x1000274)) {
    iVar17 = (int)param_1[0x20004f];
    iVar21 = 0;
    do {
      if (0 < iVar17) {
        iVar14 = 0;
        do {
          lVar16 = *(longlong *)(lStack_c8 + 0x78);
          iVar17 = iVar17 * iVar21 + iVar14;
          iVar7 = iVar14 + iVar21 * 0x800;
          iVar14 = iVar14 + 1;
          uVar19 = *(uint *)((longlong)param_1 + (longlong)iVar7 * 4 + 0x78);
          uVar10 = FUN_0047d0d0(param_1,uVar19,0);
          *(uint *)(lVar16 + (longlong)iVar17 * 4) = uVar19 & 0x80000000 | uVar10;
          iVar17 = (int)param_1[0x20004f];
          lStack_c8 = param_1[0x20004d];
        } while (iVar14 < iVar17);
      }
      iVar21 = iVar21 + 1;
    } while (iVar21 < *(int *)((longlong)param_1 + 0x1000274));
  }
  uStack_d8 = 0;
  iStack_d4 = *(int *)((longlong)param_1 + 0x10001fc);
  uStack_bc = 0;
  uStack_b8 = 0;
  if (uStack_108 - 1 < 0x300000) {
    iStack_d0 = uStack_108 - iStack_d4;
  }
  else {
    iStack_d0 = 0x300000 - iStack_d4;
  }
  uStack_c0 = 0x10001;
  pcStack_f0 = FUN_00489930;
  uStack_e8 = 0;
  plStack_f8 = param_1;
  (**(code **)(*param_1 + 0x48))(param_1,&uStack_d8,&plStack_f8);
  return iStack_d0;
}


