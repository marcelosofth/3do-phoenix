// FUN @ 0047ef90 size=1
// callees: []

undefined8
FUN_0047ef90(longlong param_1,undefined4 param_2,int param_3,int param_4,undefined8 param_5,
            undefined8 param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
            undefined8 param_10)

{
  int iVar1;
  int iVar2;
  bool bVar3;
  int iVar4;
  undefined2 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  undefined8 uVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  int iVar17;
  uint uVar18;
  uint uVar19;
  int iVar20;
  int iVar21;
  uint uVar22;
  uint uVar23;
  int iStack_e4;
  int iStack_e0;
  int iStack_dc;
  int iStack_d0;
  int iStack_cc;
  int iStack_c8;
  int iStack_c4;
  int iStack_bc;
  int aiStack_68 [4];
  int aiStack_58 [6];
  
  iVar13 = (int)param_7._2_2_;
  iVar6 = (int)param_5._2_2_;
  uVar19 = param_4 >> 0x10;
  param_3 = param_3 >> 0x10;
  uVar22 = (uint)param_6._2_2_;
  uVar23 = (uint)param_8._2_2_;
  iVar14 = (int)param_9._2_2_;
  uVar15 = (uint)param_10._2_2_;
  if (((param_3 == iVar6) && (iVar6 == iVar13)) && (iVar13 == iVar14)) {
code_r0x0047f498:
    uVar10 = 0;
  }
  else {
    iVar7 = *(int *)(param_1 + 0x1000350) + 1;
    uVar8 = *(int *)(param_1 + 0x1000354) + 1;
    if (*(int *)(param_1 + 0x10002a0) < 0) {
      if (((-1 < *(int *)(param_1 + 0x1000298)) || (-1 < param_3)) ||
         ((-1 < iVar6 || ((-1 < iVar13 || (-1 < iVar14)))))) goto code_r0x0047f060;
    }
    else if ((*(int *)(param_1 + 0x10002a0) == 0) ||
            ((((*(int *)(param_1 + 0x1000298) < 1 || (param_3 < iVar7)) || (iVar6 < iVar7)) ||
             ((iVar13 < iVar7 || (iVar14 < iVar7)))))) {
code_r0x0047f060:
      if (*(int *)(param_1 + 0x10002a4) < 0) {
        if (((-1 < *(int *)(param_1 + 0x100029c)) || (-1 < param_4)) ||
           ((param_6._2_2_ >> 7 == 0 || ((param_8._2_2_ >> 7 == 0 || (-1 < (int)uVar15))))))
        goto code_r0x0047f090;
      }
      else if ((*(int *)(param_1 + 0x10002a4) == 0) ||
              ((((*(int *)(param_1 + 0x100029c) < 1 || ((int)uVar19 < (int)uVar8)) ||
                ((int)uVar22 < (int)uVar8)) ||
               (((int)uVar23 < (int)uVar8 || ((int)uVar15 < (int)uVar8)))))) {
code_r0x0047f090:
        uVar18 = uVar15;
        if ((int)uVar23 <= (int)uVar15) {
          uVar18 = uVar23;
        }
        if ((int)uVar22 < (int)uVar18) {
          uVar18 = uVar22;
        }
        if ((int)uVar19 < (int)uVar18) {
          uVar18 = uVar19;
        }
        uVar11 = uVar15;
        if ((int)uVar15 <= (int)uVar23) {
          uVar11 = uVar23;
        }
        if ((int)uVar11 < (int)uVar22) {
          uVar11 = uVar22;
        }
        if ((int)uVar11 < (int)uVar19) {
          uVar11 = uVar19;
        }
        uVar16 = 0;
        if (-1 < (int)uVar18) {
          uVar16 = uVar18;
        }
        if ((int)uVar8 < (int)uVar11) {
          uVar11 = uVar8;
        }
        if ((int)uVar16 < (int)uVar11) {
          iStack_bc = (iVar14 - param_3) * (uVar16 - uVar19);
          iStack_d0 = (param_3 - iVar14) * (uVar16 - uVar15);
          iStack_e4 = (iVar14 - iVar13) * (uVar16 - uVar23);
          iStack_c4 = (uVar16 - uVar15) * (iVar13 - iVar14);
          iStack_e0 = (uVar16 - uVar19) * (iVar6 - param_3);
          iStack_dc = (iVar13 - iVar6) * (uVar16 - uVar22);
          iStack_c8 = (uVar16 - uVar23) * (iVar6 - iVar13);
          uVar5 = 0;
          iStack_cc = (uVar16 - uVar22) * (param_3 - iVar6);
          uVar8 = 0xffffffff;
          do {
            bVar3 = (int)uVar16 < (int)uVar22;
            if (((int)uVar16 < (int)uVar19) || (!bVar3)) {
              uVar18 = 0;
              if ((int)uVar16 >= (int)uVar19 || (int)uVar22 > (int)uVar16) goto code_r0x0047f26e;
              uVar18 = 1;
              aiStack_58[0] = 0;
              aiStack_68[0] = iStack_cc / (int)(uVar19 - uVar22) + iVar6;
              if ((int)uVar16 < (int)uVar19 && (int)uVar22 <= (int)uVar16) goto code_r0x0047f27e;
code_r0x0047f574:
              if (!bVar3 || (int)uVar23 > (int)uVar16) goto code_r0x0047f2b7;
              uVar9 = uVar18 + 1;
              aiStack_58[(int)uVar18] = 0;
              aiStack_68[(int)uVar18] = iStack_c8 / (int)(uVar22 - uVar23) + iVar13;
              if (bVar3 && (int)uVar23 <= (int)uVar16) goto code_r0x0047f2c7;
code_r0x0047f5c0:
              uVar18 = uVar9;
              if (((int)uVar15 <= (int)uVar16) && ((int)uVar16 < (int)uVar23)) {
                uVar18 = uVar9 + 1;
                aiStack_58[(int)uVar9] = 0;
                aiStack_68[(int)uVar9] = iStack_c4 / (int)(uVar23 - uVar15) + iVar14;
              }
            }
            else {
              uVar18 = 1;
              aiStack_58[0] = 1;
              aiStack_68[0] = iStack_e0 / (int)(uVar22 - uVar19) + param_3;
code_r0x0047f26e:
              if ((int)uVar16 < (int)uVar22) goto code_r0x0047f574;
code_r0x0047f27e:
              if ((int)uVar23 <= (int)uVar16) goto code_r0x0047f574;
              aiStack_58[(int)uVar18] = 1;
              aiStack_68[(int)uVar18] = iStack_dc / (int)(uVar23 - uVar22) + iVar6;
              uVar18 = uVar18 + 1;
code_r0x0047f2b7:
              uVar9 = uVar18;
              if ((int)uVar16 < (int)uVar23) goto code_r0x0047f5c0;
code_r0x0047f2c7:
              if ((int)uVar15 <= (int)uVar16) goto code_r0x0047f5c0;
              aiStack_58[(int)uVar9] = 1;
              aiStack_68[(int)uVar9] = iStack_e4 / (int)(uVar15 - uVar23) + iVar13;
              uVar18 = uVar9 + 1;
            }
            if ((uVar18 & 1) == 0) {
              if (uVar18 != 0) goto code_r0x0047f343;
            }
            else {
              if (((int)uVar16 < (int)uVar15) || ((int)uVar19 <= (int)uVar16)) {
                if (((int)uVar16 < (int)uVar15) && ((int)uVar19 <= (int)uVar16)) {
                  aiStack_58[(int)uVar18] = 0;
                  aiStack_68[(int)uVar18] = iStack_bc / (int)(uVar15 - uVar19) + param_3;
                }
              }
              else {
                aiStack_58[(int)uVar18] = 1;
                aiStack_68[(int)uVar18] = iStack_d0 / (int)(uVar19 - uVar15) + iVar14;
              }
code_r0x0047f343:
              iVar4 = aiStack_58[3];
              iVar2 = aiStack_58[2];
              iVar1 = aiStack_58[0];
              iVar21 = aiStack_68[2];
              iVar17 = aiStack_68[0];
              if (aiStack_68[1] < aiStack_68[0]) {
                aiStack_68[0] = aiStack_68[1];
                aiStack_68[1] = iVar17;
                aiStack_58[0] = aiStack_58[1];
                aiStack_58[1] = iVar1;
              }
              iVar1 = aiStack_58[0];
              iVar17 = aiStack_68[0];
              iVar20 = (int)uVar16 >> 1;
              if (uVar18 == 3) {
                if (aiStack_68[2] < aiStack_68[1]) {
                  aiStack_68[2] = aiStack_68[1];
                  aiStack_68[1] = iVar21;
                  aiStack_58[2] = aiStack_58[1];
                  aiStack_58[1] = iVar2;
                  if (iVar21 < aiStack_68[0]) {
                    aiStack_68[0] = iVar21;
                    aiStack_68[1] = iVar17;
                    aiStack_58[0] = iVar2;
                    aiStack_58[1] = iVar1;
                  }
                }
                iVar17 = aiStack_68[2];
                iVar21 = aiStack_68[3];
                if (aiStack_68[3] < aiStack_68[2]) {
                  iVar1 = aiStack_58[3];
                  aiStack_68[2] = aiStack_68[3];
                  aiStack_58[3] = aiStack_58[2];
                  iVar2 = aiStack_68[1];
                  aiStack_58[2] = iVar4;
                  iVar21 = iVar17;
                  if (aiStack_68[3] < aiStack_68[1]) {
                    aiStack_68[2] = aiStack_68[1];
                    aiStack_58[2] = aiStack_58[1];
                    aiStack_68[1] = aiStack_68[3];
                    aiStack_58[1] = iVar1;
                    if (aiStack_68[3] < aiStack_68[0]) {
                      aiStack_68[1] = aiStack_68[0];
                      aiStack_58[1] = aiStack_58[0];
                      aiStack_68[0] = aiStack_68[3];
                      aiStack_58[0] = iVar1;
                    }
                  }
                }
                aiStack_68[3] = iVar21;
                uVar18 = *(uint *)(param_1 + 0x100027c);
                uVar9 = uVar18 & 0x40000;
                if (((uVar9 != 0) && (aiStack_58[2] == 0)) ||
                   (((uVar18 & 0x20000) != 0 && (aiStack_58[2] == 1)))) {
                  iVar17 = 0;
                  if (-1 < aiStack_68[2]) {
                    iVar17 = aiStack_68[2];
                  }
                  iVar21 = aiStack_68[3];
                  if (iVar7 <= aiStack_68[3]) {
                    iVar21 = iVar7;
                  }
                  if (iVar17 < iVar21) {
                    iVar1 = (uVar16 & 1) * 2;
                    uVar9 = uVar8;
                    do {
                      uVar8 = 0;
                      uVar12 = *(int *)(param_1 + 0x1000358) * iVar20 + iVar1 +
                               *(int *)(param_1 + 0x100034c) + iVar17 * 4;
                      if (uVar12 < 0x300000) {
                        uVar8 = (uint)*(ushort *)
                                       (*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar12 ^ 2)
                                       );
                      }
                      if (uVar9 != uVar8) {
                        uVar5 = FUN_0047d0d0(param_1,param_2,uVar8);
                      }
                      uVar9 = *(int *)(param_1 + 0x100035c) * iVar20 + iVar1 +
                              *(int *)(param_1 + 0x1000348) + iVar17 * 4;
                      if (uVar9 < 0x300000) {
                        *(undefined2 *)(*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar9 ^ 2))
                             = uVar5;
                        uVar18 = *(uint *)(param_1 + 0x100027c);
                      }
                      if ((uVar18 & 0x1000) != 0) goto code_r0x0047f498;
                      iVar17 = iVar17 + 1;
                      uVar9 = uVar8;
                    } while (iVar17 != iVar21);
                    uVar9 = uVar18 & 0x40000;
                  }
                }
              }
              else {
                uVar18 = *(uint *)(param_1 + 0x100027c);
                uVar9 = uVar18 & 0x40000;
              }
              if (((uVar9 != 0) && (aiStack_58[0] == 0)) ||
                 (((uVar18 & 0x20000) != 0 && (aiStack_58[0] == 1)))) {
                iVar17 = 0;
                if (-1 < aiStack_68[0]) {
                  iVar17 = aiStack_68[0];
                }
                iVar21 = aiStack_68[1];
                if (iVar7 <= aiStack_68[1]) {
                  iVar21 = iVar7;
                }
                if (iVar17 < iVar21) {
                  iVar1 = (uVar16 & 1) * 2;
                  uVar9 = uVar8;
                  do {
                    uVar8 = 0;
                    uVar12 = *(int *)(param_1 + 0x1000358) * iVar20 + iVar1 +
                             *(int *)(param_1 + 0x100034c) + iVar17 * 4;
                    if (uVar12 < 0x300000) {
                      uVar8 = (uint)*(ushort *)
                                     (*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar12 ^ 2));
                    }
                    if (uVar8 != uVar9) {
                      uVar5 = FUN_0047d0d0(param_1,param_2,uVar8);
                    }
                    uVar9 = *(int *)(param_1 + 0x100035c) * iVar20 + iVar1 +
                            *(int *)(param_1 + 0x1000348) + iVar17 * 4;
                    if (uVar9 < 0x300000) {
                      *(undefined2 *)(*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar9 ^ 2)) =
                           uVar5;
                      uVar18 = *(uint *)(param_1 + 0x100027c);
                    }
                    if ((uVar18 & 0x1000) != 0) goto code_r0x0047f498;
                    iVar17 = iVar17 + 1;
                    uVar9 = uVar8;
                  } while (iVar17 != iVar21);
                }
              }
            }
            uVar16 = uVar16 + 1;
            iStack_bc = iStack_bc + (iVar14 - param_3);
            iStack_d0 = iStack_d0 + (param_3 - iVar14);
            iStack_e4 = iStack_e4 + (iVar14 - iVar13);
            iStack_c4 = iStack_c4 + (iVar13 - iVar14);
            iStack_dc = iStack_dc + (iVar13 - iVar6);
            iStack_c8 = iStack_c8 + (iVar6 - iVar13);
            iStack_e0 = iStack_e0 + (iVar6 - param_3);
            iStack_cc = iStack_cc + (param_3 - iVar6);
          } while (uVar16 != uVar11);
        }
        goto code_r0x0047f498;
      }
    }
    uVar10 = 0xffffffff;
  }
  return uVar10;
}


