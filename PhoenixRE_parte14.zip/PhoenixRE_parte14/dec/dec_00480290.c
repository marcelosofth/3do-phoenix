// FUN @ 00480290 size=1
// callees: []

/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00480290(longlong param_1)

{
  float fVar1;
  double dVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  double dVar6;
  double dVar7;
  double dVar8;
  float fVar9;
  float fVar10;
  char cVar11;
  undefined2 uVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  uint uVar17;
  uint uVar18;
  int iVar19;
  double *pdVar20;
  double *pdVar21;
  float *pfVar22;
  float *pfVar23;
  float *pfVar24;
  longlong lVar25;
  uint uVar26;
  uint uVar27;
  uint uVar28;
  int iVar29;
  int iVar30;
  int iVar31;
  int iVar32;
  float fVar33;
  int iVar34;
  uint uVar35;
  int iVar36;
  int iVar37;
  int iVar38;
  double dVar39;
  double dVar40;
  double dVar41;
  double dVar42;
  double dVar43;
  double dVar44;
  int iStack_578;
  uint uStack_574;
  uint uStack_570;
  uint uStack_564;
  int iStack_560;
  undefined8 uStack_548;
  int iStack_540;
  uint uStack_53c;
  int iStack_538;
  uint uStack_534;
  int iStack_530;
  uint uStack_52c;
  double adStack_528 [8];
  undefined8 uStack_4e8;
  float fStack_4e0;
  float afStack_4dc [2];
  int iStack_4d4;
  float fStack_4d0;
  int iStack_4cc;
  float afStack_4c8 [24];
  float afStack_468 [224];
  float afStack_e8 [42];
  
  pdVar21 = adStack_528;
  do {
    pdVar21[1] = 0.0;
    pdVar20 = pdVar21 + 2;
    *pdVar21 = 0.0;
    pdVar21 = pdVar20;
  } while (pdVar20 != (double *)&uStack_4e8);
  iVar13 = *(int *)(param_1 + 0x1000278);
  fVar1 = (float)(*(byte *)(param_1 + 0x1000283) & 0xf);
  if ((int)fVar1 < iVar13) {
    iVar38 = iVar13 - (int)fVar1;
    if (*(longlong *)(param_1 + 0x1000288) == 0) {
      uVar28 = *(uint *)(param_1 + 0x10002a8);
      uVar17 = *(int *)(param_1 + 0x1000290) >> 0x1f;
      uVar35 = *(uint *)(param_1 + 0x10002ac);
      uVar27 = *(uint *)(param_1 + 0x1000290) ^ uVar17;
      uVar26 = *(int *)(param_1 + 0x1000294) >> 0x1f;
      uVar18 = *(uint *)(param_1 + 0x1000294) ^ uVar26;
      if (((uVar18 == uVar26) && (uVar27 - uVar17 == 0x100000)) ||
         ((uVar27 == uVar17 && (uVar18 - uVar26 == 0x100000)))) {
        uVar17 = (int)uVar28 >> 0x1f;
        uVar18 = (int)uVar35 >> 0x1f;
        if ((((uVar18 ^ uVar35) == uVar18) && ((uVar17 ^ uVar28) - uVar17 == 0x10000)) ||
           (((uVar17 ^ uVar28) == uVar17 && ((uVar18 ^ uVar35) - uVar18 == 0x10000)))) {
          uVar17 = *(uint *)(param_1 + 0x100027c) & 0x60000;
          if (uVar17 != 0x60000) {
            uVar18 = 0x40000;
            if (((*(double *)(param_1 + 0x10002d8) + *(double *)(param_1 + 0x10002c8)) *
                 (*(double *)(param_1 + 0x10002d0) - *(double *)(param_1 + 0x10002e0)) +
                *(double *)(param_1 + 0x10002d8) * *(double *)(param_1 + 0x10002e0)) -
                *(double *)(param_1 + 0x10002c8) * *(double *)(param_1 + 0x10002d0) < 0.0) {
              uVar18 = 0x20000;
            }
            if (uVar17 == uVar18) {
              return;
            }
          }
          pdVar21 = (double *)&uStack_548;
          do {
            *(undefined4 *)((longlong)pdVar21 + 4) = 0;
            pdVar20 = pdVar21 + 1;
            *(undefined4 *)pdVar21 = 0;
            pdVar21 = pdVar20;
          } while (pdVar20 != adStack_528);
          iVar34 = *(int *)(param_1 + 0x1000274);
          iVar29 = (int)*(short *)(param_1 + 0x10002b2);
          uVar17 = (uint)*(short *)(param_1 + 0x10002b6);
          iVar36 = *(short *)(param_1 + 0x10002a6) * iVar38;
          iVar38 = *(short *)(param_1 + 0x10002a2) * iVar38;
          iStack_530 = ((int)uVar28 >> 0x10) * iVar34 + iVar29;
          uStack_52c = ((int)uVar35 >> 0x10) * iVar34 + uVar17;
          uVar28 = uVar17 + iVar36;
          iVar19 = iVar29 + iVar38;
          iStack_538 = iVar38 + iStack_530;
          uStack_534 = iVar36 + uStack_52c;
          pfVar22 = (float *)&uStack_4e8;
          do {
            pfVar22[1] = 0.0;
            pfVar23 = pfVar22 + 2;
            *pfVar22 = 0.0;
            pfVar22 = pfVar23;
          } while (pfVar23 != afStack_4c8);
          fVar33 = (float)(iVar13 - 1);
          iVar34 = iVar34 + -1;
          uStack_4e8._4_4_ = 0;
          afStack_4dc[0] = 0.0;
          uStack_548._0_4_ = iVar29;
          uStack_548._4_4_ = uVar17;
          uStack_4e8._0_4_ = fVar1;
          afStack_4dc[1] = fVar33;
          iStack_4d4 = iVar34;
          if ((int)uStack_534 < (int)uVar17) {
            iStack_4d4 = 0;
            uStack_548._0_4_ = iStack_538;
            uStack_548._4_4_ = uStack_534;
            iStack_538 = iVar29;
            uStack_534 = uVar17;
            uStack_4e8._0_4_ = fVar33;
            uStack_4e8._4_4_ = iVar34;
            afStack_4dc[1] = fVar1;
          }
          iVar38 = iStack_4d4;
          fVar10 = afStack_4dc[1];
          fVar9 = (float)uStack_4e8;
          uVar17 = uStack_534;
          iVar13 = iStack_538;
          uVar35 = uStack_548._4_4_;
          iStack_540 = iVar19;
          uStack_53c = uVar28;
          fStack_4e0 = fVar33;
          fStack_4d0 = fVar1;
          iStack_4cc = iVar34;
          if ((int)uStack_52c < (int)uVar28) {
            iStack_4cc = 0;
            iStack_540 = iStack_530;
            uStack_53c = uStack_52c;
            iStack_530 = iVar19;
            uStack_52c = uVar28;
            fStack_4e0 = fVar1;
            afStack_4dc[0] = (float)iVar34;
            fStack_4d0 = fVar33;
          }
          fVar1 = afStack_4dc[0];
          iVar19 = (int)uStack_548;
          if (iStack_540 < (int)uStack_548) {
            uStack_548._4_4_ = uStack_53c;
            uStack_53c = uVar35;
            uStack_4e8._0_4_ = fStack_4e0;
            fStack_4e0 = fVar9;
            afStack_4dc[0] = (float)uStack_4e8._4_4_;
            uStack_4e8._4_4_ = (int)fVar1;
            iStack_538 = iStack_530;
            iStack_530 = iVar13;
            uStack_534 = uStack_52c;
            uStack_52c = uVar17;
            afStack_4dc[1] = fStack_4d0;
            fStack_4d0 = fVar10;
            iStack_4d4 = iStack_4cc;
            iStack_4cc = iVar38;
            iVar19 = iStack_540;
            iStack_540 = (int)uStack_548;
          }
          uStack_548._0_4_ = iVar19;
          iStack_578 = 0;
          if ((-1 < (int)uStack_548) &&
             (iStack_578 = *(int *)(param_1 + 0x1000350) + 1,
             (int)uStack_548 <= *(int *)(param_1 + 0x1000350))) {
            iStack_578 = (int)uStack_548;
          }
          iVar13 = 0;
          if ((-1 < iStack_540) &&
             (iVar13 = *(int *)(param_1 + 0x1000350) + 1,
             iStack_540 <= *(int *)(param_1 + 0x1000350))) {
            iVar13 = iStack_540;
          }
          if (iStack_578 == iVar13) {
            return;
          }
          uStack_574 = uStack_548._4_4_;
          if ((int)uStack_548._4_4_ < 0) {
            uStack_574 = 0;
            iVar38 = -uStack_548._4_4_;
          }
          else {
            iVar38 = 0;
            if (*(int *)(param_1 + 0x1000354) < (int)uStack_548._4_4_) {
              uStack_574 = *(int *)(param_1 + 0x1000354) + 1;
              iVar38 = uStack_574 - uStack_548._4_4_;
            }
          }
          uStack_570 = 0;
          if ((-1 < (int)uStack_52c) &&
             (uStack_570 = uStack_52c, *(int *)(param_1 + 0x1000354) < (int)uStack_52c)) {
            uStack_570 = *(int *)(param_1 + 0x1000354) + 1;
          }
          uVar28 = (uint)((int)(float)uStack_4e8 < (int)fStack_4e0);
          if ((int)fStack_4e0 < (int)(float)uStack_4e8) {
            uVar28 = 0xffffffff;
          }
          uVar35 = 0xffffffff;
          if (uStack_4e8._4_4_ <= (int)afStack_4dc[0]) {
            uVar35 = (uint)(uStack_4e8._4_4_ < (int)afStack_4dc[0]);
          }
          uVar17 = (uint)((int)(float)uStack_4e8 < (int)fStack_4d0);
          if ((int)fStack_4d0 < (int)(float)uStack_4e8) {
            uVar17 = 0xffffffff;
          }
          uVar18 = (uint)(uStack_4e8._4_4_ < iStack_4cc);
          if (iStack_4cc < uStack_4e8._4_4_) {
            uVar18 = 0xffffffff;
          }
          iStack_560 = (int)(float)uStack_4e8 + uVar17 * iVar38;
          iVar38 = uStack_4e8._4_4_ + iVar38 * uVar18;
          if (*(longlong *)(param_1 + 0x1000268) == 0) {
            if ((int)uStack_570 <= (int)uStack_574) {
              return;
            }
            uStack_564 = iVar38 + uVar35 * (iStack_578 - (int)uStack_548);
            iStack_560 = (iStack_578 - (int)uStack_548) * uVar28 + iStack_560;
            do {
              if (iStack_578 < iVar13) {
                iVar38 = (uStack_574 & 1) * 2;
                iVar19 = iStack_560;
                uVar26 = uStack_564;
                iVar34 = iStack_578;
                do {
                  uVar27 = ((int)uVar26 >> 1) * ((*(ushort *)(param_1 + 0x1000286) & 0x3ff) * 4 + 8)
                           + *(int *)(param_1 + 0x1000270) + iVar19 * 4 + (uVar26 & 1) * 2;
                  uVar12 = 0;
                  if (uVar27 < 0x300000) {
                    uVar12 = *(undefined2 *)
                              (*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar27 ^ 2));
                  }
                  iVar36 = FUN_0047ca50(param_1,uVar12);
                  if (-1 < iVar36) {
                    uVar12 = 0;
                    uVar27 = *(int *)(param_1 + 0x1000358) * ((int)uStack_574 >> 1) + iVar38 +
                             *(int *)(param_1 + 0x100034c) + iVar34 * 4;
                    if (uVar27 < 0x300000) {
                      uVar12 = *(undefined2 *)
                                (*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar27 ^ 2));
                    }
                    uVar12 = FUN_0047d0d0(param_1,iVar36,uVar12);
                    uVar27 = *(int *)(param_1 + 0x100035c) * ((int)uStack_574 >> 1) + iVar38 +
                             *(int *)(param_1 + 0x1000348) + iVar34 * 4;
                    if (uVar27 < 0x300000) {
                      *(undefined2 *)(*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar27 ^ 2))
                           = uVar12;
                    }
                  }
                  iVar34 = iVar34 + 1;
                  uVar26 = uVar26 + uVar35;
                  iVar19 = iVar19 + uVar28;
                } while (iVar34 != iVar13);
              }
              uStack_574 = uStack_574 + 1;
              uStack_564 = uStack_564 + uVar18;
              iStack_560 = iStack_560 + uVar17;
            } while (uStack_574 != uStack_570);
            return;
          }
          if (*(char *)(*(longlong *)(param_1 + 0x1000268) + 100) != '\0') {
            if ((int)uStack_570 <= (int)uStack_574) {
              return;
            }
            iVar38 = uVar35 * (iStack_578 - (int)uStack_548) + iVar38;
            iStack_560 = iStack_560 + (iStack_578 - (int)uStack_548) * uVar28;
            do {
              if (iStack_578 < iVar13) {
                iVar36 = iStack_578;
                iVar19 = iVar38;
                iVar34 = iStack_560;
                do {
                  iVar29 = *(int *)(*(longlong *)(*(longlong *)(param_1 + 0x1000268) + 0x78) +
                                   (longlong)
                                   ((*(int *)(param_1 + 0x1000264) + iVar19) *
                                    *(int *)(*(longlong *)(param_1 + 0x1000268) + 0x5c) +
                                   *(int *)(param_1 + 0x1000260) + iVar34) * 4);
                  if ((-1 < iVar29) &&
                     (uVar26 = *(int *)(param_1 + 0x100035c) * ((int)uStack_574 >> 1) +
                               (uStack_574 & 1) * 2 + *(int *)(param_1 + 0x1000348) + iVar36 * 4,
                     uVar26 < 0x300000)) {
                    *(short *)(*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar26 ^ 2)) =
                         (short)iVar29;
                  }
                  iVar36 = iVar36 + 1;
                  iVar19 = iVar19 + uVar35;
                  iVar34 = iVar34 + uVar28;
                } while (iVar36 != iVar13);
              }
              uStack_574 = uStack_574 + 1;
              iVar38 = iVar38 + uVar18;
              iStack_560 = iStack_560 + uVar17;
            } while (uStack_574 != uStack_570);
            return;
          }
          if ((int)uStack_570 <= (int)uStack_574) {
            return;
          }
          uStack_564 = iVar38 + uVar35 * (iStack_578 - (int)uStack_548);
          iStack_560 = (iStack_578 - (int)uStack_548) * uVar28 + iStack_560;
          do {
            if (iStack_578 < iVar13) {
              iVar38 = (uStack_574 & 1) * 2;
              iVar19 = iStack_560;
              iVar34 = iStack_578;
              uVar26 = uStack_564;
              do {
                iVar36 = *(int *)(*(longlong *)(*(longlong *)(param_1 + 0x1000268) + 0x78) +
                                 (longlong)
                                 (int)((*(int *)(param_1 + 0x1000264) + uVar26) *
                                       *(int *)(*(longlong *)(param_1 + 0x1000268) + 0x5c) +
                                      *(int *)(param_1 + 0x1000260) + iVar19) * 4);
                if (-1 < iVar36) {
                  uVar12 = 0;
                  uVar27 = *(int *)(param_1 + 0x1000358) * ((int)uStack_574 >> 1) + iVar38 +
                           *(int *)(param_1 + 0x100034c) + iVar34 * 4;
                  if (uVar27 < 0x300000) {
                    uVar12 = *(undefined2 *)
                              (*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar27 ^ 2));
                  }
                  uVar12 = FUN_0047d0d0(param_1,iVar36,uVar12);
                  uVar27 = *(int *)(param_1 + 0x100035c) * ((int)uStack_574 >> 1) + iVar38 +
                           *(int *)(param_1 + 0x1000348) + iVar34 * 4;
                  if (uVar27 < 0x300000) {
                    *(undefined2 *)(*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar27 ^ 2)) =
                         uVar12;
                  }
                }
                iVar34 = iVar34 + 1;
                uVar26 = uVar26 + uVar35;
                iVar19 = iVar19 + uVar28;
              } while (iVar34 != iVar13);
            }
            uStack_574 = uStack_574 + 1;
            uStack_564 = uStack_564 + uVar18;
            iStack_560 = iStack_560 + uVar17;
          } while (uStack_574 != uStack_570);
          return;
        }
      }
    }
    if ((*(int *)(param_1 + 0x10000c8) == 1) || ((*(byte *)(param_1 + 0x100027d) & 0x10) != 0)) {
      cVar11 = FUN_0047ed60(param_1,iVar13);
      if (cVar11 == '\0') {
        if (0 < *(int *)(param_1 + 0x1000274)) {
          uStack_570 = 0;
          iVar34 = *(int *)(param_1 + 0x1000290);
          iVar36 = *(int *)(param_1 + 0x1000294);
          iVar38 = *(int *)(param_1 + 0x10002b0);
          iVar19 = *(int *)(param_1 + 0x10002b4);
          do {
            iVar29 = *(int *)(param_1 + 0x10002a8) + iVar38;
            iVar30 = *(int *)(param_1 + 0x10002ac) + iVar19;
            iVar31 = *(int *)(param_1 + 0x1000288) + iVar34;
            iVar32 = *(int *)(param_1 + 0x100028c) + iVar36;
            if ((int)fVar1 < iVar13) {
              iVar36 = iVar36 >> 4;
              iVar34 = iVar34 >> 4;
              iVar14 = iVar32 >> 4;
              iVar15 = iVar31 >> 4;
              fVar33 = fVar1;
              iVar13 = iVar29;
              iVar37 = iVar30;
              do {
                lVar25 = *(longlong *)(param_1 + 0x1000268);
                if (lVar25 == 0) {
                  uVar12 = 0;
                  uVar28 = ((*(ushort *)(param_1 + 0x1000286) & 0x3ff) * 4 + 8) *
                           ((int)uStack_570 >> 1) + (uStack_570 & 1) * 2 +
                           *(int *)(param_1 + 0x1000270) + (int)fVar33 * 4;
                  if (uVar28 < 0x300000) {
                    uVar12 = *(undefined2 *)
                              (*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar28 ^ 2));
                  }
                  iVar16 = FUN_0047ca50(param_1,uVar12);
                  if (-1 < iVar16) {
                    iVar16 = FUN_0047ef90(param_1,iVar16,iVar38,iVar19,iVar38 + iVar34,
                                          iVar19 + iVar36,iVar13 + iVar15,iVar37 + iVar14,iVar13,
                                          iVar37);
                    goto joined_r0x00480c04;
                  }
                }
                else if (*(char *)(lVar25 + 100) == '\0') {
                  iVar16 = *(int *)(*(longlong *)(lVar25 + 0x78) +
                                   (longlong)
                                   (int)((uStack_570 + *(int *)(param_1 + 0x1000264)) *
                                         *(int *)(lVar25 + 0x5c) +
                                        (int)fVar33 + *(int *)(param_1 + 0x1000260)) * 4);
                  if (-1 < iVar16) {
                    iVar16 = FUN_0047ef90(param_1,iVar16,iVar38,iVar19,iVar38 + iVar34,
                                          iVar19 + iVar36,iVar13 + iVar15,iVar37 + iVar14,iVar13,
                                          iVar37);
joined_r0x00480c04:
                    if (iVar16 != 0) break;
                  }
                }
                else {
                  iVar16 = *(int *)(*(longlong *)(lVar25 + 0x78) +
                                   (longlong)
                                   (int)((uStack_570 + *(int *)(param_1 + 0x1000264)) *
                                         *(int *)(lVar25 + 0x5c) +
                                        (int)fVar33 + *(int *)(param_1 + 0x1000260)) * 4);
                  if (-1 < iVar16) {
                    iVar16 = FUN_0047f9e0(param_1,iVar16,iVar38,iVar19,iVar38 + iVar34,
                                          iVar19 + iVar36,iVar13 + iVar15,iVar37 + iVar14,iVar13,
                                          iVar37);
                    goto joined_r0x00480c04;
                  }
                }
                iVar19 = iVar19 + iVar36;
                iVar38 = iVar38 + iVar34;
                iVar37 = iVar37 + iVar14;
                iVar13 = iVar13 + iVar15;
                fVar33 = (float)((int)fVar33 + 1);
              } while ((int)fVar33 < *(int *)(param_1 + 0x1000278));
            }
            uStack_570 = uStack_570 + 1;
            if (*(int *)(param_1 + 0x1000274) <= (int)uStack_570) {
              return;
            }
            iVar13 = *(int *)(param_1 + 0x1000278);
            iVar34 = iVar31;
            iVar36 = iVar32;
            iVar38 = iVar29;
            iVar19 = iVar30;
          } while( true );
        }
      }
    }
    else {
      dVar44 = (double)*(int *)(param_1 + 0x1000274);
      dVar2 = (double)iVar38;
      dVar3 = (double)(*(int *)(param_1 + 0x10002b0) + -0x8000) * _UNK_00b030f8;
      dVar4 = (double)(*(int *)(param_1 + 0x10002b4) + -0x8000) * _UNK_00b030f8;
      dVar7 = *(double *)(param_1 + 0x10002d8) * dVar44 + dVar3;
      adStack_528[2] = dVar2 * *(double *)(param_1 + 0x10002c8) + dVar3;
      dVar8 = *(double *)(param_1 + 0x10002e0) * dVar44 + dVar4;
      adStack_528[4] =
           (*(double *)(param_1 + 0x10002b8) * dVar44 + *(double *)(param_1 + 0x10002c8)) * dVar2 +
           dVar7;
      adStack_528[3] = dVar2 * *(double *)(param_1 + 0x10002d0) + dVar4;
      dVar43 = adStack_528[2] - dVar3;
      dVar5 = adStack_528[4] - dVar7;
      adStack_528[5] =
           (dVar44 * *(double *)(param_1 + 0x10002c0) + *(double *)(param_1 + 0x10002d0)) * dVar2 +
           dVar8;
      dVar44 = adStack_528[3] - dVar4;
      dVar6 = adStack_528[5] - dVar8;
      dVar41 = dVar5 - dVar43;
      dVar39 = dVar6 - dVar44;
      dVar41 = dVar41 * dVar41 + dVar39 * dVar39;
      dVar39 = SQRT(dVar41);
      adStack_528[0] = dVar3;
      adStack_528[1] = dVar4;
      adStack_528[6] = dVar7;
      adStack_528[7] = dVar8;
      if (NAN(dVar39)) {
        dVar39 = (double)FUN_008ce5b0(dVar41);
      }
      dVar39 = SQRT(dVar39);
      if (NAN(dVar39)) {
        dVar39 = (double)FUN_008ce5b0();
      }
      iVar13 = *(int *)(param_1 + 0x1000274);
      iVar19 = (int)dVar39 / 2 + 1;
      iVar38 = 7;
      if (iVar19 < 8) {
        iVar38 = iVar19;
      }
      if (((iVar13 < iVar38) && (iVar19 = *(int *)(param_1 + 0x1000278), iVar19 < iVar38)) &&
         (iVar38 = iVar19, iVar19 < iVar13)) {
        iVar38 = iVar13;
      }
      pfVar22 = (float *)&uStack_4e8;
      pfVar23 = pfVar22;
      do {
        pfVar23[1] = 0.0;
        pfVar24 = pfVar23 + 4;
        *pfVar23 = 0.0;
        pfVar23[3] = 0.0;
        pfVar23[2] = 0.0;
        pfVar23 = pfVar24;
      } while (pfVar24 != afStack_e8);
      dVar39 = (double)iVar38;
      dVar7 = dVar7 - dVar3;
      dVar8 = dVar8 - dVar4;
      dVar43 = dVar43 / dVar39;
      dVar44 = dVar44 / dVar39;
      dVar5 = dVar5 / dVar39 - dVar43;
      dVar6 = dVar6 / dVar39 - dVar44;
      if (-1 < iVar38) {
        iVar19 = 0;
        do {
          iVar34 = 0;
          dVar41 = dVar3;
          dVar42 = dVar4;
          do {
            fVar33 = (float)dVar41;
            lVar25 = (longlong)(iVar34 + iVar19 * 8);
            dVar41 = dVar41 + dVar43;
            *(float *)(&uStack_4e8 + lVar25 * 2) = fVar33;
            *(float *)((longlong)&uStack_4e8 + lVar25 * 0x10 + 4) = (float)dVar42;
            dVar42 = dVar42 + dVar44;
            dVar40 = (double)iVar34;
            iVar34 = iVar34 + 1;
            *(float *)((longlong)afStack_4dc + lVar25 * 0x10) =
                 (float)(((double)iVar19 * (double)iVar13) / dVar39);
            (&fStack_4e0)[lVar25 * 4] = (float)((dVar40 * dVar2) / dVar39 + (double)(int)fVar1);
          } while (iVar38 + 1 != iVar34);
          iVar19 = iVar19 + 1;
          dVar3 = dVar3 + dVar7 / dVar39;
          dVar4 = dVar4 + dVar8 / dVar39;
          dVar43 = dVar43 + dVar5 / dVar39;
          dVar44 = dVar44 + dVar6 / dVar39;
        } while (iVar19 != iVar38 + 1);
        if (0 < iVar38) {
          do {
            pfVar23 = pfVar22;
            do {
              pfVar24 = pfVar23 + 4;
              FUN_0047e3c0(param_1,pfVar23,pfVar24,pfVar23 + 0x24);
              FUN_0047e3c0(param_1,pfVar23,pfVar23 + 0x24,pfVar23 + 0x20);
              pfVar23 = pfVar24;
            } while (pfVar24 != pfVar22 + ((ulonglong)(iVar38 - 1) * 2 + 2) * 2);
            pfVar22 = pfVar22 + 0x20;
          } while (pfVar22 != (float *)((longlong)afStack_468 + (ulonglong)(iVar38 - 1) * 0x80));
        }
      }
    }
  }
  return;
}


