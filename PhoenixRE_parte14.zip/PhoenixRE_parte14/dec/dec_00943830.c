// FUN @ 00943830 size=1
// callees: []

void FUN_00943830(longlong *param_1)

{
  ulonglong *puVar1;
  uint uVar2;
  uint *puVar3;
  ulonglong *puVar4;
  longlong lVar5;
  int *piVar6;
  uint uVar7;
  ulonglong uVar8;
  longlong lVar9;
  
  puVar3 = (uint *)*param_1;
  if (puVar3 == (uint *)0x0) {
    return;
  }
  if ((int)puVar3[2] < 2) {
    return;
  }
  uVar2 = *puVar3;
  uVar7 = uVar2 + 1 + (uVar2 >> 1);
  if (uVar7 < 0x20) {
    puVar3 = (uint *)func_0x008ce288(0x18);
    lVar9 = 0x1f;
    lVar5 = 0x508;
    uVar8 = 0x20;
    uVar7 = 0x20;
  }
  else {
    puVar3 = (uint *)func_0x008ce288(0x18);
    uVar8 = (ulonglong)(int)uVar7;
    if (uVar8 < 0x330000000000001) {
      lVar9 = uVar8 - 1;
      lVar5 = uVar8 * 0x28 + 8;
    }
    else {
      lVar9 = uVar8 - 1;
      lVar5 = -1;
    }
  }
  puVar4 = (ulonglong *)func_0x008ce290(lVar5);
  lVar5 = 0;
  puVar1 = puVar4 + 1;
  *puVar4 = uVar8;
  puVar4 = puVar1;
  do {
    lVar5 = lVar5 + 1;
    *(undefined4 *)puVar4 = 0;
    *(undefined4 *)((longlong)puVar4 + 0x1c) = 0;
    *(undefined4 *)(puVar4 + 3) = 0;
    puVar4[2] = 0;
    *(undefined4 *)((longlong)puVar4 + 4) = 0;
    *(undefined4 *)(puVar4 + 1) = 0;
    puVar4[4] = 0;
    puVar4 = puVar4 + 5;
  } while (lVar5 != lVar9 + 1);
  *(ulonglong **)(puVar3 + 4) = puVar1;
  puVar3[1] = uVar7;
  puVar3[2] = 1;
  *puVar3 = uVar2;
  piVar6 = (int *)*param_1;
  if (*piVar6 != 0) {
    FUN_008db890(puVar1,*(undefined8 *)(piVar6 + 4));
    piVar6 = (int *)*param_1;
    if (piVar6 == (int *)0x0) goto code_r0x00943932;
  }
  piVar6[2] = piVar6[2] + -1;
  lVar9 = *param_1;
  if (*(int *)(lVar9 + 8) == 0) {
    if (*(longlong *)(lVar9 + 0x10) != 0) {
      func_0x008ce278(*(longlong *)(lVar9 + 0x10) + -8);
      lVar9 = *param_1;
    }
    func_0x008ce280(lVar9);
  }
code_r0x00943932:
  *param_1 = (longlong)puVar3;
  return;
}


