// FUN @ 00703e20 size=1
// callees: []

undefined8 FUN_00703e20(longlong param_1)

{
  uint uVar1;
  int iVar2;
  longlong lVar3;
  uint *puVar4;
  undefined8 uVar5;
  longlong lVar6;
  int *piVar7;
  uint uVar8;
  
  lVar3 = lRam0000000000cf4050;
  iVar2 = *(int *)(param_1 + 0x28);
  puVar4 = *(uint **)(lRam0000000000cf4050 + 0x20);
  if ((puVar4 == (uint *)0x0) || ((int)puVar4[2] < 2)) goto code_r0x0047ade0;
  uVar1 = *puVar4;
  uVar8 = uVar1 + 1 + (uVar1 >> 1);
  if (uVar8 < 0x20) {
    uVar8 = 0x20;
    puVar4 = (uint *)func_0x008ce288(0x18);
    lVar6 = 0x100;
  }
  else {
    puVar4 = (uint *)func_0x008ce288(0x18);
    lVar6 = -1;
    if ((ulonglong)(longlong)(int)uVar8 < 0xfe0000000000001) {
      lVar6 = (longlong)(int)uVar8 * 8;
    }
  }
  uVar5 = func_0x008ce290(lVar6);
  puVar4[1] = uVar8;
  *(undefined8 *)(puVar4 + 4) = uVar5;
  puVar4[2] = 1;
  *puVar4 = uVar1;
  piVar7 = *(int **)(lVar3 + 0x20);
  if (*piVar7 == 0) {
code_r0x0047adad:
    piVar7[2] = piVar7[2] + -1;
    lVar6 = *(longlong *)(lVar3 + 0x20);
    if (*(int *)(lVar6 + 8) == 0) {
      if (*(longlong *)(lVar6 + 0x10) != 0) {
        func_0x008ce278();
        lVar6 = *(longlong *)(lVar3 + 0x20);
      }
      func_0x008ce280(lVar6);
    }
  }
  else {
    FUN_008de030(uVar5,*(undefined8 *)(piVar7 + 4));
    piVar7 = *(int **)(lVar3 + 0x20);
    if (piVar7 != (int *)0x0) goto code_r0x0047adad;
  }
  *(uint **)(lVar3 + 0x20) = puVar4;
code_r0x0047ade0:
  uVar5 = 0;
  lVar3 = **(longlong **)(*(longlong *)(puVar4 + 4) + (longlong)iVar2 * 8);
  if (*(char *)(lVar3 + 0x49) == '\0') {
    *(undefined1 *)(lVar3 + 0x48) = 0;
    lVar6 = lVar3 + 0x20;
    while (EnterCriticalSection(lVar6), *(char *)(lVar3 + 0x4a) == '\0') {
      LeaveCriticalSection(lVar6);
      Sleep(0);
    }
    *(undefined1 *)(lVar3 + 0x48) = 0;
    *(undefined1 *)(lVar3 + 0x4a) = 0;
    *(undefined8 *)(lVar3 + 0x50) = 0;
    LeaveCriticalSection(lVar6);
    if (cRam0000000000d01610 == '\0') {
      SetEvent(*(undefined8 *)(lVar3 + 0x10));
    }
    else {
      (*pcRam0000000000d01618)(lVar3 + 0x18);
    }
    Sleep(0);
    uVar5 = 1;
  }
  return uVar5;
}


