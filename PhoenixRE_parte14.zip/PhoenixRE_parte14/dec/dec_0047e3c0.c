// FUN @ 0047e3c0 size=1
// callees: []

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0047e3c0(longlong param_1,float *param_2,float *param_3,float *param_4)

{
  ulonglong uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  float *pfVar6;
  float *pfVar7;
  float *pfVar8;
  float *pfVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  float fVar13;
  float fVar14;
  double dVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  undefined4 uStack_118;
  undefined4 uStack_114;
  float fStack_108;
  float fStack_104;
  float fStack_f8;
  float fStack_f4;
  float fStack_e8;
  float fStack_e4;
  
  uVar1 = _UNK_00b030e0;
  fVar16 = _UNK_00b030c8;
  fVar18 = *param_2;
  if (((((0.0 <= fVar18) || (0.0 < *param_3 || *param_3 == 0.0)) ||
       (0.0 < *param_4 || *param_4 == 0.0)) &&
      (((fVar21 = param_2[1], 0.0 <= fVar21 || (0.0 < param_3[1] || param_3[1] == 0.0)) ||
       (0.0 < param_4[1] || param_4[1] == 0.0)))) &&
     (((dVar15 = (double)*(int *)(param_1 + 0x1000350) + _UNK_00b030d8, (double)fVar18 <= dVar15 ||
       ((double)*param_3 <= dVar15)) || ((double)*param_4 <= dVar15)))) {
    iVar4 = *(int *)(param_1 + 0x1000354);
    dVar15 = (double)iVar4 + _UNK_00b030d8;
    fVar17 = param_3[1];
    if (((double)fVar21 <= dVar15) || ((double)fVar17 <= dVar15)) {
      fVar19 = param_4[1];
    }
    else {
      fVar19 = param_4[1];
      if (dVar15 < (double)fVar19) {
        return;
      }
    }
    uVar2 = *(uint *)(param_1 + 0x100027c) & 0x60000;
    if (uVar2 != 0x60000) {
      uVar5 = 0x20000;
      if ((fVar18 + *param_3) * (fVar21 - fVar17) + (*param_3 + *param_4) * (fVar17 - fVar19) +
          (fVar18 + *param_4) * (fVar19 - fVar21) < 0.0) {
        uVar5 = 0x40000;
      }
      if (uVar2 != uVar5) {
        return;
      }
    }
    pfVar6 = param_4;
    fVar18 = fVar17;
    if (fVar17 <= fVar19) {
      pfVar6 = param_3;
      param_3 = param_4;
      fVar18 = fVar19;
      fVar19 = fVar17;
    }
    pfVar7 = pfVar6;
    pfVar8 = param_2;
    pfVar9 = param_3;
    fVar17 = fVar18;
    fVar22 = fVar19;
    fVar23 = fVar21;
    if ((fVar19 < fVar21) &&
       (pfVar7 = param_3, pfVar8 = pfVar6, pfVar9 = param_2, fVar17 = fVar21, fVar22 = fVar18,
       fVar23 = fVar19, fVar21 <= fVar18)) {
      pfVar7 = param_2;
      pfVar9 = param_3;
      fVar17 = fVar18;
      fVar22 = fVar21;
    }
    if (fVar23 < 0.0) {
      iVar3 = (int)(fVar23 - _UNK_00b030cc) +
              (int)((fVar23 - (float)(int)(fVar23 - _UNK_00b030cc)) + _UNK_00b030c8);
    }
    else {
      iVar3 = (int)(fVar23 + _UNK_00b030c8);
    }
    if (fVar22 < 0.0) {
      iVar11 = (int)((fVar22 - (float)(int)(fVar22 - _UNK_00b030cc)) + _UNK_00b030c8) +
               (int)(fVar22 - _UNK_00b030cc);
    }
    else {
      iVar11 = (int)(fVar22 + _UNK_00b030c8);
    }
    if (fVar17 < 0.0) {
      iVar12 = (int)((fVar17 - (float)(int)(fVar17 - _UNK_00b030cc)) + _UNK_00b030c8) +
               (int)(fVar17 - _UNK_00b030cc);
    }
    else {
      iVar12 = (int)(fVar17 + _UNK_00b030c8);
    }
    if (iVar3 != iVar12) {
      fVar17 = fVar17 - fVar23;
      fVar18 = fVar17;
      if (((double)((ulonglong)(double)fVar17 & _UNK_00b030e0) < _UNK_00b030f0) &&
         (fVar18 = _UNK_00b030d4, 0.0 <= fVar17)) {
        fVar18 = _UNK_00b030d0;
      }
      fVar21 = *pfVar8;
      fStack_108 = pfVar8[2];
      fStack_104 = pfVar8[3];
      fVar17 = (*pfVar9 - fVar21) / fVar18;
      fVar19 = (pfVar9[2] - fStack_108) / fVar18;
      fVar18 = (pfVar9[3] - fStack_104) / fVar18;
      if (iVar3 < iVar11) {
        iVar10 = 0;
        if ((-1 < iVar3) && (iVar10 = iVar4 + 1, iVar3 <= iVar4)) {
          iVar10 = iVar3;
        }
        iVar3 = 0;
        if ((-1 < iVar11) && (iVar3 = iVar4 + 1, iVar11 <= iVar4)) {
          iVar3 = iVar11;
        }
        if (iVar10 != iVar3) {
          fVar22 = fVar22 - fVar23;
          fStack_e4 = fVar22;
          if (((double)((ulonglong)(double)fVar22 & _UNK_00b030e0) < _UNK_00b030f0) &&
             (fStack_e4 = _UNK_00b030d4, 0.0 <= fVar22)) {
            fStack_e4 = _UNK_00b030d0;
          }
          fVar14 = (*pfVar7 - fVar21) / fStack_e4;
          fStack_e8 = (pfVar7[2] - fStack_108) / fStack_e4;
          fStack_e4 = (pfVar7[3] - fStack_104) / fStack_e4;
          dVar15 = ((double)iVar10 + _UNK_00b030c0) - (double)fVar23;
          fVar20 = (float)((double)fVar14 * dVar15 + (double)fVar21);
          fVar21 = (float)((double)fVar17 * dVar15 + (double)fVar21);
          fStack_f4 = (fVar17 - fVar14) * fVar22;
          dVar15 = (double)fStack_f4;
          if (((double)((ulonglong)dVar15 & _UNK_00b030e0) < _UNK_00b030f0) &&
             (fStack_f4 = _UNK_00b030d4, _UNK_00b030f0 <= dVar15)) {
            fStack_f4 = _UNK_00b030d0;
          }
          fStack_f8 = ((fVar19 - fStack_e8) * fVar22) / fStack_f4;
          fStack_f4 = ((fVar18 - fStack_e4) * fVar22) / fStack_f4;
          fVar22 = fVar17;
          fVar13 = fVar20;
          if (fVar17 < fVar14) {
            fVar22 = fVar14;
            fVar13 = fVar21;
            fVar21 = fVar20;
            fStack_e8 = fVar19;
            fStack_e4 = fVar18;
            fVar14 = fVar17;
          }
          fVar23 = ((float)iVar10 - fVar23) + _UNK_00b030c8;
          uStack_118 = 0;
          uStack_114 = 0;
          fStack_108 = fStack_e8 * fVar23 + fStack_108;
          fStack_104 = fStack_e4 * fVar23 + fStack_104;
          FUN_0047d9e0(param_1,&uStack_118,&fStack_108,&fStack_f8,&fStack_e8,fVar13,fVar21,fVar14,
                       fVar22,iVar10,iVar3);
        }
      }
      if (iVar11 < iVar12) {
        iVar4 = 0;
        if ((-1 < iVar11) &&
           (iVar4 = *(int *)(param_1 + 0x1000354) + 1, iVar11 <= *(int *)(param_1 + 0x1000354))) {
          iVar4 = iVar11;
        }
        iVar3 = 0;
        if ((-1 < iVar12) &&
           (iVar3 = *(int *)(param_1 + 0x1000354) + 1, iVar12 <= *(int *)(param_1 + 0x1000354))) {
          iVar3 = iVar12;
        }
        if (iVar4 != iVar3) {
          fVar21 = pfVar7[1];
          fVar23 = pfVar9[1] - fVar21;
          fVar22 = fVar23;
          if (((double)((ulonglong)(double)fVar23 & uVar1) < _UNK_00b030f0) &&
             (fVar22 = _UNK_00b030d4, 0.0 <= fVar23)) {
            fVar22 = _UNK_00b030d0;
          }
          fVar23 = *pfVar7;
          fStack_104 = pfVar7[3];
          fStack_108 = pfVar7[2];
          fVar13 = (*pfVar9 - fVar23) / fVar22;
          fVar14 = pfVar8[1];
          fVar20 = (float)((double)fVar13 * (((double)iVar4 + _UNK_00b030c0) - (double)fVar21) +
                          (double)fVar23);
          fVar24 = fVar21 - fVar14;
          fVar25 = (float)((double)fVar17 * (((double)iVar4 + _UNK_00b030c0) - (double)fVar14) +
                          (double)*pfVar8);
          fVar23 = (fVar24 * fVar17 + *pfVar8) - fVar23;
          fStack_f4 = fVar23;
          if (((double)((ulonglong)(double)fVar23 & uVar1) < _UNK_00b030f0) &&
             (fStack_f4 = _UNK_00b030d4, 0.0 <= fVar23)) {
            fStack_f4 = _UNK_00b030d0;
          }
          fStack_f8 = ((fVar24 * fVar19 + pfVar8[2]) - fStack_108) / fStack_f4;
          fStack_f4 = ((fVar24 * fVar18 + pfVar8[3]) - fStack_104) / fStack_f4;
          if (fVar17 <= fVar13) {
            fVar19 = (pfVar9[2] - fStack_108) / fVar22;
            fVar18 = (pfVar9[3] - fStack_104) / fVar22;
            fVar16 = ((float)iVar4 - fVar21) + fVar16;
            fStack_108 = fVar16 * fVar19 + fStack_108;
            fStack_104 = fVar16 * fVar18 + fStack_104;
            fVar16 = fVar17;
            fVar21 = fVar25;
          }
          else {
            fVar16 = ((float)iVar4 - fVar14) + fVar16;
            fStack_108 = fVar16 * fVar19 + pfVar8[2];
            fStack_104 = fVar16 * fVar18 + pfVar8[3];
            fVar16 = fVar13;
            fVar21 = fVar20;
            fVar20 = fVar25;
            fVar13 = fVar17;
          }
          uStack_118 = 0;
          uStack_114 = 0;
          fStack_e8 = fVar19;
          fStack_e4 = fVar18;
          FUN_0047d9e0(param_1,&uStack_118,&fStack_108,&fStack_f8,&fStack_e8,fVar20,fVar21,fVar13,
                       fVar16,iVar4,iVar3);
        }
      }
    }
  }
  return;
}


