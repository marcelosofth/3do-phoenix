// FUN @ 004821b0 size=1
// callees: []

ulonglong FUN_004821b0(longlong param_1,int *param_2,int *param_3,int *param_4,uint param_5)

{
  int iVar1;
  uint uVar2;
  ulonglong uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iStack_b8;
  int iStack_b4;
  int iStack_a8;
  int iStack_a4;
  int iStack_98;
  int iStack_94;
  int iStack_88;
  int iStack_84;
  int iStack_78;
  int iStack_74;
  int iStack_68;
  int iStack_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  
  iVar1 = *param_2;
  iStack_78 = *(int *)(param_1 + 0x1000350) + 1;
  iStack_64 = *(int *)(param_1 + 0x1000354) + 1;
  if (((iVar1 < 1) && (*param_3 < 1)) && (*param_4 < 1)) {
    return 0;
  }
  iVar6 = param_2[1];
  if (((iVar6 < 1) && (param_3[1] < 1)) && (param_4[1] < 1)) {
    return 0;
  }
  if (((iStack_64 <= iVar6) && (iStack_64 <= param_3[1])) && (iStack_64 <= param_4[1])) {
    return 0;
  }
  if ((iVar1 < iStack_78) || (iVar8 = *param_3, iVar8 < iStack_78)) {
    iVar7 = param_3[1];
    iVar8 = *param_3;
    iStack_98 = *param_4;
  }
  else {
    iStack_98 = *param_4;
    if (iStack_78 <= iStack_98) {
      return 0;
    }
    iVar7 = param_3[1];
  }
  iVar5 = iVar6;
  iVar4 = iVar8;
  if (iVar7 < iVar6) {
    *param_2 = iVar8;
    *param_3 = iVar1;
    param_2[1] = iVar7;
    param_3[1] = iVar6;
    iVar5 = iVar7;
    iVar4 = iVar1;
    iVar7 = iVar6;
    iVar1 = iVar8;
  }
  iStack_94 = param_4[1];
  iStack_a8 = iVar4;
  iStack_a4 = iVar7;
  if (iStack_94 < iVar7) {
    param_3[1] = iStack_94;
    *param_4 = iVar4;
    param_4[1] = iVar7;
    *param_3 = iStack_98;
    iStack_a8 = iStack_98;
    iStack_a4 = iStack_94;
    iStack_94 = iVar7;
    iStack_98 = iVar4;
  }
  iStack_b4 = iVar5;
  iStack_b8 = iVar1;
  if (iStack_a4 < iVar5) {
    *param_3 = iVar1;
    param_2[1] = iStack_a4;
    param_3[1] = iVar5;
    *param_2 = iStack_a8;
    iStack_b4 = iStack_a4;
    iStack_b8 = iStack_a8;
    iStack_a4 = iVar5;
    iStack_a8 = iVar1;
  }
  if (((param_5 & 1) == 0) && (param_5 = param_5 | 1, iStack_b4 < 0)) {
    if (-1 < iStack_a4) {
      iVar7 = iStack_b4 << 8;
      iVar1 = iStack_b4 - iStack_a4;
      iVar8 = iStack_b4 - iStack_94;
      iStack_b4 = 0;
      iVar6 = ((iStack_a8 - iStack_b8) * (iVar7 / iVar1) >> 8) + iStack_b8;
      iVar8 = ((iStack_98 - iStack_b8) * (iVar7 / iVar8) >> 8) + iStack_b8;
      iStack_b8 = iVar6;
      iVar1 = FUN_004821b0(param_1,&iStack_b8,&iStack_a8,&iStack_98,param_5);
      iStack_68 = *param_4;
      iStack_74 = 0;
      iStack_64 = param_4[1];
      iStack_84 = 0;
      iStack_88 = iVar6;
      iStack_78 = iVar8;
      iVar6 = FUN_004821b0(param_1,&iStack_88,&iStack_78,&iStack_68,param_5);
      return (ulonglong)(uint)(iVar6 + iVar1);
    }
    iStack_74 = 0;
    iStack_84 = 0;
    iStack_88 = ((iStack_98 - iStack_b8) * ((iStack_b4 << 8) / (iStack_b4 - iStack_94)) >> 8) +
                iStack_b8;
    iStack_78 = iStack_a8 +
                ((iStack_98 - iStack_a8) * ((iStack_a4 << 8) / (iStack_a4 - iStack_94)) >> 8);
    iStack_68 = iStack_98;
    iStack_64 = iStack_94;
  }
  else if (((param_5 & 2) == 0) && (param_5 = param_5 | 2, iStack_64 < iStack_94)) {
    iStack_74 = iStack_64;
    if (iStack_a4 <= iStack_64) {
      iVar6 = ((iStack_98 - iStack_b8) *
               (((iStack_64 - iStack_b4) * 0x100) / (iStack_94 - iStack_b4)) >> 8) + iStack_b8;
      iVar8 = ((iStack_98 - iStack_a8) *
               (((iStack_64 - iStack_a4) * 0x100) / (iStack_94 - iStack_a4)) >> 8) + iStack_a8;
      iStack_98 = iVar8;
      iStack_94 = iStack_64;
      iVar1 = FUN_004821b0(param_1,&iStack_b8,&iStack_a8,&iStack_98,param_5);
      iStack_88 = *param_2;
      iStack_84 = param_2[1];
      iStack_78 = iVar8;
      iStack_68 = iVar6;
code_r0x004825b6:
      iVar6 = FUN_004821b0(param_1,&iStack_88,&iStack_78,&iStack_68,param_5);
      return (ulonglong)(uint)(iVar6 + iVar1);
    }
    iVar1 = (iStack_64 - iStack_b4) * 0x100;
    iStack_68 = ((iStack_98 - iStack_b8) * (iVar1 / (iStack_94 - iStack_b4)) >> 8) + iStack_b8;
    iStack_78 = ((iStack_a8 - iStack_b8) * (iVar1 / (iStack_a4 - iStack_b4)) >> 8) + iStack_b8;
    iStack_88 = iStack_b8;
    iStack_84 = iStack_b4;
  }
  else {
    iVar1 = iStack_a4;
    iVar6 = iStack_b8;
    if (iStack_a8 < iStack_b8) {
      *param_2 = iStack_a8;
      *param_3 = iStack_b8;
      param_2[1] = iStack_a4;
      param_3[1] = iStack_b4;
      iVar1 = iStack_b4;
      iVar6 = iStack_a8;
      iStack_b4 = iStack_a4;
      iStack_a8 = iStack_b8;
    }
    iStack_5c = iVar1;
    iStack_58 = iStack_98;
    iStack_60 = iStack_a8;
    if (iStack_98 < iStack_a8) {
      param_3[1] = iStack_94;
      param_4[1] = iVar1;
      *param_3 = iStack_98;
      *param_4 = iStack_a8;
      iStack_5c = iStack_94;
      iStack_94 = iVar1;
      iStack_58 = iStack_a8;
      iStack_60 = iStack_98;
    }
    iStack_64 = iStack_b4;
    iStack_98 = iVar6;
    if (iStack_60 < iVar6) {
      param_3[1] = iStack_b4;
      *param_2 = iStack_60;
      *param_3 = iVar6;
      param_2[1] = iStack_5c;
      iStack_64 = iStack_5c;
      iStack_98 = iStack_60;
      iStack_5c = iStack_b4;
      iStack_60 = iVar6;
    }
    if (((param_5 & 4) == 0) && (param_5 = param_5 | 4, iStack_98 < 0)) {
      if (-1 < iStack_60) {
        iStack_a8 = 0;
        iStack_b8 = 0;
        iVar6 = ((iStack_5c - iStack_64) * ((iStack_98 << 8) / (iStack_98 - iStack_60)) >> 8) +
                iStack_64;
        iStack_a4 = ((iStack_94 - iStack_64) * ((iStack_98 << 8) / (iStack_98 - iStack_58)) >> 8) +
                    iStack_64;
        iStack_b4 = iVar6;
        iStack_98 = iStack_58;
        iVar1 = FUN_004821b0(param_1,&iStack_b8,&iStack_a8,&iStack_98,param_5);
        iStack_68 = *param_4;
        iStack_88 = 0;
        iStack_64 = param_4[1];
        iStack_78 = *param_3;
        iStack_74 = param_3[1];
        iStack_84 = iVar6;
        iVar6 = FUN_004821b0(param_1,&iStack_88,&iStack_78,&iStack_68,param_5);
        return (ulonglong)(uint)(iVar6 + iVar1);
      }
      iStack_78 = 0;
      iStack_88 = 0;
      iStack_84 = ((iStack_94 - iStack_64) * ((iStack_98 << 8) / (iStack_98 - iStack_58)) >> 8) +
                  iStack_64;
      iStack_74 = ((iStack_94 - iStack_5c) * ((iStack_60 << 8) / (iStack_60 - iStack_58)) >> 8) +
                  iStack_5c;
      iStack_68 = iStack_58;
      iStack_64 = iStack_94;
    }
    else {
      iStack_68 = iStack_98;
      if (((param_5 & 8) != 0) || (iStack_58 <= iStack_78)) {
        iStack_54 = iStack_94;
        uVar2 = FUN_008de650(&iStack_68,3);
        return (ulonglong)((uVar2 ^ (int)uVar2 >> 0x1f) - ((int)uVar2 >> 0x1f));
      }
      param_5 = param_5 | 8;
      iStack_88 = iStack_78;
      if (iStack_60 <= iStack_78) {
        iVar6 = iStack_5c +
                ((iStack_94 - iStack_5c) *
                 (((iStack_78 - iStack_60) * 0x100) / (iStack_58 - iStack_60)) >> 8);
        iStack_a4 = iStack_64 +
                    ((iStack_94 - iStack_64) *
                     (((iStack_78 - iStack_98) * 0x100) / (iStack_58 - iStack_98)) >> 8);
        iStack_b8 = iStack_78;
        iStack_b4 = iVar6;
        iStack_a8 = iStack_78;
        iStack_94 = iStack_64;
        iVar1 = FUN_004821b0(param_1,&iStack_b8,&iStack_a8,&iStack_98,param_5);
        iStack_84 = iVar6;
        iStack_78 = *param_3;
        iStack_74 = param_3[1];
        iStack_68 = *param_2;
        iStack_64 = param_2[1];
        goto code_r0x004825b6;
      }
      iVar1 = (iStack_78 - iStack_98) * 0x100;
      iStack_84 = iStack_64 + ((iStack_5c - iStack_64) * (iVar1 / (iStack_60 - iStack_98)) >> 8);
      iStack_74 = ((iStack_94 - iStack_64) * (iVar1 / (iStack_58 - iStack_98)) >> 8) + iStack_64;
    }
  }
  uVar3 = FUN_004821b0(param_1,&iStack_88,&iStack_78,&iStack_68,param_5);
  return uVar3;
}


