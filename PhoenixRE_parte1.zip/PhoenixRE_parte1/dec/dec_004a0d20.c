// FUN_004a0d20 @ 004a0d20 size=202
// callers: 0058a560 00589910 004a1d80 
// callees: 

int FUN_004a0d20(longlong param_1,uint param_2)

{
  longlong lVar1;
  int iVar2;
  uint uVar3;
  
  iVar2 = *(int *)(param_1 + 0x159f55c);
  if ((0 < iVar2) && ((longlong)iVar2 + 0x118U < 0x300000)) {
    lVar1 = param_1 + 0x129755c + (longlong)iVar2;
    if (((param_2 & 0xfff) < *(uint *)(lVar1 + 0xb0)) &&
       (uVar3 = *(int *)(lVar1 + 0xac) + ((param_2 & 0xfff) >> 7) * 4, uVar3 < 0x300000)) {
      if (uVar3 < 0x2ffffd) {
        uVar3 = *(int *)(param_1 + 0x129755c + (ulonglong)(uVar3 >> 2) * 4) + (param_2 & 0x7f) * 8;
      }
      else {
        uVar3 = (param_2 & 0x7f) * 8;
      }
      if (uVar3 < 0x2ffffd) {
        iVar2 = *(int *)(param_1 + 0x129755c + (ulonglong)(uVar3 >> 2) * 4);
        if (iVar2 - 1U < 0x2fffff) {
          uVar3 = 0;
          if (iVar2 + 0x18U < 0x2ffffd) {
            uVar3 = *(uint *)(param_1 + 0x129755c + (ulonglong)(iVar2 + 0x18U >> 2) * 4);
          }
          if (param_2 == uVar3) {
            return iVar2;
          }
        }
      }
    }
  }
  return 0;
}


