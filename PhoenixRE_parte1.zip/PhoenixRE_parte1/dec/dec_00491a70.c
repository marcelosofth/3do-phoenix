// FUN_00491a70 @ 00491a70 size=9812
// callers: 004a7f60 
// callees: 00916020:FUN_00916020 0046d8c0:FUN_0046d8c0 00478c50:FUN_00478c50 00917050:FUN_00917050 008ce550:_Unwind_SjLj_Unregister 008ce288:operator.new 00910c20:FUN_00910c20 0047ba00:FUN_0047ba00 008ce548:_Unwind_SjLj_Register 0090ede0:FUN_0090ede0 0041f340:FUN_0041f340 004986a0:FUN_004986a0 00952e50:FUN_00952e50 008ce278:operator.delete[] 005912e0:FUN_005912e0 008ce290:operator.new[] 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00491a70(longlong *param_1,undefined8 *param_2,undefined8 param_3,longlong param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int *piVar1;
  int iVar2;
  longlong *plVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  uint *puVar8;
  longlong lVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  uint uVar12;
  undefined1 auStack_1c8 [32];
  undefined4 uStack_1a8;
  undefined4 uStack_1a0;
  uint **ppuStack_190;
  longlong *plStack_188;
  uint **ppuStack_180;
  code *pcStack_178;
  int **ppiStack_170;
  undefined8 *puStack_168;
  undefined8 *puStack_160;
  undefined8 *puStack_158;
  undefined8 *puStack_150;
  longlong *plStack_148;
  undefined8 *puStack_140;
  undefined1 *puStack_138;
  uint uStack_12c;
  longlong *plStack_128;
  longlong *plStack_120;
  undefined1 auStack_118 [8];
  undefined4 uStack_110;
  undefined *puStack_e8;
  undefined *puStack_e0;
  undefined1 *puStack_d8;
  undefined1 *puStack_d0;
  undefined1 *puStack_c8;
  longlong *plStack_b0;
  code *pcStack_a0;
  undefined8 uStack_98;
  undefined4 auStack_88 [4];
  undefined8 *puStack_78;
  int *apiStack_68 [2];
  undefined8 *puStack_58;
  uint *apuStack_48 [2];
  undefined8 *puStack_38;
  uint *puStack_28;
  longlong *plStack_20;
  undefined8 uStack_18;
  undefined8 *puStack_10;
  
  puStack_d8 = &stack0xfffffffffffffff8;
  puStack_c8 = auStack_1c8;
  pcStack_178 = (code *)CONCAT44(pcStack_178._4_4_,param_6);
  puStack_e8 = &DAT_008ce270;
  puStack_e0 = &DAT_00cc1a70;
  puStack_d0 = &LAB_0049427f;
  puStack_138 = auStack_118;
  ppuStack_190 = (uint **)param_2;
  plStack_188 = param_1;
  ppuStack_180 = (uint **)param_4;
  ppiStack_170 = (int **)param_3;
  _Unwind_SjLj_Register(puStack_138);
  puStack_28 = *ppuStack_190;
  puStack_28[2] = puStack_28[2] + 1;
  ppuStack_190 = &puStack_28;
  uStack_110 = 1;
  FUN_0041f340(plStack_188,ppuStack_190,ppiStack_170);
  uVar12 = puStack_28[2];
  puStack_28[2] = uVar12 - 1;
  if ((puStack_28 != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(puStack_28);
  }
  *plStack_188 = (longlong)&PTR_FUN_00c240f0;
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ((&DAT_00b0375d)[uVar12] != '\0');
  ppiStack_170 = (int **)CONCAT44(ppiStack_170._4_4_,uVar12);
  plStack_148._0_4_ = uVar4 + 2 + (uVar12 >> 1);
  if ((uint)plStack_148 < 0x20) {
    plStack_148._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)(uint)plStack_148 + 0x10;
  }
  uStack_110 = 2;
  puStack_28 = operator_new__(uVar11);
  puStack_28[2] = 1;
  puStack_28[1] = (uint)plStack_148;
  *puStack_28 = (uint)ppiStack_170;
  *(undefined1 *)((longlong)puStack_28 + (longlong)(int)(uint)ppiStack_170 + 0xc) = 0;
  if ((uint)ppiStack_170 != 0) {
    puVar8 = puStack_28 + 3;
    if (puVar8 < &DAT_00b0375d) {
      if (0 < (int)(uint)ppiStack_170) {
        lVar9 = 0;
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b0375d)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppiStack_170);
      }
    }
    else if ((&DAT_00b0375d < puVar8) && (uVar12 = (uint)ppiStack_170 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)uVar12) =
             (&DAT_00b0375d)[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 3;
  plStack_128 = plStack_188 + 5;
  FUN_004986a0(plStack_128,ppuStack_190,plStack_188,param_5);
  uVar12 = puStack_28[2];
  puStack_28[2] = uVar12 - 1;
  if ((puStack_28 != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(puStack_28);
  }
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ((&DAT_00b03704)[uVar12] != '\0');
  ppiStack_170 = (int **)CONCAT44(ppiStack_170._4_4_,uVar12);
  uVar12 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar12 < 0x20) {
    plStack_148._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)uVar12 + 0x10;
    plStack_148._0_4_ = uVar12;
  }
  uStack_110 = 4;
  puStack_28 = operator_new__(uVar11);
  puStack_28[2] = 1;
  puStack_28[1] = (uint)plStack_148;
  *puStack_28 = (uint)ppiStack_170;
  *(undefined1 *)((longlong)puStack_28 + (longlong)(int)(uint)ppiStack_170 + 0xc) = 0;
  if ((uint)ppiStack_170 != 0) {
    puVar8 = puStack_28 + 3;
    if (puVar8 < &DAT_00b03704) {
      if (0 < (int)(uint)ppiStack_170) {
        lVar9 = 0;
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b03704)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppiStack_170);
      }
    }
    else if ((&DAT_00b03704 < puVar8) && (uVar12 = (uint)ppiStack_170 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)uVar12) =
             (&DAT_00b03704)[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 5;
  plStack_120 = plStack_188 + 0x95;
  FUN_0046d8c0(plStack_120,ppuStack_190);
  uVar12 = puStack_28[2];
  puStack_28[2] = uVar12 - 1;
  if ((puStack_28 != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(puStack_28);
  }
  plStack_148 = (longlong *)CONCAT44(plStack_148._4_4_,(uint)(byte)pcStack_178);
  puStack_140 = (undefined8 *)((longlong)ppuStack_180 + 0x200000);
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ((&DAT_00b03708)[uVar12] != '\0');
  ppiStack_170 = (int **)CONCAT44(ppiStack_170._4_4_,uVar12);
  uStack_12c = uVar4 + 2 + (uVar12 >> 1);
  if (uStack_12c < 0x20) {
    uStack_12c = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)uStack_12c + 0x10;
  }
  uStack_110 = 6;
  puStack_28 = operator_new__(uVar11);
  puStack_28[2] = 1;
  puStack_28[1] = uStack_12c;
  *puStack_28 = (uint)ppiStack_170;
  *(undefined1 *)((longlong)puStack_28 + (longlong)(int)(uint)ppiStack_170 + 0xc) = 0;
  if ((uint)ppiStack_170 != 0) {
    puVar8 = puStack_28 + 3;
    if (puVar8 < &DAT_00b03708) {
      if (0 < (int)(uint)ppiStack_170) {
        lVar9 = 0;
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b03708)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppiStack_170);
      }
    }
    else if ((&DAT_00b03708 < puVar8) && (uVar12 = (uint)ppiStack_170 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)uVar12) =
             (&DAT_00b03708)[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_1a8 = 0;
  uStack_110 = 7;
  plStack_b0 = plStack_188 + 0x245a;
  uStack_1a0 = (uint)plStack_148;
  FUN_00478c50(plStack_b0,ppuStack_190,plStack_188,puStack_140);
  uVar12 = puStack_28[2];
  puStack_28[2] = uVar12 - 1;
  if ((puStack_28 != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(puStack_28);
  }
  plStack_188[0x12cd3] = 0;
  *(byte *)(plStack_188 + 0x10ccf) = (byte)pcStack_178;
  *(undefined4 *)((longlong)plStack_188 + 0x86684) = param_7;
  plStack_188[0x12cd6] = 0;
  plStack_188[0x12cda] = 0;
  plStack_188[0x12cdd] = 0;
  uStack_110 = 8;
  puVar6 = operator_new__(0x5a010);
  *puVar6 = 0xb401;
  uStack_98 = 0;
  plStack_188[0x12ce1] = (longlong)(puVar6 + 1);
  *(undefined4 *)(plStack_188 + 0x12ce2) = 0xb401;
  plStack_188[0x12ce4] = 0;
  *(undefined4 *)(plStack_188 + 0x12ce3) = 0;
  plStack_188[0x12ce0] = (longlong)ppuStack_180;
  plStack_188[0x93] = (longlong)FUN_0048ef80;
  pcStack_a0 = FUN_0048ef80;
  plStack_188[0x2458] = (longlong)FUN_0048f010;
  plStack_188[0x2456] = (longlong)FUN_00490360;
  plStack_188[0x2452] = (longlong)FUN_0048f020;
  plStack_188[0x2454] = (longlong)FUN_004910c0;
  plStack_188[0x2450] = (longlong)FUN_0048f0b0;
  ppuStack_180 = (uint **)((longlong)plStack_188 + 0x8668c);
  *(undefined4 *)((longlong)plStack_188 + 0x96714) = 0;
  plStack_188[0x92] = (longlong)plStack_188;
  plStack_188[0x94] = 0;
  plStack_188[0x2459] = 0;
  plStack_188[0x2457] = 0;
  plStack_188[0x2453] = 0;
  plStack_188[0x2455] = 0;
  plStack_188[0x2451] = 0;
  uStack_110 = 9;
  pcStack_178 = operator_new(0x20);
  *(undefined8 *)pcStack_178 = 0;
  *(undefined8 *)((longlong)pcStack_178 + 8) = 0;
  *(undefined4 *)((longlong)pcStack_178 + 0x18) = 3;
  puVar7 = operator_new__(0x48);
  *puVar7 = 8;
  puVar6 = puVar7 + 1;
  do {
    *puVar6 = 0;
    puVar6 = puVar6 + 1;
  } while (puVar6 != puVar7 + 9);
  *(undefined8 **)((longlong)pcStack_178 + 0x10) = puVar7 + 1;
  *(undefined4 *)((longlong)pcStack_178 + 0x1c) = 1;
  puStack_10 = (undefined8 *)pcStack_178;
  puStack_28 = (uint *)CONCAT44(puStack_28._4_4_,0x10000);
  uStack_18 = (undefined8 *)((ulonglong)uStack_18._4_4_ << 0x20);
  plStack_20 = (longlong *)ppuStack_180;
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ((&DAT_00b03758)[uVar12] != '\0');
  ppuStack_180 = (uint **)CONCAT44(ppuStack_180._4_4_,uVar12);
  uVar12 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar12 < 0x20) {
    uVar11 = 0x30;
    pcStack_178._0_4_ = 0x20;
  }
  else {
    uVar11 = (longlong)(int)uVar12 + 0x10;
    pcStack_178._0_4_ = uVar12;
  }
  uStack_110 = 10;
  apuStack_48[0] = operator_new__(uVar11);
  apuStack_48[0][2] = 1;
  apuStack_48[0][1] = (uint)pcStack_178;
  *apuStack_48[0] = (uint)ppuStack_180;
  *(undefined1 *)((longlong)apuStack_48[0] + (longlong)(int)(uint)ppuStack_180 + 0xc) = 0;
  if ((uint)ppuStack_180 != 0) {
    puVar8 = apuStack_48[0] + 3;
    if (puVar8 < &DAT_00b03758) {
      if (0 < (int)(uint)ppuStack_180) {
        lVar9 = 0;
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b03758)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppuStack_180);
      }
    }
    else if ((&DAT_00b03758 < puVar8) &&
            (ppuStack_180._0_4_ = (uint)ppuStack_180 - 1, -1 < (int)(uint)ppuStack_180)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)(uint)ppuStack_180) =
             (&DAT_00b03758)[uVar11 + (longlong)(int)(uint)ppuStack_180];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)(uint)ppuStack_180);
    }
  }
  ppuStack_180 = apuStack_48;
  uStack_110 = 0xb;
  pcStack_178 = (code *)(plStack_188 + 4);
  FUN_0090ede0(pcStack_178,ppuStack_180,ppuStack_190);
  uVar12 = apuStack_48[0][2];
  apuStack_48[0][2] = uVar12 - 1;
  if ((apuStack_48[0] != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(apuStack_48[0]);
  }
  FUN_00916020(ppuStack_190 + 3);
  uStack_110 = 9;
  ppiStack_170 = (int **)(plStack_188 + 0x10cd1);
  plStack_148 = operator_new(0x20);
  *plStack_148 = 0;
  plStack_148[1] = 0;
  *(undefined4 *)(plStack_148 + 3) = 3;
  puVar7 = operator_new__(0x48);
  *puVar7 = 8;
  puVar6 = puVar7 + 1;
  do {
    *puVar6 = 0;
    puVar6 = puVar6 + 1;
  } while (puVar6 != puVar7 + 9);
  plStack_148[2] = (longlong)(puVar7 + 1);
  *(undefined4 *)((longlong)plStack_148 + 0x1c) = 1;
  puStack_10 = plStack_148;
  puStack_28 = (uint *)CONCAT44(puStack_28._4_4_,4);
  uStack_18 = (undefined8 *)((ulonglong)uStack_18 & 0xffffffff00000000);
  plStack_20 = (longlong *)ppiStack_170;
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ("DSPCalibration"[uVar12] != '\0');
  ppiStack_170 = (int **)CONCAT44(ppiStack_170._4_4_,uVar12);
  uVar12 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar12 < 0x20) {
    plStack_148._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)uVar12 + 0x10;
    plStack_148._0_4_ = uVar12;
  }
  uStack_110 = 0xc;
  apuStack_48[0] = operator_new__(uVar11);
  apuStack_48[0][2] = 1;
  apuStack_48[0][1] = (uint)plStack_148;
  *apuStack_48[0] = (uint)ppiStack_170;
  *(undefined1 *)((longlong)apuStack_48[0] + (longlong)(int)(uint)ppiStack_170 + 0xc) = 0;
  if ((uint)ppiStack_170 != 0) {
    puVar8 = apuStack_48[0] + 3;
    if (puVar8 < "DSPCalibration") {
      if (0 < (int)(uint)ppiStack_170) {
        lVar9 = 0;
        do {
          *(char *)((longlong)puVar8 + lVar9) = "DSPCalibration"[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppiStack_170);
      }
    }
    else if (("DSPCalibration" < puVar8) && (uVar12 = (uint)ppiStack_170 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(char *)((longlong)puVar8 + uVar11 + (longlong)(int)uVar12) =
             "DSPCalibration"[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 0xd;
  FUN_0090ede0(pcStack_178,ppuStack_180,ppuStack_190);
  uVar12 = apuStack_48[0][2];
  apuStack_48[0][2] = uVar12 - 1;
  if ((apuStack_48[0] != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(apuStack_48[0]);
  }
  FUN_00916020(ppuStack_190 + 3);
  auStack_88[0] = 4;
  uStack_110 = 9;
  puStack_168 = operator_new(8);
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ((&DAT_00b03753)[uVar12] != '\0');
  uVar4 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar4 < 0x20) {
    plStack_148._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)uVar4 + 0x10;
    plStack_148._0_4_ = uVar4;
  }
  uStack_110 = 0x22;
  ppiStack_170._0_4_ = uVar12;
  puVar8 = operator_new__(uVar11);
  puVar8[2] = 1;
  puVar8[1] = (uint)plStack_148;
  *puVar8 = (uint)ppiStack_170;
  *(undefined1 *)((longlong)puVar8 + (longlong)(int)(uint)ppiStack_170 + 0xc) = 0;
  *puStack_168 = puVar8;
  if ((uint)ppiStack_170 != 0) {
    puVar8 = puVar8 + 3;
    if (puVar8 < &DAT_00b03753) {
      lVar9 = 0;
      if (0 < (int)(uint)ppiStack_170) {
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b03753)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppiStack_170);
      }
    }
    else if ((&DAT_00b03753 < puVar8) &&
            (ppiStack_170._0_4_ = (uint)ppiStack_170 - 1, -1 < (int)(uint)ppiStack_170)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)(uint)ppiStack_170) =
             (&DAT_00b03753)[uVar11 + (longlong)(int)(uint)ppiStack_170];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)(uint)ppiStack_170);
    }
  }
  puStack_78 = puStack_168;
  ppiStack_170._0_4_ = 0;
  do {
    uVar12 = (uint)ppiStack_170;
    ppiStack_170._0_4_ = uVar12 + 1;
  } while ((&DAT_00b0371b)[(uint)ppiStack_170] != '\0');
  plStack_148._0_4_ = uVar12 + 2 + ((uint)ppiStack_170 >> 1);
  if ((uint)plStack_148 < 0x20) {
    plStack_148._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)(uint)plStack_148 + 0x10;
  }
  uStack_110 = 0xe;
  puStack_28 = operator_new__(uVar11);
  puStack_28[2] = 1;
  puStack_28[1] = (uint)plStack_148;
  *puStack_28 = (uint)ppiStack_170;
  *(undefined1 *)((longlong)puStack_28 + (longlong)(int)(uint)ppiStack_170 + 0xc) = 0;
  if ((uint)ppiStack_170 != 0) {
    puVar8 = puStack_28 + 3;
    if (puVar8 < &DAT_00b0371b) {
      lVar9 = 0;
      if (0 < (int)(uint)ppiStack_170) {
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b0371b)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppiStack_170);
      }
    }
    else if ((&DAT_00b0371b < puVar8) &&
            (ppiStack_170._0_4_ = (uint)ppiStack_170 - 1, -1 < (int)(uint)ppiStack_170)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)(uint)ppiStack_170) =
             (&DAT_00b0371b)[uVar11 + (longlong)(int)(uint)ppiStack_170];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)(uint)ppiStack_170);
    }
  }
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ("DSPCalibration"[uVar12] != '\0');
  ppiStack_170 = (int **)CONCAT44(ppiStack_170._4_4_,uVar12);
  plStack_148._0_4_ = uVar4 + 2 + (uVar12 >> 1);
  if ((uint)plStack_148 < 0x20) {
    plStack_148._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)(uint)plStack_148 + 0x10;
  }
  uStack_110 = 0xf;
  apuStack_48[0] = operator_new__(uVar11);
  apuStack_48[0][2] = 1;
  apuStack_48[0][1] = (uint)plStack_148;
  *apuStack_48[0] = (uint)ppiStack_170;
  *(undefined1 *)((longlong)apuStack_48[0] + (longlong)(int)(uint)ppiStack_170 + 0xc) = 0;
  if ((uint)ppiStack_170 != 0) {
    puVar8 = apuStack_48[0] + 3;
    if (puVar8 < "DSPCalibration") {
      if (0 < (int)(uint)ppiStack_170) {
        lVar9 = 0;
        do {
          *(char *)((longlong)puVar8 + lVar9) = "DSPCalibration"[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppiStack_170);
      }
    }
    else if (("DSPCalibration" < puVar8) && (uVar12 = (uint)ppiStack_170 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(char *)((longlong)puVar8 + uVar11 + (longlong)(int)uVar12) =
             "DSPCalibration"[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 0x10;
  lVar9 = FUN_00910c20(pcStack_178,ppuStack_180);
  uStack_110 = 0x10;
  uVar10 = FUN_00917050(lVar9 + 0x18,ppuStack_190);
  ppiStack_170 = (int **)auStack_88;
  FUN_005912e0(uVar10,ppiStack_170);
  uVar12 = apuStack_48[0][2];
  apuStack_48[0][2] = uVar12 - 1;
  if ((apuStack_48[0] != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(apuStack_48[0]);
  }
  uVar12 = puStack_28[2];
  puStack_28[2] = uVar12 - 1;
  if ((puStack_28 != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(puStack_28);
  }
  FUN_00952e50(ppiStack_170);
  uStack_110 = 9;
  ppiStack_170 = (int **)((longlong)plStack_188 + 0x9668c);
  plStack_148 = operator_new(0x20);
  *plStack_148 = 0;
  plStack_148[1] = 0;
  *(undefined4 *)(plStack_148 + 3) = 3;
  puVar7 = operator_new__(0x48);
  *puVar7 = 8;
  puVar6 = puVar7 + 1;
  do {
    *puVar6 = 0;
    puVar6 = puVar6 + 1;
  } while (puVar6 != puVar7 + 9);
  plStack_148[2] = (longlong)(puVar7 + 1);
  *(undefined4 *)((longlong)plStack_148 + 0x1c) = 1;
  puStack_10 = plStack_148;
  puStack_28 = (uint *)CONCAT44(puStack_28._4_4_,4);
  uStack_18 = (undefined8 *)((ulonglong)uStack_18 & 0xffffffff00000000);
  plStack_20 = (longlong *)ppiStack_170;
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ("TimersTickAccum"[uVar12] != '\0');
  ppiStack_170 = (int **)CONCAT44(ppiStack_170._4_4_,uVar12);
  uVar12 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar12 < 0x20) {
    plStack_148._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)uVar12 + 0x10;
    plStack_148._0_4_ = uVar12;
  }
  uStack_110 = 0x11;
  apuStack_48[0] = operator_new__(uVar11);
  apuStack_48[0][2] = 1;
  apuStack_48[0][1] = (uint)plStack_148;
  *apuStack_48[0] = (uint)ppiStack_170;
  *(undefined1 *)((longlong)apuStack_48[0] + (longlong)(int)(uint)ppiStack_170 + 0xc) = 0;
  if ((uint)ppiStack_170 != 0) {
    puVar8 = apuStack_48[0] + 3;
    if (puVar8 < "TimersTickAccum") {
      if (0 < (int)(uint)ppiStack_170) {
        lVar9 = 0;
        do {
          *(char *)((longlong)puVar8 + lVar9) = "TimersTickAccum"[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppiStack_170);
      }
    }
    else if (("TimersTickAccum" < puVar8) && (uVar12 = (uint)ppiStack_170 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(char *)((longlong)puVar8 + uVar11 + (longlong)(int)uVar12) =
             "TimersTickAccum"[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 0x12;
  FUN_0090ede0(pcStack_178,ppuStack_180,ppuStack_190);
  uVar12 = apuStack_48[0][2];
  apuStack_48[0][2] = uVar12 - 1;
  if ((apuStack_48[0] != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(apuStack_48[0]);
  }
  FUN_00916020(ppuStack_190 + 3);
  apiStack_68[0] = (int *)CONCAT44(apiStack_68[0]._4_4_,4);
  uStack_110 = 9;
  puStack_160 = operator_new(8);
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ((&DAT_00b03720)[uVar12] != '\0');
  uVar4 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar4 < 0x20) {
    plStack_148._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)uVar4 + 0x10;
    plStack_148._0_4_ = uVar4;
  }
  uStack_110 = 0x23;
  ppiStack_170._0_4_ = uVar12;
  puVar8 = operator_new__(uVar11);
  puVar8[2] = 1;
  puVar8[1] = (uint)plStack_148;
  *puVar8 = (uint)ppiStack_170;
  *(undefined1 *)((longlong)puVar8 + (longlong)(int)(uint)ppiStack_170 + 0xc) = 0;
  *puStack_160 = puVar8;
  if ((uint)ppiStack_170 != 0) {
    puVar8 = puVar8 + 3;
    if (puVar8 < &DAT_00b03720) {
      lVar9 = 0;
      if (0 < (int)(uint)ppiStack_170) {
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b03720)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppiStack_170);
      }
    }
    else if ((&DAT_00b03720 < puVar8) &&
            (ppiStack_170._0_4_ = (uint)ppiStack_170 - 1, -1 < (int)(uint)ppiStack_170)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)(uint)ppiStack_170) =
             (&DAT_00b03720)[uVar11 + (longlong)(int)(uint)ppiStack_170];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)(uint)ppiStack_170);
    }
  }
  puStack_58 = puStack_160;
  ppiStack_170._0_4_ = 0;
  do {
    uVar12 = (uint)ppiStack_170;
    ppiStack_170._0_4_ = uVar12 + 1;
  } while ((&DAT_00b0371b)[(uint)ppiStack_170] != '\0');
  plStack_148._0_4_ = uVar12 + 2 + ((uint)ppiStack_170 >> 1);
  if ((uint)plStack_148 < 0x20) {
    plStack_148._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)(uint)plStack_148 + 0x10;
  }
  uStack_110 = 0x13;
  puStack_28 = operator_new__(uVar11);
  puStack_28[2] = 1;
  puStack_28[1] = (uint)plStack_148;
  *puStack_28 = (uint)ppiStack_170;
  *(undefined1 *)((longlong)puStack_28 + (longlong)(int)(uint)ppiStack_170 + 0xc) = 0;
  if ((uint)ppiStack_170 != 0) {
    puVar8 = puStack_28 + 3;
    if (puVar8 < &DAT_00b0371b) {
      lVar9 = 0;
      if (0 < (int)(uint)ppiStack_170) {
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b0371b)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppiStack_170);
      }
    }
    else if ((&DAT_00b0371b < puVar8) &&
            (ppiStack_170._0_4_ = (uint)ppiStack_170 - 1, -1 < (int)(uint)ppiStack_170)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)(uint)ppiStack_170) =
             (&DAT_00b0371b)[uVar11 + (longlong)(int)(uint)ppiStack_170];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)(uint)ppiStack_170);
    }
  }
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ("TimersTickAccum"[uVar12] != '\0');
  ppiStack_170 = (int **)CONCAT44(ppiStack_170._4_4_,uVar12);
  plStack_148._0_4_ = uVar4 + 2 + (uVar12 >> 1);
  if ((uint)plStack_148 < 0x20) {
    plStack_148._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)(uint)plStack_148 + 0x10;
  }
  uStack_110 = 0x14;
  apuStack_48[0] = operator_new__(uVar11);
  apuStack_48[0][2] = 1;
  apuStack_48[0][1] = (uint)plStack_148;
  *apuStack_48[0] = (uint)ppiStack_170;
  *(undefined1 *)((longlong)apuStack_48[0] + (longlong)(int)(uint)ppiStack_170 + 0xc) = 0;
  if ((uint)ppiStack_170 != 0) {
    puVar8 = apuStack_48[0] + 3;
    if (puVar8 < "TimersTickAccum") {
      if (0 < (int)(uint)ppiStack_170) {
        lVar9 = 0;
        do {
          *(char *)((longlong)puVar8 + lVar9) = "TimersTickAccum"[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppiStack_170);
      }
    }
    else if (("TimersTickAccum" < puVar8) && (uVar12 = (uint)ppiStack_170 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(char *)((longlong)puVar8 + uVar11 + (longlong)(int)uVar12) =
             "TimersTickAccum"[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 0x15;
  lVar9 = FUN_00910c20(pcStack_178,ppuStack_180);
  uStack_110 = 0x15;
  uVar10 = FUN_00917050(lVar9 + 0x18,ppuStack_190);
  ppiStack_170 = apiStack_68;
  FUN_005912e0(uVar10,ppiStack_170);
  uVar12 = apuStack_48[0][2];
  apuStack_48[0][2] = uVar12 - 1;
  if ((apuStack_48[0] != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(apuStack_48[0]);
  }
  uVar12 = puStack_28[2];
  puStack_28[2] = uVar12 - 1;
  if ((puStack_28 != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(puStack_28);
  }
  FUN_00952e50(ppiStack_170);
  uStack_110 = 9;
  plStack_148 = plStack_188 + 0x12cd2;
  puStack_140 = operator_new(0x20);
  *puStack_140 = 0;
  puStack_140[1] = 0;
  *(undefined4 *)(puStack_140 + 3) = 3;
  puVar7 = operator_new__(0x48);
  *puVar7 = 8;
  puVar6 = puVar7 + 1;
  do {
    *puVar6 = 0;
    puVar6 = puVar6 + 1;
  } while (puVar6 != puVar7 + 9);
  puStack_140[2] = puVar7 + 1;
  *(undefined4 *)((longlong)puStack_140 + 0x1c) = 1;
  puStack_10 = puStack_140;
  puStack_28 = (uint *)CONCAT44(puStack_28._4_4_,4);
  uStack_18 = (undefined8 *)((ulonglong)uStack_18 & 0xffffffff00000000);
  plStack_20 = plStack_148;
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ("AudioTickAccum"[uVar12] != '\0');
  plStack_148 = (longlong *)CONCAT44(plStack_148._4_4_,uVar12);
  uVar12 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar12 < 0x20) {
    puStack_140._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)uVar12 + 0x10;
    puStack_140._0_4_ = uVar12;
  }
  uStack_110 = 0x16;
  apuStack_48[0] = operator_new__(uVar11);
  apuStack_48[0][2] = 1;
  apuStack_48[0][1] = (uint)puStack_140;
  *apuStack_48[0] = (uint)plStack_148;
  *(undefined1 *)((longlong)apuStack_48[0] + (longlong)(int)(uint)plStack_148 + 0xc) = 0;
  if ((uint)plStack_148 != 0) {
    puVar8 = apuStack_48[0] + 3;
    if (puVar8 < "AudioTickAccum") {
      if (0 < (int)(uint)plStack_148) {
        lVar9 = 0;
        do {
          *(char *)((longlong)puVar8 + lVar9) = "AudioTickAccum"[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)plStack_148);
      }
    }
    else if (("AudioTickAccum" < puVar8) && (uVar12 = (uint)plStack_148 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(char *)((longlong)puVar8 + uVar11 + (longlong)(int)uVar12) =
             "AudioTickAccum"[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 0x17;
  FUN_0090ede0(pcStack_178,ppuStack_180,ppuStack_190);
  uVar12 = apuStack_48[0][2];
  apuStack_48[0][2] = uVar12 - 1;
  if ((apuStack_48[0] != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(apuStack_48[0]);
  }
  FUN_00916020(ppuStack_190 + 3);
  apuStack_48[0] = (uint *)CONCAT44(apuStack_48[0]._4_4_,4);
  uStack_110 = 9;
  puStack_158 = operator_new(8);
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ((&DAT_00b03720)[uVar12] != '\0');
  uVar4 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar4 < 0x20) {
    puStack_140._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)uVar4 + 0x10;
    puStack_140._0_4_ = uVar4;
  }
  uStack_110 = 0x24;
  plStack_148._0_4_ = uVar12;
  puVar8 = operator_new__(uVar11);
  puVar8[2] = 1;
  puVar8[1] = (uint)puStack_140;
  *puVar8 = (uint)plStack_148;
  *(undefined1 *)((longlong)puVar8 + (longlong)(int)(uint)plStack_148 + 0xc) = 0;
  *puStack_158 = puVar8;
  if ((uint)plStack_148 != 0) {
    puVar8 = puVar8 + 3;
    if (puVar8 < &DAT_00b03720) {
      lVar9 = 0;
      if (0 < (int)(uint)plStack_148) {
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b03720)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)plStack_148);
      }
    }
    else if ((&DAT_00b03720 < puVar8) &&
            (plStack_148._0_4_ = (uint)plStack_148 - 1, -1 < (int)(uint)plStack_148)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)(uint)plStack_148) =
             (&DAT_00b03720)[uVar11 + (longlong)(int)(uint)plStack_148];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)(uint)plStack_148);
    }
  }
  puStack_38 = puStack_158;
  plStack_148._0_4_ = 0;
  do {
    uVar12 = (uint)plStack_148;
    plStack_148._0_4_ = uVar12 + 1;
  } while ((&DAT_00b0371b)[(uint)plStack_148] != '\0');
  puStack_140._0_4_ = uVar12 + 2 + ((uint)plStack_148 >> 1);
  if ((uint)puStack_140 < 0x20) {
    puStack_140._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)(uint)puStack_140 + 0x10;
  }
  uStack_110 = 0x18;
  puStack_28 = operator_new__(uVar11);
  puStack_28[2] = 1;
  puStack_28[1] = (uint)puStack_140;
  *puStack_28 = (uint)plStack_148;
  *(undefined1 *)((longlong)puStack_28 + (longlong)(int)(uint)plStack_148 + 0xc) = 0;
  if ((uint)plStack_148 != 0) {
    puVar8 = puStack_28 + 3;
    if (puVar8 < &DAT_00b0371b) {
      lVar9 = 0;
      if (0 < (int)(uint)plStack_148) {
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b0371b)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)plStack_148);
      }
    }
    else if ((&DAT_00b0371b < puVar8) &&
            (plStack_148._0_4_ = (uint)plStack_148 - 1, -1 < (int)(uint)plStack_148)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)(uint)plStack_148) =
             (&DAT_00b0371b)[uVar11 + (longlong)(int)(uint)plStack_148];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)(uint)plStack_148);
    }
  }
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ("AudioTickAccum"[uVar12] != '\0');
  plStack_148 = (longlong *)CONCAT44(plStack_148._4_4_,uVar12);
  puStack_140._0_4_ = uVar4 + 2 + (uVar12 >> 1);
  if ((uint)puStack_140 < 0x20) {
    puStack_140._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)(uint)puStack_140 + 0x10;
  }
  uStack_110 = 0x19;
  apiStack_68[0] = operator_new__(uVar11);
  apiStack_68[0][2] = 1;
  apiStack_68[0][1] = (uint)puStack_140;
  *apiStack_68[0] = (uint)plStack_148;
  *(undefined1 *)((longlong)apiStack_68[0] + (longlong)(int)(uint)plStack_148 + 0xc) = 0;
  if ((uint)plStack_148 != 0) {
    piVar1 = apiStack_68[0] + 3;
    if (piVar1 < "AudioTickAccum") {
      if (0 < (int)(uint)plStack_148) {
        lVar9 = 0;
        do {
          *(char *)((longlong)piVar1 + lVar9) = "AudioTickAccum"[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)plStack_148);
      }
    }
    else if (("AudioTickAccum" < piVar1) && (uVar12 = (uint)plStack_148 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(char *)((longlong)piVar1 + uVar11 + (longlong)(int)uVar12) =
             "AudioTickAccum"[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 0x1a;
  lVar9 = FUN_00910c20(pcStack_178,ppiStack_170);
  uStack_110 = 0x1a;
  uVar10 = FUN_00917050(lVar9 + 0x18,ppuStack_190);
  FUN_005912e0(uVar10,ppuStack_180);
  iVar2 = apiStack_68[0][2];
  apiStack_68[0][2] = iVar2 + -1;
  if ((apiStack_68[0] != (int *)&DAT_00cfd470) && (iVar2 + -1 == 0)) {
    operator_delete__(apiStack_68[0]);
  }
  uVar12 = puStack_28[2];
  puStack_28[2] = uVar12 - 1;
  if ((puStack_28 != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(puStack_28);
  }
  FUN_00952e50(ppuStack_180);
  uStack_110 = 9;
  plStack_148 = (longlong *)((longlong)plStack_188 + 0x96694);
  puStack_140 = operator_new(0x20);
  *puStack_140 = 0;
  puStack_140[1] = 0;
  *(undefined4 *)(puStack_140 + 3) = 3;
  puVar7 = operator_new__(0x48);
  *puVar7 = 8;
  puVar6 = puVar7 + 1;
  do {
    *puVar6 = 0;
    puVar6 = puVar6 + 1;
  } while (puVar6 != puVar7 + 9);
  puStack_140[2] = puVar7 + 1;
  *(undefined4 *)((longlong)puStack_140 + 0x1c) = 1;
  puStack_10 = puStack_140;
  puStack_28 = (uint *)CONCAT44(puStack_28._4_4_,4);
  uStack_18 = (undefined8 *)((ulonglong)uStack_18 & 0xffffffff00000000);
  plStack_20 = plStack_148;
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ("VDLPTickAccum"[uVar12] != '\0');
  plStack_148 = (longlong *)CONCAT44(plStack_148._4_4_,uVar12);
  uVar12 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar12 < 0x20) {
    puStack_140._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)uVar12 + 0x10;
    puStack_140._0_4_ = uVar12;
  }
  uStack_110 = 0x1b;
  apuStack_48[0] = operator_new__(uVar11);
  apuStack_48[0][2] = 1;
  apuStack_48[0][1] = (uint)puStack_140;
  *apuStack_48[0] = (uint)plStack_148;
  *(undefined1 *)((longlong)apuStack_48[0] + (longlong)(int)(uint)plStack_148 + 0xc) = 0;
  if ((uint)plStack_148 != 0) {
    puVar8 = apuStack_48[0] + 3;
    if (puVar8 < "VDLPTickAccum") {
      if (0 < (int)(uint)plStack_148) {
        lVar9 = 0;
        do {
          *(char *)((longlong)puVar8 + lVar9) = "VDLPTickAccum"[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)plStack_148);
      }
    }
    else if (("VDLPTickAccum" < puVar8) && (uVar12 = (uint)plStack_148 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(char *)((longlong)puVar8 + uVar11 + (longlong)(int)uVar12) =
             "VDLPTickAccum"[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 0x1c;
  FUN_0090ede0(pcStack_178,ppuStack_180,ppuStack_190);
  uVar12 = apuStack_48[0][2];
  apuStack_48[0][2] = uVar12 - 1;
  if ((apuStack_48[0] != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(apuStack_48[0]);
  }
  FUN_00916020(ppuStack_190 + 3);
  puStack_28 = (uint *)CONCAT44(puStack_28._4_4_,4);
  uStack_110 = 9;
  puStack_150 = operator_new(8);
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ((&DAT_00b03720)[uVar12] != '\0');
  uVar4 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar4 < 0x20) {
    puStack_140._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)uVar4 + 0x10;
    puStack_140._0_4_ = uVar4;
  }
  uStack_110 = 0x25;
  plStack_148._0_4_ = uVar12;
  puVar8 = operator_new__(uVar11);
  puVar8[2] = 1;
  puVar8[1] = (uint)puStack_140;
  *puVar8 = (uint)plStack_148;
  *(undefined1 *)((longlong)puVar8 + (longlong)(int)(uint)plStack_148 + 0xc) = 0;
  *puStack_150 = puVar8;
  if ((uint)plStack_148 != 0) {
    puVar8 = puVar8 + 3;
    if (puVar8 < &DAT_00b03720) {
      lVar9 = 0;
      if (0 < (int)(uint)plStack_148) {
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b03720)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)plStack_148);
      }
    }
    else if ((&DAT_00b03720 < puVar8) &&
            (plStack_148._0_4_ = (uint)plStack_148 - 1, -1 < (int)(uint)plStack_148)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)(uint)plStack_148) =
             (&DAT_00b03720)[uVar11 + (longlong)(int)(uint)plStack_148];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)(uint)plStack_148);
    }
  }
  uStack_18 = puStack_150;
  plStack_148._0_4_ = 0;
  do {
    uVar12 = (uint)plStack_148;
    plStack_148._0_4_ = uVar12 + 1;
  } while ((&DAT_00b0371b)[(uint)plStack_148] != '\0');
  puStack_140._0_4_ = uVar12 + 2 + ((uint)plStack_148 >> 1);
  if ((uint)puStack_140 < 0x20) {
    puStack_140._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)(uint)puStack_140 + 0x10;
  }
  uStack_110 = 0x1d;
  apuStack_48[0] = operator_new__(uVar11);
  apuStack_48[0][2] = 1;
  apuStack_48[0][1] = (uint)puStack_140;
  *apuStack_48[0] = (uint)plStack_148;
  *(undefined1 *)((longlong)apuStack_48[0] + (longlong)(int)(uint)plStack_148 + 0xc) = 0;
  if ((uint)plStack_148 != 0) {
    puVar8 = apuStack_48[0] + 3;
    if (puVar8 < &DAT_00b0371b) {
      lVar9 = 0;
      if (0 < (int)(uint)plStack_148) {
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b0371b)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)plStack_148);
      }
    }
    else if ((&DAT_00b0371b < puVar8) &&
            (plStack_148._0_4_ = (uint)plStack_148 - 1, -1 < (int)(uint)plStack_148)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)(uint)plStack_148) =
             (&DAT_00b0371b)[uVar11 + (longlong)(int)(uint)plStack_148];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)(uint)plStack_148);
    }
  }
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ("VDLPTickAccum"[uVar12] != '\0');
  plStack_148 = (longlong *)CONCAT44(plStack_148._4_4_,uVar12);
  puStack_140._0_4_ = uVar4 + 2 + (uVar12 >> 1);
  if ((uint)puStack_140 < 0x20) {
    puStack_140._0_4_ = 0x20;
    uVar11 = 0x30;
  }
  else {
    uVar11 = (longlong)(int)(uint)puStack_140 + 0x10;
  }
  uStack_110 = 0x1e;
  apiStack_68[0] = operator_new__(uVar11);
  apiStack_68[0][2] = 1;
  apiStack_68[0][1] = (uint)puStack_140;
  *apiStack_68[0] = (uint)plStack_148;
  *(undefined1 *)((longlong)apiStack_68[0] + (longlong)(int)(uint)plStack_148 + 0xc) = 0;
  if ((uint)plStack_148 != 0) {
    piVar1 = apiStack_68[0] + 3;
    if (piVar1 < "VDLPTickAccum") {
      if (0 < (int)(uint)plStack_148) {
        lVar9 = 0;
        do {
          *(char *)((longlong)piVar1 + lVar9) = "VDLPTickAccum"[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)plStack_148);
      }
    }
    else if (("VDLPTickAccum" < piVar1) && (uVar12 = (uint)plStack_148 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(char *)((longlong)piVar1 + uVar11 + (longlong)(int)uVar12) =
             "VDLPTickAccum"[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 0x1f;
  lVar9 = FUN_00910c20(pcStack_178,ppiStack_170);
  uStack_110 = 0x1f;
  uVar10 = FUN_00917050(lVar9 + 0x18,ppuStack_180);
  FUN_005912e0(uVar10,ppuStack_190);
  iVar2 = apiStack_68[0][2];
  apiStack_68[0][2] = iVar2 + -1;
  if ((apiStack_68[0] != (int *)&DAT_00cfd470) && (iVar2 + -1 == 0)) {
    operator_delete__(apiStack_68[0]);
  }
  uVar12 = apuStack_48[0][2];
  apuStack_48[0][2] = uVar12 - 1;
  if ((apuStack_48[0] != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(apuStack_48[0]);
  }
  FUN_00952e50(ppuStack_190);
  pcStack_178 = *(code **)(*_DAT_00cf4050 + 0xe8);
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ((&DAT_00b03708)[uVar12] != '\0');
  ppuStack_180 = (uint **)CONCAT44(ppuStack_180._4_4_,uVar12);
  uVar12 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar12 < 0x20) {
    uVar11 = 0x30;
    ppiStack_170._0_4_ = 0x20;
  }
  else {
    uVar11 = (longlong)(int)uVar12 + 0x10;
    ppiStack_170._0_4_ = uVar12;
  }
  uStack_110 = 9;
  puStack_28 = operator_new__(uVar11);
  puStack_28[2] = 1;
  puStack_28[1] = (uint)ppiStack_170;
  *puStack_28 = (uint)ppuStack_180;
  *(undefined1 *)((longlong)puStack_28 + (longlong)(int)(uint)ppuStack_180 + 0xc) = 0;
  if ((uint)ppuStack_180 != 0) {
    puVar8 = puStack_28 + 3;
    if (puVar8 < &DAT_00b03708) {
      if (0 < (int)(uint)ppuStack_180) {
        lVar9 = 0;
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b03708)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppuStack_180);
      }
    }
    else if ((&DAT_00b03708 < puVar8) && (uVar12 = (uint)ppuStack_180 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)uVar12) =
             (&DAT_00b03708)[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 0x20;
  uVar5 = (*pcStack_178)(_DAT_00cf4050,ppuStack_190,0);
  *(undefined4 *)((longlong)plStack_188 + 0x86674) = uVar5;
  uVar12 = puStack_28[2];
  puStack_28[2] = uVar12 - 1;
  if ((puStack_28 != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(puStack_28);
  }
  pcStack_178 = *(code **)(*_DAT_00cf4050 + 0xe8);
  uVar12 = 0;
  do {
    uVar4 = uVar12;
    uVar12 = uVar4 + 1;
  } while ((&DAT_00b03704)[uVar12] != '\0');
  ppuStack_180 = (uint **)CONCAT44(ppuStack_180._4_4_,uVar12);
  uVar12 = uVar4 + 2 + (uVar12 >> 1);
  if (uVar12 < 0x20) {
    uVar11 = 0x30;
    ppiStack_170._0_4_ = 0x20;
  }
  else {
    uVar11 = (longlong)(int)uVar12 + 0x10;
    ppiStack_170._0_4_ = uVar12;
  }
  uStack_110 = 9;
  puStack_28 = operator_new__(uVar11);
  puStack_28[2] = 1;
  puStack_28[1] = (uint)ppiStack_170;
  *puStack_28 = (uint)ppuStack_180;
  *(undefined1 *)((longlong)puStack_28 + (longlong)(int)(uint)ppuStack_180 + 0xc) = 0;
  if ((uint)ppuStack_180 != 0) {
    puVar8 = puStack_28 + 3;
    if (puVar8 < &DAT_00b03704) {
      if (0 < (int)(uint)ppuStack_180) {
        lVar9 = 0;
        do {
          *(undefined *)((longlong)puVar8 + lVar9) = (&DAT_00b03704)[lVar9];
          lVar9 = lVar9 + 1;
        } while ((int)lVar9 < (int)(uint)ppuStack_180);
      }
    }
    else if ((&DAT_00b03704 < puVar8) && (uVar12 = (uint)ppuStack_180 - 1, -1 < (int)uVar12)) {
      uVar11 = 0;
      do {
        *(undefined *)((longlong)puVar8 + uVar11 + (longlong)(int)uVar12) =
             (&DAT_00b03704)[uVar11 + (longlong)(int)uVar12];
        uVar11 = uVar11 - 1;
      } while (uVar11 != ~(ulonglong)uVar12);
    }
  }
  uStack_110 = 0x21;
  uVar5 = (*pcStack_178)(_DAT_00cf4050,ppuStack_190,0);
  *(undefined4 *)(plStack_188 + 0x10cce) = uVar5;
  uVar12 = puStack_28[2];
  puStack_28[2] = uVar12 - 1;
  if ((puStack_28 != (uint *)&DAT_00cfd470) && (uVar12 - 1 == 0)) {
    operator_delete__(puStack_28);
  }
  plVar3 = _DAT_00cf4050;
  *(undefined4 *)(plStack_188 + 0x10cd1) = 0;
  *(undefined4 *)((longlong)plStack_188 + 0x9668c) = 0;
  *(undefined4 *)(plStack_188 + 0x12cd2) = 0;
  *(undefined4 *)((longlong)plStack_188 + 0x96694) = 0;
  *(undefined1 *)(plStack_188 + 0x10cd0) = 0;
  uStack_110 = 9;
  uVar5 = FUN_0047ba00(plVar3);
  *(undefined4 *)((longlong)plStack_188 + 0x8667c) = uVar5;
  (**(code **)(*plStack_188 + 0x78))(plStack_188,plStack_188,1,0);
  _Unwind_SjLj_Unregister(puStack_138);
  return;
}


