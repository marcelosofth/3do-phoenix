// FUN_004a0920 @ 004a0920 size=697
// callers: 
// callees: 004894c0:FUN_004894c0 00422800:FUN_00422800 00423870:FUN_00423870 00490890:FUN_00490890 00421e70:FUN_00421e70 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a0920(longlong param_1)

{
  longlong lVar1;
  uint uVar2;
  int iVar3;
  code *pcVar4;
  uint *puVar5;
  int iVar6;
  uint uVar7;
  
  iVar6 = 0x40000;
  lVar1 = param_1 + 0x48;
  (**(code **)(*_DAT_00cf4050 + 0xd0))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x34));
  do {
    uVar7 = 0;
    while (uVar7 < *(uint *)(param_1 + 0x1297558)) {
      while( true ) {
        if (*(int *)(param_1 + 0x159f560) == *(int *)(param_1 + 0x154)) {
          uVar7 = *(int *)(param_1 + 0x1297558) + uVar7;
          goto LAB_004a0a33;
        }
        if (*(int *)(*(longlong *)(param_1 + 0x1097548) + 0x10000ec) == 0x10) {
          puVar5 = (uint *)FUN_00421e70(lVar1,0xffffffff);
          if ((*puVar5 & 0x1f) != 0x11) {
            if (*(uint *)(param_1 + 0x1297558) < *(uint *)(param_1 + 0x2c)) {
              uVar7 = *(int *)(param_1 + 0x1297558) + uVar7;
              *(int *)(param_1 + 0x2c) = *(int *)(param_1 + 0x2c) - *(int *)(param_1 + 0x1297558);
            }
            else {
              iVar3 = *(int *)(param_1 + 0x2c);
              *(undefined4 *)(param_1 + 0x2c) = 0;
              uVar7 = iVar3 + uVar7;
              FUN_004894c0(*(undefined8 *)(param_1 + 0x1097548),0);
            }
            goto LAB_004a0a33;
          }
          FUN_004894c0(*(undefined8 *)(param_1 + 0x1097548),0x30);
        }
        iVar3 = FUN_00423870(lVar1);
        uVar7 = uVar7 + iVar3;
        if ((((*(uint *)(param_1 + 0x1087494) & *(uint *)(param_1 + 0x108749c) & 0x7fffffff) == 0)
            && ((*(uint *)(param_1 + 0x10874b4) & *(uint *)(param_1 + 0x10874bc)) == 0)) ||
           (uVar2 = *(uint *)(param_1 + 0x1c8), (uVar2 & 0x40) != 0)) break;
        *(uint *)(param_1 + 0x1b4) = uVar2;
        *(uint *)(param_1 + 0x1c8) = uVar2 | 0xc0;
        FUN_00422800(lVar1,0x11);
        *(uint *)(param_1 + 0x1c8) = *(uint *)(param_1 + 0x1c8) & 0xffffffe0 | 0x11;
        if (*(longlong *)(param_1 + 0x70) != 0) {
          pcVar4 = *(code **)(param_1 + 0x78);
          if (((ulonglong)pcVar4 & 1) != 0) {
            pcVar4 = *(code **)(pcVar4 + *(longlong *)
                                          (*(longlong *)(param_1 + 0x70) +
                                          *(longlong *)(param_1 + 0x80)) + -1);
          }
          (*pcVar4)();
        }
        iVar3 = *(int *)(param_1 + 0x154);
        *(undefined4 *)(param_1 + 0x154) = 0x1c;
        *(int *)(param_1 + 0x150) = iVar3 + 4;
        if (*(uint *)(param_1 + 0x1297558) <= uVar7) goto LAB_004a0a33;
      }
    }
LAB_004a0a33:
    iVar6 = iVar6 - uVar7;
    *(int *)(param_1 + 0x28) = *(int *)(param_1 + 0x28) + uVar7;
    FUN_00490890(param_1 + 0x1000dc8,(int)(*(int *)(param_1 + 0x40) * uVar7) >> 4);
    if ((((*(uint *)(param_1 + 0x1087494) & *(uint *)(param_1 + 0x108749c) & 0x7fffffff) != 0) ||
        ((*(uint *)(param_1 + 0x10874b4) & *(uint *)(param_1 + 0x10874bc)) != 0)) &&
       (uVar7 = *(uint *)(param_1 + 0x1c8), (uVar7 & 0x40) == 0)) {
      *(uint *)(param_1 + 0x1b4) = uVar7;
      *(uint *)(param_1 + 0x1c8) = uVar7 | 0xc0;
      FUN_00422800(lVar1,0x11);
      *(uint *)(param_1 + 0x1c8) = *(uint *)(param_1 + 0x1c8) & 0xffffffe0 | 0x11;
      if (*(longlong *)(param_1 + 0x70) != 0) {
        pcVar4 = *(code **)(param_1 + 0x78);
        if (((ulonglong)pcVar4 & 1) != 0) {
          pcVar4 = *(code **)(pcVar4 + *(longlong *)
                                        (*(longlong *)(param_1 + 0x70) +
                                        *(longlong *)(param_1 + 0x80)) + -1);
        }
        (*pcVar4)();
      }
      iVar3 = *(int *)(param_1 + 0x154);
      *(undefined4 *)(param_1 + 0x154) = 0x1c;
      *(int *)(param_1 + 0x150) = iVar3 + 4;
    }
    if (iVar6 < 1) {
      (**(code **)(*_DAT_00cf4050 + 0xb0))();
                    /* WARNING: Could not recover jumptable at 0x004a0aa7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*_DAT_00cf4050 + 0xd8))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x34));
      return;
    }
  } while( true );
}


