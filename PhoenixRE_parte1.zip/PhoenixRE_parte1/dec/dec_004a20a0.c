// FUN_004a20a0 @ 004a20a0 size=737
// callers: 
// callees: 0041ff00:FUN_0041ff00 008ce550:_Unwind_SjLj_Unregister 0093b430:FUN_0093b430 005941b0:FUN_005941b0 008ce548:_Unwind_SjLj_Register 00594330:FUN_00594330 0093b400:FUN_0093b400 0093cad0:FUN_0093cad0 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004a20a0(longlong param_1,int param_2)

{
  undefined1 auStack_118 [32];
  undefined4 uStack_f8;
  undefined1 *puStack_e0;
  longlong lStack_d8;
  int iStack_cc;
  undefined1 *puStack_c8;
  code *pcStack_c0;
  undefined1 *puStack_b8;
  code *pcStack_b0;
  undefined1 auStack_a8 [8];
  undefined4 uStack_a0;
  undefined *puStack_78;
  undefined *puStack_70;
  undefined1 *puStack_68;
  undefined1 *puStack_60;
  undefined1 *puStack_58;
  longlong lStack_40;
  undefined1 auStack_38 [16];
  undefined1 auStack_28 [16];
  undefined1 auStack_18 [16];
  
  puStack_68 = &stack0xfffffffffffffff8;
  puStack_58 = auStack_118;
  puStack_78 = &DAT_008ce270;
  puStack_70 = &DAT_00cc1e7c;
  puStack_60 = &LAB_004a2388;
  puStack_c8 = auStack_a8;
  lStack_d8 = param_1;
  iStack_cc = param_2;
  _Unwind_SjLj_Register(puStack_c8);
  if (iStack_cc == 2) {
    pcStack_c0 = *(code **)(*_DAT_00cf4050 + 0xf0);
    uStack_a0 = 0xffffffff;
    puStack_e0 = auStack_18;
    FUN_0093cad0(puStack_e0,"madam.bin");
    uStack_f8 = 1;
    uStack_a0 = 1;
    (*pcStack_c0)(_DAT_00cf4050,puStack_e0,lStack_d8 + 0x1000578,0x800);
    FUN_0093b400(puStack_e0);
    pcStack_c0 = *(code **)(*_DAT_00cf4050 + 0xf0);
    uStack_a0 = 0xffffffff;
    FUN_0093cad0(puStack_e0,"clio.bin");
    uStack_f8 = 1;
    uStack_a0 = 2;
    (*pcStack_c0)(_DAT_00cf4050,puStack_e0,lStack_d8 + 0x1087454,0x10000);
    FUN_0093b400(puStack_e0);
    lStack_40 = lStack_d8 + 0x129755c;
    pcStack_b0 = *(code **)(*_DAT_00cf4050 + 0xf0);
    uStack_a0 = 0xffffffff;
    puStack_b8 = auStack_38;
    FUN_0093b430(puStack_b8,*(undefined4 *)(lStack_d8 + 0x159f55c),0x10,1);
    pcStack_c0 = (code *)auStack_28;
    uStack_a0 = 3;
    FUN_005941b0(pcStack_c0,"memory_",puStack_b8);
    uStack_a0 = 4;
    FUN_00594330(puStack_e0,pcStack_c0,&DAT_00b03b57);
    uStack_f8 = 1;
    uStack_a0 = 5;
    (*pcStack_b0)(_DAT_00cf4050,puStack_e0,lStack_40,0x300000);
    FUN_0093b400(puStack_e0);
    FUN_0093b400(pcStack_c0);
    FUN_0093b400(puStack_b8);
    pcStack_c0 = *(code **)(*_DAT_00cf4050 + 0xf0);
    uStack_a0 = 0xffffffff;
    FUN_0093cad0(puStack_e0,"nvram.bin");
    uStack_f8 = 0;
    uStack_a0 = 6;
    (*pcStack_c0)(_DAT_00cf4050,puStack_e0,lStack_d8 + 0x159755c,0x8000);
    FUN_0093b400(puStack_e0);
  }
  uStack_a0 = 0xffffffff;
  FUN_0041ff00(lStack_d8,iStack_cc);
  _Unwind_SjLj_Unregister(puStack_c8);
  return;
}


