// FUN_0048b310 @ 0048b310 size=7416
// callers: 
// callees: 008ce548:_Unwind_SjLj_Register 008ce290:operator.new[] 00926950:FUN_00926950 008ce288:operator.new 008ce278:operator.delete[] 008d9400:FUN_008d9400 008ce280:operator.delete 008ce550:_Unwind_SjLj_Unregister 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048b310(longlong param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  ushort uVar5;
  uint uVar6;
  int iVar7;
  undefined8 *puVar8;
  void *pvVar9;
  int *piVar10;
  ulonglong uVar11;
  code *pcVar12;
  longlong lVar13;
  ulonglong *puVar14;
  byte bVar16;
  undefined8 *puVar15;
  uint uVar17;
  ulonglong uVar18;
  longlong *plVar19;
  uint *puVar20;
  undefined8 *puVar21;
  undefined4 *puVar22;
  undefined4 *puVar23;
  undefined1 auStack_188 [32];
  undefined8 uStack_168;
  undefined8 uStack_160;
  undefined8 *puStack_158;
  undefined8 uStack_150;
  undefined8 uStack_148;
  longlong *plStack_140;
  undefined4 *puStack_138;
  longlong *plStack_130;
  longlong lStack_128;
  uint uStack_11c;
  longlong lStack_118;
  longlong lStack_110;
  longlong lStack_108;
  uint *puStack_100;
  ulonglong *puStack_f8;
  ulonglong uStack_f0;
  ulonglong *puStack_e8;
  undefined4 *puStack_e0;
  undefined1 auStack_d8 [8];
  undefined4 uStack_d0;
  undefined *puStack_a8;
  undefined *puStack_a0;
  undefined1 *puStack_98;
  undefined *puStack_90;
  undefined1 *puStack_88;
  undefined1 *puStack_70;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  undefined8 uStack_38;
  undefined8 uStack_30;
  undefined8 uStack_28;
  undefined8 uStack_20;
  
  puStack_98 = &stack0xffffffffffffffe8;
  puStack_88 = auStack_188;
  puStack_a8 = &DAT_008ce270;
  puStack_70 = auStack_d8;
  puStack_a0 = &DAT_00cc18d8;
  puStack_90 = &DAT_0048cf69;
  lStack_108 = param_1;
  _Unwind_SjLj_Register(puStack_70);
  plVar19 = _DAT_00cf4050;
  uVar17 = *(uint *)(lStack_108 + 0x10003a8);
  if ((uVar17 & 0x8000) != 0) {
    if (0 < *(int *)(lStack_108 + 0x1000914)) {
      uStack_58 = 0xffffffffffffffff;
      uStack_50 = 0xffffffffffffffff;
      uStack_48 = 0xffffffffffffffff;
      uStack_40 = 0xffffffffffffffff;
      uStack_38 = 0xffffffffffffffff;
      uStack_30 = 0xffffffffffffffff;
      uStack_28 = 0xffffffffffffffff;
      uStack_20 = 0xffffffffffffffff;
      piVar10 = (int *)_DAT_00cf4050[2];
      if ((piVar10 != (int *)0x0) && (*piVar10 != 0)) {
        if (piVar10[2] < 2) {
          *piVar10 = 0;
          plVar19 = _DAT_00cf4050;
        }
        else {
          piVar10[2] = piVar10[2] + -1;
          plVar19[2] = 0;
        }
      }
      uStack_d0 = 0xffffffff;
      plStack_130 = (longlong *)(**(code **)(*plVar19 + 0xb8))();
      uStack_11c = 0;
      puVar20 = (uint *)*plStack_130;
      puStack_138 = &uStack_5c;
      puStack_e0 = &uStack_60;
      lStack_110 = 0;
      while (puVar20 != (uint *)0x0) {
        uVar17 = *puVar20;
        uStack_150._4_4_ = (undefined4)((ulonglong)uStack_150 >> 0x20);
        uStack_150 = CONCAT44(uStack_150._4_4_,uVar17);
        if (((int)uVar17 <= (int)lStack_110) || (0x1d < (int)uStack_11c)) break;
        if (1 < (int)puVar20[2]) {
          uVar17 = uVar17 + 1 + (uVar17 >> 1);
          if (uVar17 < 0x20) {
            uStack_d0 = 0xffffffff;
            puStack_100 = operator_new(0x18);
            uVar18 = 0x208;
            uStack_168 = (longlong *)0x1f;
            uStack_f0 = 0x20;
            uStack_148 = CONCAT44(uStack_148._4_4_,0x20);
          }
          else {
            uStack_148._4_4_ = (undefined4)((ulonglong)uStack_148 >> 0x20);
            uStack_148 = CONCAT44(uStack_148._4_4_,uVar17);
            uStack_d0 = 0xffffffff;
            puStack_100 = operator_new(0x18);
            uStack_f0 = (ulonglong)(int)(uint)uStack_148;
            if (uStack_f0 < 0x7f0000000000001) {
              uStack_168 = (longlong *)(uStack_f0 - 1);
              uVar18 = uStack_f0 * 0x10 + 8;
            }
            else {
              uStack_168 = (longlong *)(uStack_f0 - 1);
              uVar18 = 0xffffffffffffffff;
            }
          }
          uStack_d0 = 0xffffffff;
          puStack_e8 = operator_new__(uVar18);
          *puStack_e8 = uStack_f0;
          puStack_f8 = puStack_e8 + 1;
          uStack_160 = puStack_e8 + 2;
          do {
            uStack_d0 = 2;
            plStack_140 = uStack_168;
            puStack_158 = operator_new(0x20);
            *puStack_158 = 0;
            puStack_158[1] = 0;
            *(undefined4 *)(puStack_158 + 3) = 3;
            puVar8 = operator_new__(0x48);
            *puVar8 = 8;
            puVar15 = puVar8 + 1;
            do {
              *puVar15 = 0;
              puVar15 = puVar15 + 1;
            } while (puVar15 != puVar8 + 9);
            uStack_168 = (longlong *)((longlong)uStack_168 + -1);
            puVar14 = uStack_160 + 2;
            puStack_158[2] = puVar8 + 1;
            *(undefined4 *)((longlong)puStack_158 + 0x1c) = 1;
            *uStack_160 = (ulonglong)puStack_158;
            uStack_160 = puVar14;
          } while (uStack_168 != (longlong *)0xffffffffffffffff);
          puStack_100[2] = 1;
          *(ulonglong **)(puStack_100 + 4) = puStack_f8;
          puStack_100[1] = (uint)uStack_148;
          *puStack_100 = (uint)uStack_150;
          piVar10 = (int *)*plStack_130;
          if (*piVar10 == 0) {
LAB_0048b62c:
            piVar10[2] = piVar10[2] + -1;
            pvVar9 = (void *)*plStack_130;
            if (*(int *)((longlong)pvVar9 + 8) == 0) {
              lVar13 = *(longlong *)((longlong)pvVar9 + 0x10);
              if (lVar13 != 0) {
                lStack_128 = lVar13 + *(longlong *)(lVar13 + -8) * 0x10;
                lStack_118 = lStack_128;
                if (lVar13 != lStack_128) {
                  do {
                    uStack_150 = lStack_128 - lStack_118;
                    uStack_148 = lStack_118 + -8;
                    piVar10 = (int *)(*(longlong *)(lStack_128 + -8) + 0x1c);
                    *piVar10 = *piVar10 + -1;
                    uStack_168 = *(longlong **)(lStack_128 + -8);
                    if (*(int *)((longlong)uStack_168 + 0x1c) == 0) {
                      puVar15 = (undefined8 *)uStack_168[2];
                      if (puVar15 != (undefined8 *)0x0) {
                        uStack_168 = puVar15 + puVar15[-1];
                        for (puStack_158 = uStack_168; puVar15 != puStack_158;
                            puStack_158 = puStack_158 + -1) {
                          uStack_160 = (ulonglong *)((longlong)puStack_158 - (longlong)uStack_168);
                          if (puStack_158[-1] != 0) {
                            piVar10 = (int *)(puStack_158[-1] + 8);
                            *piVar10 = *piVar10 + -1;
                            pvVar9 = (void *)puStack_158[-1];
                            if (*(int *)((longlong)pvVar9 + 8) == 0) {
                              if (*(void **)((longlong)pvVar9 + 0x10) != (void *)0x0) {
                                operator_delete__(*(void **)((longlong)pvVar9 + 0x10));
                                pvVar9 = *(void **)((longlong)(uStack_168 + -1) +
                                                   (longlong)uStack_160);
                              }
                              operator_delete(pvVar9);
                            }
                            *(undefined8 *)((longlong)(uStack_168 + -1) + (longlong)uStack_160) = 0;
                            puVar15 = *(undefined8 **)
                                       (*(longlong *)(uStack_150 + uStack_148) + 0x10);
                          }
                        }
                        operator_delete__(puVar15 + -1);
                        uStack_168 = *(longlong **)(lStack_118 + -8 + uStack_150);
                        if (uStack_168 == (longlong *)0x0) goto LAB_0048b823;
                      }
                      if (uStack_168[1] != 0) {
                        piVar10 = (int *)(uStack_168[1] + 8);
                        *piVar10 = *piVar10 + -1;
                        pvVar9 = (void *)uStack_168[1];
                        if (*(int *)((longlong)pvVar9 + 8) == 0) {
                          if (*(void **)((longlong)pvVar9 + 0x10) != (void *)0x0) {
                            operator_delete__(*(void **)((longlong)pvVar9 + 0x10));
                            pvVar9 = (void *)uStack_168[1];
                          }
                          operator_delete(pvVar9);
                        }
                        uStack_168[1] = 0;
                      }
                      if (*uStack_168 != 0) {
                        piVar10 = (int *)(*uStack_168 + 8);
                        *piVar10 = *piVar10 + -1;
                        pvVar9 = (void *)*uStack_168;
                        if (*(int *)((longlong)pvVar9 + 8) == 0) {
                          if (*(void **)((longlong)pvVar9 + 0x10) != (void *)0x0) {
                            operator_delete__(*(void **)((longlong)pvVar9 + 0x10));
                            pvVar9 = (void *)*uStack_168;
                          }
                          operator_delete(pvVar9);
                        }
                        *uStack_168 = 0;
                      }
                      operator_delete(uStack_168);
                    }
LAB_0048b823:
                    lStack_128 = lStack_128 + -0x10;
                    lVar13 = *(longlong *)(*plStack_130 + 0x10);
                  } while (lVar13 != lStack_128);
                }
                operator_delete__((void *)(lVar13 + -8));
                pvVar9 = (void *)*plStack_130;
              }
              operator_delete(pvVar9);
            }
          }
          else {
            FUN_008d9400(puStack_f8,*(undefined8 *)(piVar10 + 4));
            piVar10 = (int *)*plStack_130;
            if (piVar10 != (int *)0x0) goto LAB_0048b62c;
          }
          *plStack_130 = (longlong)puStack_100;
          puVar20 = puStack_100;
        }
        piVar10 = (int *)(lStack_110 * 0x10 + *(longlong *)(puVar20 + 4));
        iVar7 = *piVar10;
        if (iVar7 == 0) {
          if (0x1b < (int)uStack_11c) break;
          uStack_160 = (ulonglong *)(piVar10 + 2);
          uStack_5c = 0;
          uStack_d0 = 0xffffffff;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 1;
          uStack_d0 = 0xffffffff;
          uStack_168 = (longlong *)CONCAT44(uStack_168._4_4_,-(uint)(iVar7 == 0));
          uVar4 = uStack_168;
          uStack_168._0_2_ = (ushort)-(uint)(iVar7 == 0);
          uStack_168._2_6_ = SUB86(uVar4,2);
          uStack_168 = (longlong *)
                       (CONCAT62(uStack_168._2_6_,(ushort)uStack_168) & 0xfffffffffffff800);
          uStack_168._0_2_ = (ushort)uStack_168 + 0x8800;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 2;
          uStack_d0 = 0xffffffff;
          uVar5 = (ushort)uStack_168 | 0x1000;
          if (iVar7 == 0) {
            uVar5 = (ushort)uStack_168;
          }
          uStack_168._0_2_ = uVar5;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 3;
          uStack_d0 = 0xffffffff;
          uVar5 = (ushort)uStack_168 | 0x200;
          if (iVar7 == 0) {
            uVar5 = (ushort)uStack_168;
          }
          uStack_168._0_2_ = uVar5;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 4;
          uStack_d0 = 0xffffffff;
          uVar5 = (ushort)uStack_168 | 0x400;
          if (iVar7 == 0) {
            uVar5 = (ushort)uStack_168;
          }
          uStack_168._0_2_ = uVar5;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 5;
          uStack_d0 = 0xffffffff;
          uVar5 = (ushort)uStack_168 | 0x100;
          if (iVar7 == 0) {
            uVar5 = (ushort)uStack_168;
          }
          uStack_168._0_2_ = uVar5;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 6;
          uStack_d0 = 0xffffffff;
          uVar5 = (ushort)uStack_168 | 0x80;
          if (iVar7 == 0) {
            uVar5 = (ushort)uStack_168;
          }
          uStack_168._0_2_ = uVar5;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 7;
          uStack_d0 = 0xffffffff;
          uVar5 = (ushort)uStack_168 | 0x40;
          if (iVar7 == 0) {
            uVar5 = (ushort)uStack_168;
          }
          uStack_168._0_2_ = uVar5;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 8;
          uStack_d0 = 0xffffffff;
          uVar5 = (ushort)uStack_168 | 0x10;
          if (iVar7 == 0) {
            uVar5 = (ushort)uStack_168;
          }
          uStack_168._0_2_ = uVar5;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 9;
          uStack_d0 = 0xffffffff;
          uVar5 = (ushort)uStack_168 | 0x20;
          if (iVar7 == 0) {
            uVar5 = (ushort)uStack_168;
          }
          uStack_168._0_2_ = uVar5;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 10;
          uStack_d0 = 0xffffffff;
          uVar5 = (ushort)uStack_168 | 4;
          if (iVar7 == 0) {
            uVar5 = (ushort)uStack_168;
          }
          uStack_168 = (longlong *)CONCAT62(uStack_168._2_6_,uVar5);
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uVar5 = (ushort)uStack_168 | 8;
          if (iVar7 == 0) {
            uVar5 = (ushort)uStack_168;
          }
          *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c ^ 3)) = (char)(uVar5 >> 8);
          *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 1 ^ 3)) = (char)uVar5;
          puVar20 = (uint *)*plStack_130;
          uStack_11c = uStack_11c + 2;
        }
        else if (iVar7 == 1) {
          if (0x19 < (int)uStack_11c) break;
          uStack_160 = (ulonglong *)(piVar10 + 2);
          uStack_5c = 0;
          uStack_d0 = 0xffffffff;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 1;
          uStack_d0 = 0xffffffff;
          uStack_168._0_4_ = (-(uint)(iVar7 == 0) & 0xff800000) + 0x49800000;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 2;
          uStack_d0 = 0xffffffff;
          uVar17 = (uint)uStack_168 | 0x400000;
          if (iVar7 == 0) {
            uVar17 = (uint)uStack_168;
          }
          uStack_168._0_4_ = uVar17;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 4;
          uStack_d0 = 0xffffffff;
          uVar17 = (uint)uStack_168 | 0x200000;
          if (iVar7 == 0) {
            uVar17 = (uint)uStack_168;
          }
          uStack_168._0_4_ = uVar17;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          uVar17 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uVar6 = 0x80000;
          if (-0x201 < (int)uVar17) {
            if ((int)uVar17 < 0x200) {
              uVar6 = (uVar17 & 0x3ff) << 10;
            }
            else {
              uVar6 = 0x7fc00;
            }
          }
          uStack_5c = 3;
          uStack_d0 = 0xffffffff;
          uStack_168 = (longlong *)CONCAT44(uStack_168._4_4_,uVar6 | (uint)uStack_168);
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          uVar17 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uVar6 = 0x200;
          if (-0x201 < (int)uVar17) {
            if ((int)uVar17 < 0x200) {
              uVar6 = uVar17 & 0x3ff;
            }
            else {
              uVar6 = 0x1ff;
            }
          }
          *(undefined1 *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c ^ 3)) = 0x49;
          *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 1 ^ 3)) =
               (char)((ulonglong)uStack_168 >> 0x10);
          *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 2 ^ 3)) =
               (char)((uVar6 | (uint)uStack_168) >> 8);
          *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 3 ^ 3)) =
               (char)(uVar6 | (uint)uStack_168);
          puVar20 = (uint *)*plStack_130;
          uStack_11c = uStack_11c + 4;
        }
        else if (iVar7 == 2) {
          if (0x18 < (int)uStack_11c) break;
          uStack_168 = (longlong *)(piVar10 + 2);
          uStack_60 = 0;
          uStack_d0 = 0xffffffff;
          piVar10 = (int *)FUN_00926950(uStack_168,puStack_e0);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          if (iVar7 == 0) {
            uStack_5c = 1;
            uStack_d0 = 1;
            piVar10 = (int *)FUN_00926950(uStack_168,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            if (iVar7 != 0) goto LAB_0048c5fd;
            puStack_158 = (undefined8 *)CONCAT44(puStack_158._4_4_,0x4d000000);
          }
          else {
LAB_0048c5fd:
            puStack_158 = (undefined8 *)CONCAT44(puStack_158._4_4_,0x4d800000);
          }
          uStack_5c = 3;
          uStack_d0 = 0xffffffff;
          lVar13 = FUN_00926950(uStack_168,puStack_138);
          uStack_5c = 2;
          uStack_150 = CONCAT44(uStack_150._4_4_,*(undefined4 *)(lStack_108 + 0x1000bec));
          uStack_160._0_4_ = *(int *)(lVar13 + 4);
          lVar13 = FUN_00926950(uStack_168,puStack_138);
          iVar7 = *(int *)(lStack_108 + 0x1000be8);
          if ((iVar7 == 0x140) || (iVar7 == 0x280)) {
            uStack_160 = (ulonglong *)
                         CONCAT44(uStack_160._4_4_,
                                  (((int)(uint)uStack_160 >> 0x10) * 0x1e0) / (int)(uint)uStack_150)
            ;
            uVar17 = ((*(int *)(lVar13 + 4) >> 0x10) * 0x280) / iVar7 & 0xffff;
LAB_0048c6a3:
            iVar7 = (int)(uVar17 * 0x400 + ((int)((uint)uStack_160 + 2) >> 1) * 0xc698b) / 5 +
                    0x55ecc;
          }
          else {
            uStack_5c = 3;
            uStack_d0 = 0xffffffff;
            lVar13 = FUN_00926950(uStack_168,puStack_138);
            uStack_5c = 2;
            iVar7 = (*(short *)(lVar13 + 6) * 0x240) / *(int *)(lStack_108 + 0x1000bec);
            uStack_150 = CONCAT44(uStack_150._4_4_,iVar7);
            uStack_160 = (ulonglong *)CONCAT44(uStack_160._4_4_,iVar7);
            lVar13 = FUN_00926950(uStack_168,puStack_138);
            iVar7 = *(int *)(lStack_108 + 0x1000be8);
            uVar17 = (*(short *)(lVar13 + 6) * 0x300) / iVar7 & 0xffff;
            if ((iVar7 == 0x280) || (iVar7 == 0x140)) goto LAB_0048c6a3;
            iVar7 = (int)(uVar17 * 0x400 + ((int)((uint)uStack_150 + -0x28) >> 1) * 0xc698b) / 5 +
                    0x36cc;
          }
          uStack_5c = 4;
          uStack_160 = (ulonglong *)(CONCAT44(uStack_160._4_4_,iVar7 >> 10) & 0xffffffff0001ffff);
          uStack_d0 = 0xffffffff;
          uStack_160._0_4_ = (uint)uStack_160 | (uint)puStack_158;
          piVar10 = (int *)FUN_00926950(uStack_168,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 5;
          uStack_d0 = 0xffffffff;
          uVar17 = (uint)uStack_160 | 0x400000;
          if (iVar7 == 0) {
            uVar17 = (uint)uStack_160;
          }
          uStack_160._0_4_ = uVar17;
          piVar10 = (int *)FUN_00926950(uStack_168,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 6;
          uStack_d0 = 0xffffffff;
          uVar17 = (uint)uStack_160 | 0x200000;
          if (iVar7 == 0) {
            uVar17 = (uint)uStack_160;
          }
          uStack_160._0_4_ = uVar17;
          piVar10 = (int *)FUN_00926950(uStack_168,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 7;
          uStack_d0 = 0xffffffff;
          uVar17 = (uint)uStack_160 | 0x100000;
          if (iVar7 == 0) {
            uVar17 = (uint)uStack_160;
          }
          uStack_160._0_4_ = uVar17;
          piVar10 = (int *)FUN_00926950(uStack_168,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 1;
          uVar17 = (uint)uStack_160 | 0x80000;
          if (iVar7 == 0) {
            uVar17 = (uint)uStack_160;
          }
          *(undefined1 *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c ^ 3)) = 0x4d;
          *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 1 ^ 3)) =
               (char)(uVar17 >> 0x10);
          *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 2 ^ 3)) =
               (char)(uVar17 >> 8);
          uStack_160 = (ulonglong *)CONCAT44(uStack_160._4_4_,uStack_11c + 4);
          *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 3 ^ 3)) = (char)uVar17;
          uStack_d0 = 0xffffffff;
          piVar10 = (int *)FUN_00926950(uStack_168,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_11c = uStack_11c + 5;
          if (iVar7 == 0) {
            *(undefined1 *)((longlong)&uStack_58 + (longlong)(int)((uint)uStack_160 ^ 3)) = 0x1f;
          }
          else {
            *(undefined1 *)((longlong)&uStack_58 + (longlong)(int)((uint)uStack_160 ^ 3)) = 0;
          }
          uStack_5c = 8;
          uStack_d0 = 0xffffffff;
          lVar13 = FUN_00926950(uStack_168,puStack_138);
          if (*(int *)(lVar13 + 4) != 0) {
            uStack_5c = 3;
            uStack_d0 = 0xffffffff;
            lVar13 = FUN_00926950(uStack_168,puStack_138);
            uStack_60 = 2;
            lStack_128 = CONCAT44(lStack_128._4_4_,(int)*(short *)(lVar13 + 6));
            lVar13 = FUN_00926950(uStack_168);
            lStack_118 = CONCAT44(lStack_118._4_4_,(int)*(short *)(lVar13 + 6));
            uStack_168 = _DAT_00cf4050;
            puVar14 = (ulonglong *)_DAT_00cf4050[2];
            if ((ulonglong *)_DAT_00cf4050[2] == (ulonglong *)0x0) {
              uStack_160 = operator_new(0x18);
              puVar15 = operator_new__(0x188);
              lVar13 = 0;
              *puVar15 = 0x20;
              do {
                *(undefined4 *)((longlong)puVar15 + lVar13 + 0x10) = 0;
                *(undefined4 *)((longlong)puVar15 + lVar13 + 0xc) = 0;
                lVar13 = lVar13 + 0xc;
              } while (lVar13 != 0x180);
              uStack_160[2] = (ulonglong)(puVar15 + 1);
              *(int *)((longlong)uStack_160 + 4) = 0x20;
              *(int *)(uStack_160 + 1) = 1;
              *(int *)uStack_160 = 0;
              uStack_168[2] = (longlong)uStack_160;
              puVar14 = uStack_160;
            }
            if ((int)puVar14[1] < 2) {
              iVar7 = (int)*puVar14;
              if (iVar7 < *(int *)((longlong)puVar14 + 4)) {
                puVar1 = (undefined4 *)(puVar14[2] + (longlong)iVar7 * 0xc);
                *puVar1 = 0;
                puVar1[1] = (undefined4)lStack_118;
                puVar1[2] = (undefined4)lStack_128;
                *(int *)uStack_168[2] = *(int *)uStack_168[2] + 1;
                goto LAB_0048c322;
              }
            }
            else {
              iVar7 = (int)*puVar14;
            }
            puStack_100 = (uint *)CONCAT44(puStack_100._4_4_,iVar7 + 1U);
            uVar17 = iVar7 + 2 + (iVar7 + 1U >> 1);
            if (uVar17 < 0x20) {
              uStack_d0 = 0xffffffff;
              uStack_160 = operator_new(0x18);
              uStack_150 = CONCAT44(uStack_150._4_4_,0x20);
              uVar18 = 0x188;
              uStack_148 = 0x1f;
              puStack_158 = (undefined8 *)0x20;
            }
            else {
              uStack_150 = CONCAT44(uStack_150._4_4_,uVar17);
              uStack_d0 = 0xffffffff;
              uStack_160 = operator_new(0x18);
              puStack_158 = (undefined8 *)(longlong)(int)(uint)uStack_150;
              if (puStack_158 < (undefined8 *)0xaa0000000000001) {
                uStack_148 = (longlong)puStack_158 + -1;
                uVar18 = (longlong)puStack_158 * 0xc + 8;
              }
              else {
                uVar18 = 0xffffffffffffffff;
                uStack_148 = (longlong)puStack_158 + -1;
              }
            }
            uStack_d0 = 0xffffffff;
            puVar8 = operator_new__(uVar18);
            lVar13 = 0;
            *puVar8 = puStack_158;
            puVar15 = puVar8 + 2;
            do {
              lVar13 = lVar13 + 1;
              *(undefined4 *)puVar15 = 0;
              *(undefined4 *)((longlong)puVar15 + -4) = 0;
              puVar15 = (undefined8 *)((longlong)puVar15 + 0xc);
            } while (lVar13 != uStack_148 + 1);
            puVar15 = puVar8 + 1;
            uStack_160[2] = (ulonglong)puVar15;
            *(uint *)((longlong)uStack_160 + 4) = (uint)uStack_150;
            *(int *)(uStack_160 + 1) = 1;
            *(int *)uStack_160 = (int)puStack_100;
            iVar7 = *(int *)uStack_168[2];
            lVar13 = (longlong)iVar7;
            if (iVar7 != 0) {
              puVar3 = *(undefined8 **)((int *)uStack_168[2] + 4);
              if (puVar15 < puVar3) {
                if (0 < iVar7) {
                  puVar15 = puVar3;
                  do {
                    puVar21 = (undefined8 *)((longlong)puVar15 + 0xc);
                    *(undefined4 *)(puVar8 + 1) = *(undefined4 *)puVar15;
                    *(undefined4 *)((longlong)puVar8 + 0xc) = *(undefined4 *)((longlong)puVar15 + 4)
                    ;
                    *(undefined4 *)(puVar8 + 2) = *(undefined4 *)(puVar15 + 1);
                    puVar15 = puVar21;
                    puVar8 = (undefined8 *)((longlong)puVar8 + 0xc);
                  } while (puVar21 !=
                           (undefined8 *)((longlong)puVar3 + (ulonglong)(iVar7 - 1) * 0xc + 0xc));
LAB_0048ce66:
                  puVar15 = (undefined8 *)uStack_160[2];
                  lVar13 = (longlong)*(int *)uStack_168[2];
                }
              }
              else if ((puVar3 < puVar15) && (iVar7 = iVar7 + -1, -1 < iVar7)) {
                lVar13 = (longlong)iVar7 * 0xc;
                puVar1 = (undefined4 *)((longlong)puVar3 + lVar13 + 4);
                puVar2 = (undefined4 *)((longlong)puVar8 + lVar13 + 0xc);
                puVar22 = puVar2;
                puVar23 = puVar1;
                do {
                  iVar7 = iVar7 + -1;
                  *(undefined4 *)
                   ((longlong)puVar8 + (longlong)puVar22 + (lVar13 - (longlong)puVar2) + 8) =
                       *(undefined4 *)
                        ((longlong)puVar3 + (lVar13 - (longlong)puVar1) + (longlong)puVar23);
                  *puVar22 = *puVar23;
                  puVar22[1] = puVar23[1];
                  puVar22 = puVar22 + -3;
                  puVar23 = puVar23 + -3;
                } while (iVar7 != -1);
                goto LAB_0048ce66;
              }
            }
            puVar1 = (undefined4 *)((longlong)puVar15 + lVar13 * 0xc);
            *puVar1 = 0;
            puVar1[2] = (undefined4)lStack_128;
            puVar1[1] = (undefined4)lStack_118;
            if (uStack_168[2] != 0) {
              piVar10 = (int *)(uStack_168[2] + 8);
              *piVar10 = *piVar10 + -1;
              pvVar9 = (void *)uStack_168[2];
              if (*(int *)((longlong)pvVar9 + 8) == 0) {
                if (*(longlong *)((longlong)pvVar9 + 0x10) != 0) {
                  operator_delete__((void *)(*(longlong *)((longlong)pvVar9 + 0x10) + -8));
                  pvVar9 = (void *)uStack_168[2];
                }
                operator_delete(pvVar9);
              }
            }
            uStack_168[2] = (longlong)uStack_160;
          }
LAB_0048c322:
          puVar20 = (uint *)*plStack_130;
        }
        else if (iVar7 == 3) {
          if (0x1a < (int)uStack_11c) break;
          uStack_160 = (ulonglong *)(piVar10 + 2);
          uStack_5c = 0;
          uStack_d0 = 0xffffffff;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 1;
          uStack_d0 = 0xffffffff;
          uStack_168._0_4_ = (-(uint)(iVar7 == 0) & 0xffffff00) + 0xc00100;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 2;
          uStack_d0 = 0xffffffff;
          uVar17 = (uint)uStack_168 | 0x2000;
          if (iVar7 == 0) {
            uVar17 = (uint)uStack_168;
          }
          uStack_168._0_4_ = uVar17;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 3;
          uStack_d0 = 0xffffffff;
          uVar17 = (uint)uStack_168 | 0x200;
          if (iVar7 == 0) {
            uVar17 = (uint)uStack_168;
          }
          uStack_168._0_4_ = uVar17;
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          uStack_5c = 4;
          uStack_d0 = 0xffffffff;
          uVar17 = (uint)uStack_168 | 0x1000;
          if (iVar7 == 0) {
            uVar17 = (uint)uStack_168;
          }
          uStack_168 = (longlong *)CONCAT44(uStack_168._4_4_,uVar17);
          piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
          iVar7 = piVar10[1];
          if (*piVar10 != 0) {
            piVar10[1] = 0;
          }
          bVar16 = uStack_168._1_1_ | 4;
          if (iVar7 == 0) {
            bVar16 = uStack_168._1_1_;
          }
          *(undefined1 *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c ^ 3)) = 0xc0;
          *(undefined1 *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 1 ^ 3)) = 0;
          *(byte *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 2 ^ 3)) = bVar16;
          puVar20 = (uint *)*plStack_130;
          uStack_11c = uStack_11c + 3;
        }
        else if (iVar7 == 4) {
          if ((int)uStack_11c < 0x15) {
            uStack_160 = (ulonglong *)(piVar10 + 2);
            *(undefined1 *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c ^ 3)) = 1;
            uStack_5c = 0xd;
            *(undefined1 *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 1 ^ 3)) = 0;
            *(undefined1 *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 2 ^ 3)) = 0;
            uStack_d0 = 0xffffffff;
            puStack_158._0_4_ = uStack_11c + 3;
            lVar13 = FUN_00926950(uStack_160,puStack_138);
            uStack_168._0_4_ = 0x3ff003;
            iVar7 = *(int *)(lVar13 + 4) + 0x10000 >> 7;
            if ((iVar7 < 0x400) && (uStack_168._0_4_ = 3, -1 < iVar7)) {
              uStack_168._0_4_ = iVar7 << 0xc | 3;
            }
            uStack_5c = 0xc;
            uStack_d0 = 0xffffffff;
            lVar13 = FUN_00926950(uStack_160,puStack_138);
            iVar7 = *(int *)(lVar13 + 4) + 0x10000 >> 7;
            uVar17 = 0xffc00000;
            if (iVar7 < 0x400) {
              uVar17 = 0;
              if (-1 < iVar7) {
                uVar17 = iVar7 << 0x16;
              }
            }
            uStack_5c = 0xe;
            uStack_168._0_4_ = uVar17 | (uint)uStack_168;
            uStack_d0 = 0xffffffff;
            lVar13 = FUN_00926950(uStack_160,puStack_138);
            uVar17 = *(int *)(lVar13 + 4) >> 0x1f;
            uStack_5c = 0;
            uVar6 = (int)((uVar17 ^ *(uint *)(lVar13 + 4)) - uVar17) >> 6;
            uVar17 = 0x3ff;
            if ((int)uVar6 < 0x400) {
              uVar17 = uVar6;
            }
            uVar17 = (uVar17 ^ 0x3ff) << 2 | (uint)uStack_168;
            *(char *)((longlong)&uStack_58 + (longlong)(int)((uint)puStack_158 ^ 3)) =
                 (char)(uVar17 >> 0x18);
            *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 4 ^ 3)) =
                 (char)(uVar17 >> 0x10);
            *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 5 ^ 3)) =
                 (char)(uVar17 >> 8);
            puStack_158 = (undefined8 *)CONCAT44(puStack_158._4_4_,uStack_11c + 7);
            *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 6 ^ 3)) = (char)uVar17;
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uStack_5c = 1;
            uStack_d0 = 0xffffffff;
            uStack_168 = (longlong *)CONCAT44(uStack_168._4_4_,-(uint)(iVar7 == 0));
            uVar4 = uStack_168;
            uStack_168._0_2_ = (ushort)-(uint)(iVar7 == 0);
            uStack_168._2_6_ = SUB86(uVar4,2);
            uStack_168._0_2_ = ~(ushort)uStack_168 & 0x800;
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uStack_5c = 2;
            uStack_d0 = 0xffffffff;
            uVar5 = (ushort)uStack_168 | 0x400;
            if (iVar7 == 0) {
              uVar5 = (ushort)uStack_168;
            }
            uStack_168._0_2_ = uVar5;
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uStack_5c = 3;
            uStack_d0 = 0xffffffff;
            uVar5 = (ushort)uStack_168 | 0x100;
            if (iVar7 == 0) {
              uVar5 = (ushort)uStack_168;
            }
            uStack_168._0_2_ = uVar5;
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uStack_5c = 4;
            uStack_d0 = 0xffffffff;
            uVar5 = (ushort)uStack_168 | 0x200;
            if (iVar7 == 0) {
              uVar5 = (ushort)uStack_168;
            }
            uStack_168._0_2_ = uVar5;
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uStack_5c = 5;
            uStack_d0 = 0xffffffff;
            uVar5 = (ushort)uStack_168 | 0x4000;
            if (iVar7 == 0) {
              uVar5 = (ushort)uStack_168;
            }
            uStack_168._0_2_ = uVar5;
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uStack_5c = 6;
            uStack_d0 = 0xffffffff;
            uVar5 = (ushort)uStack_168 | 0x2000;
            if (iVar7 == 0) {
              uVar5 = (ushort)uStack_168;
            }
            uStack_168._0_2_ = uVar5;
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uStack_5c = 7;
            uStack_d0 = 0xffffffff;
            uVar5 = (ushort)uStack_168 | 0x1000;
            if (iVar7 == 0) {
              uVar5 = (ushort)uStack_168;
            }
            uStack_168._0_2_ = uVar5;
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uStack_5c = 8;
            uStack_d0 = 0xffffffff;
            uVar5 = (ushort)uStack_168 | 0x40;
            if (iVar7 == 0) {
              uVar5 = (ushort)uStack_168;
            }
            uStack_168._0_2_ = uVar5;
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uStack_5c = 9;
            uStack_d0 = 0xffffffff;
            uVar5 = (ushort)uStack_168 | 0x80;
            if (iVar7 == 0) {
              uVar5 = (ushort)uStack_168;
            }
            uStack_168._0_2_ = uVar5;
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uStack_5c = 10;
            uStack_d0 = 0xffffffff;
            uVar5 = (ushort)uStack_168 | 0x20;
            if (iVar7 == 0) {
              uVar5 = (ushort)uStack_168;
            }
            uStack_168._0_2_ = uVar5;
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uStack_5c = 0xb;
            uStack_d0 = 0xffffffff;
            uVar5 = (ushort)uStack_168 | 0x10;
            if (iVar7 == 0) {
              uVar5 = (ushort)uStack_168;
            }
            uStack_168 = (longlong *)CONCAT62(uStack_168._2_6_,uVar5);
            piVar10 = (int *)FUN_00926950(uStack_160,puStack_138);
            iVar7 = piVar10[1];
            if (*piVar10 != 0) {
              piVar10[1] = 0;
            }
            uVar5 = (ushort)uStack_168 | 0x8000;
            if (iVar7 == 0) {
              uVar5 = (ushort)uStack_168;
            }
            *(char *)((longlong)&uStack_58 + (longlong)(int)((uint)puStack_158 ^ 3)) =
                 (char)(uVar5 >> 8);
            *(char *)((longlong)&uStack_58 + (longlong)(int)(uStack_11c + 8 ^ 3)) = (char)uVar5;
            uStack_11c = uStack_11c + 9;
            goto LAB_0048c322;
          }
          break;
        }
        lStack_110 = lStack_110 + 1;
      }
      uVar17 = *(uint *)(lStack_108 + 0x1000910);
      uVar18 = (ulonglong)uVar17;
      if (uVar17 < 0x300000) {
        *(undefined4 *)(*(longlong *)(lStack_108 + 0x30) + uVar18) = 0;
        uVar17 = *(uint *)(lStack_108 + 0x1000910);
      }
      uVar17 = uVar17 + 4;
      *(uint *)(lStack_108 + 0x1000910) = uVar17;
      *(int *)(lStack_108 + 0x1000918) = *(int *)(lStack_108 + 0x1000918) + 4;
      iVar7 = *(int *)(lStack_108 + 0x1000914) + -4;
      uStack_168 = (longlong *)CONCAT44(uStack_168._4_4_,*(int *)(lStack_108 + 0x1000914));
      *(int *)(lStack_108 + 0x1000914) = iVar7;
      uVar11 = 0;
      if (0 < iVar7) {
        do {
          if ((uint)uVar11 < 0xf) {
            if (uVar17 < 0x300000) {
              *(undefined4 *)(*(longlong *)(lStack_108 + 0x30) + (ulonglong)uVar17) =
                   *(undefined4 *)((longlong)&uStack_58 + uVar11 * 4);
              uVar17 = *(uint *)(lStack_108 + 0x1000910);
            }
          }
          else if (uVar17 < 0x300000) {
            *(undefined4 *)(*(longlong *)(lStack_108 + 0x30) + (ulonglong)uVar17) = 0xffffffff;
            uVar17 = *(uint *)(lStack_108 + 0x1000910);
          }
          uVar17 = uVar17 + 4;
          uVar6 = (uint)uVar11 + 1;
          uVar11 = (ulonglong)uVar6;
          *(int *)(lStack_108 + 0x1000918) = *(int *)(lStack_108 + 0x1000918) + 4;
          *(uint *)(lStack_108 + 0x1000910) = uVar17;
          iVar7 = *(int *)(lStack_108 + 0x1000914) + -4;
          *(int *)(lStack_108 + 0x1000914) = iVar7;
        } while (0 < iVar7);
        if (uVar6 != 0) {
          lVar13 = *(longlong *)(lStack_108 + 0x1000bd0);
          if (lVar13 != 0) {
            pcVar12 = *(code **)(lStack_108 + 0x1000bd8);
            if (((ulonglong)pcVar12 & 1) == 0) {
              plVar19 = (longlong *)(lVar13 + *(longlong *)(lStack_108 + 0x1000be0));
            }
            else {
              plVar19 = (longlong *)(lVar13 + *(longlong *)(lStack_108 + 0x1000be0));
              pcVar12 = *(code **)(pcVar12 + *plVar19 + -1);
            }
            uStack_d0 = 0xffffffff;
            (*pcVar12)(plVar19,uVar18,uVar6 * 4);
          }
        }
      }
      *(undefined4 *)(lStack_108 + 0x1000914) = 0xfffffffc;
      uVar17 = *(uint *)(lStack_108 + 0x10003a8);
    }
    lVar13 = *(longlong *)(lStack_108 + 0x1000ba0);
    *(uint *)(lStack_108 + 0x10003a8) = uVar17 & 0xffff7fff;
    if (lVar13 != 0) {
      pcVar12 = *(code **)(lStack_108 + 0x1000ba8);
      if (((ulonglong)pcVar12 & 1) == 0) {
        plVar19 = (longlong *)(lVar13 + *(longlong *)(lStack_108 + 0x1000bb0));
      }
      else {
        plVar19 = (longlong *)(lVar13 + *(longlong *)(lStack_108 + 0x1000bb0));
        pcVar12 = *(code **)(pcVar12 + *plVar19 + -1);
      }
      uStack_d0 = 0xffffffff;
      (*pcVar12)(plVar19,0,1);
    }
  }
  _Unwind_SjLj_Unregister(puStack_70);
  return;
}


