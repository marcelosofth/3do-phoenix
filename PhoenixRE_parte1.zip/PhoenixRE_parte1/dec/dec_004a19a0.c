// FUN_004a19a0 @ 004a19a0 size=776
// callers: 00589910 004a1cf0 004a1d80 
// callees: 008ce548:_Unwind_SjLj_Register 008de260:FUN_008de260 008ce290:operator.new[] 0093b400:FUN_0093b400 004a0e10:FUN_004a0e10 008ce550:_Unwind_SjLj_Unregister 

longlong * FUN_004a19a0(longlong *param_1,longlong param_2,uint param_3)

{
  int iVar1;
  int *piVar2;
  ulonglong uVar3;
  undefined1 auStack_c8 [32];
  uint uStack_a8;
  longlong *plStack_a0;
  longlong lStack_98;
  uint uStack_8c;
  uint *puStack_88;
  undefined1 *puStack_80;
  undefined1 auStack_78 [8];
  undefined4 uStack_70;
  undefined *puStack_48;
  undefined *puStack_40;
  undefined1 *puStack_38;
  undefined *puStack_30;
  undefined1 *puStack_28;
  char cStack_d;
  uint uStack_c;
  
  puStack_38 = &stack0xfffffffffffffff8;
  puStack_28 = auStack_c8;
  puStack_48 = &DAT_008ce270;
  puStack_40 = &DAT_00cc1e3c;
  puStack_30 = &DAT_004a1cbe;
  puStack_80 = auStack_78;
  plStack_a0 = param_1;
  lStack_98 = param_2;
  uStack_8c = param_3;
  _Unwind_SjLj_Register(puStack_80);
  *plStack_a0 = (longlong)&DAT_00cfd470;
  DAT_00cfd47c = 0;
  *(undefined4 *)*plStack_a0 = 0;
  *(undefined4 *)(*plStack_a0 + 4) = 0;
  *(int *)(*plStack_a0 + 8) = *(int *)(*plStack_a0 + 8) + 1;
  uStack_a8 = uStack_8c ^ 0x3000000;
  if ((uStack_a8 & 0xfff00000) == 0) {
    if ((*(byte *)(lStack_98 + 0x10874d8) & 4) == 0) {
      do {
        if (*(char *)(lStack_98 + 0x1097558 + (ulonglong)(uStack_a8 ^ 3)) == '\0') break;
        uStack_70 = 1;
        FUN_004a0e10(plStack_a0);
        uStack_a8 = uStack_a8 + 1;
      } while (uStack_a8 != 0x100000);
    }
    else {
      do {
        if (*(char *)(lStack_98 + 0x1097558 + (ulonglong)((uStack_a8 ^ 3) + 0x100000)) == '\0')
        break;
        uStack_70 = 1;
        FUN_004a0e10(plStack_a0);
        uStack_a8 = uStack_a8 + 1;
      } while (uStack_a8 != 0x100000);
    }
  }
  else if (((((uStack_8c ^ 0x3100000) & 0xfff00000) != 0) ||
           (((uStack_8c ^ 0x3100000) & 0x40000) == 0)) && (uStack_8c < 0x300000)) {
    cStack_d = *(char *)(lStack_98 + 0x129755c + (ulonglong)(uStack_8c ^ 3));
    while (cStack_d != '\0') {
      piVar2 = (int *)*plStack_a0;
      iVar1 = *piVar2;
      uStack_a8 = iVar1 + 1;
      if ((piVar2[1] < (int)uStack_a8) || (1 < piVar2[2])) {
        uStack_c = iVar1 + 2 + (uStack_a8 >> 1);
        if (uStack_c < 0x20) {
          uStack_c = 0x20;
          uVar3 = 0x30;
        }
        else {
          uVar3 = (longlong)(int)uStack_c + 0x10;
        }
        uStack_70 = 1;
        puStack_88 = operator_new__(uVar3);
        puStack_88[2] = 1;
        puStack_88[1] = uStack_c;
        *puStack_88 = uStack_a8;
        *(undefined1 *)((longlong)puStack_88 + (longlong)(int)uStack_a8 + 0xc) = 0;
        iVar1 = 0;
        if (*(int *)*plStack_a0 != 0) {
          FUN_008de260(puStack_88 + 3,(int *)*plStack_a0 + 3);
          iVar1 = *(int *)*plStack_a0;
        }
        *(char *)((longlong)puStack_88 + (longlong)iVar1 + 0xc) = cStack_d;
        FUN_0093b400(plStack_a0);
        *plStack_a0 = (longlong)puStack_88;
      }
      else {
        *(char *)((longlong)piVar2 + (longlong)iVar1 + 0xc) = cStack_d;
        *(uint *)*plStack_a0 = uStack_a8;
        *(undefined1 *)(*plStack_a0 + 0xc + (longlong)(int)uStack_a8) = 0;
      }
      uStack_8c = uStack_8c + 1;
      if (uStack_8c == 0x300000) break;
      cStack_d = *(char *)(lStack_98 + 0x129755c + (ulonglong)(uStack_8c ^ 3));
    }
  }
  _Unwind_SjLj_Unregister(puStack_80);
  return plStack_a0;
}


