// FUN_0048d0c0 @ 0048d0c0 size=7072
// callers: 004a7f60 
// callees: 008ce548:_Unwind_SjLj_Register 008ce278:operator.delete[] 008da710:FUN_008da710 0090f670:FUN_0090f670 0041f340:FUN_0041f340 004899d0:FUN_004899d0 008ce288:operator.new 008ce280:operator.delete 0094a890:FUN_0094a890 008ce290:operator.new[] 008ce550:_Unwind_SjLj_Unregister 0041f0b0:FUN_0041f0b0 008de3b0:FUN_008de3b0 008dc690:FUN_008dc690 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048d0c0(undefined8 *param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4,
                 undefined4 param_5)

{
  longlong *plVar1;
  undefined *puVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  longlong lVar9;
  void *pvVar10;
  ulonglong *puVar11;
  int *piVar12;
  ulonglong *puVar13;
  uint *puVar14;
  ulonglong uVar15;
  uint uVar16;
  longlong lVar17;
  undefined1 auStack_158 [40];
  uint **ppuStack_130;
  code *pcStack_128;
  undefined8 *puStack_120;
  longlong *plStack_118;
  longlong *plStack_110;
  uint *puStack_108;
  ulonglong uStack_100;
  ulonglong *puStack_f8;
  ulonglong *puStack_f0;
  longlong *plStack_e8;
  longlong lStack_e0;
  longlong *plStack_d8;
  longlong lStack_d0;
  int **ppiStack_c8;
  undefined1 *puStack_c0;
  uint *puStack_b8;
  ulonglong uStack_b0;
  undefined1 auStack_a8 [8];
  undefined4 uStack_a0;
  undefined *puStack_78;
  undefined *puStack_70;
  undefined1 *puStack_68;
  undefined1 *puStack_60;
  undefined1 *puStack_58;
  undefined8 *puStack_40;
  uint *apuStack_38 [2];
  int *piStack_28;
  undefined8 *puStack_20;
  undefined4 uStack_18;
  undefined8 *puStack_10;
  
  puStack_68 = &stack0xfffffffffffffff8;
  puStack_58 = auStack_158;
  puStack_78 = &DAT_008ce270;
  puStack_70 = &DAT_00cc18f0;
  puStack_60 = &LAB_0048ec9d;
  puStack_c0 = auStack_a8;
  ppuStack_130 = (uint **)param_4;
  pcStack_128 = (code *)param_2;
  puStack_120 = param_1;
  plStack_118 = (longlong *)param_3;
  _Unwind_SjLj_Register(puStack_c0);
  piStack_28 = *(int **)pcStack_128;
  piStack_28[2] = piStack_28[2] + 1;
  ppiStack_c8 = &piStack_28;
  uStack_a0 = 1;
  FUN_0041f340(puStack_120,ppiStack_c8,plStack_118);
  iVar3 = piStack_28[2];
  piStack_28[2] = iVar3 + -1;
  if ((piStack_28 != (int *)&DAT_00cfd470) && (iVar3 + -1 == 0)) {
    operator_delete__(piStack_28);
  }
  *puStack_120 = &PTR_FUN_00c247f0;
  *(undefined4 *)(puStack_120 + 5) = param_5;
  uVar16 = 0;
  do {
    uVar4 = uVar16;
    uVar16 = uVar4 + 1;
  } while ("CELEngine"[uVar16] != '\0');
  pcStack_128 = (code *)CONCAT44(pcStack_128._4_4_,uVar16);
  uVar16 = uVar4 + 2 + (uVar16 >> 1);
  if (uVar16 < 0x20) {
    uVar15 = 0x30;
    plStack_118._0_4_ = 0x20;
  }
  else {
    uVar15 = (longlong)(int)uVar16 + 0x10;
    plStack_118._0_4_ = uVar16;
  }
  uStack_a0 = 2;
  piStack_28 = operator_new__(uVar15);
  piStack_28[2] = 1;
  piStack_28[1] = (uint)plStack_118;
  *piStack_28 = (uint)pcStack_128;
  *(undefined1 *)((longlong)piStack_28 + (longlong)(int)(uint)pcStack_128 + 0xc) = 0;
  if ((uint)pcStack_128 != 0) {
    piVar12 = piStack_28 + 3;
    if (&UNK_00b0314a < piVar12) {
      if (("CELEngine" < piVar12) && (uVar16 = (uint)pcStack_128 - 1, -1 < (int)uVar16)) {
        uVar15 = 0;
        do {
          *(char *)((longlong)piVar12 + uVar15 + (longlong)(int)uVar16) =
               "CELEngine"[uVar15 + (longlong)(int)uVar16];
          uVar15 = uVar15 - 1;
        } while (uVar15 != ~(ulonglong)uVar16);
      }
    }
    else if (0 < (int)(uint)pcStack_128) {
      lVar17 = 0;
      do {
        *(char *)((longlong)piVar12 + lVar17) = "CELEngine"[lVar17];
        lVar17 = lVar17 + 1;
      } while ((int)lVar17 < (int)(uint)pcStack_128);
    }
  }
  uStack_a0 = 3;
  puStack_40 = puStack_120 + 7;
  FUN_004899d0(puStack_40,ppiStack_c8,puStack_120,ppuStack_130);
  iVar3 = piStack_28[2];
  piStack_28[2] = iVar3 + -1;
  if ((piStack_28 != (int *)&DAT_00cfd470) && (iVar3 + -1 == 0)) {
    operator_delete__(piStack_28);
  }
  puStack_120[0x200174] = 0;
  puStack_120[6] = ppuStack_130;
  puStack_120[0x200177] = 0;
  puStack_120[0x20017a] = 0;
  *(undefined4 *)((longlong)puStack_120 + 0x1000bec) = 0;
  *(undefined4 *)(puStack_120 + 0x20017d) = 0;
  uStack_a0 = 4;
  ppuStack_130 = (uint **)(puStack_120 + 0x200074);
  pcStack_128 = operator_new(0x20);
  *(undefined8 *)pcStack_128 = 0;
  *(undefined8 *)((longlong)pcStack_128 + 8) = 0;
  *(undefined4 *)((longlong)pcStack_128 + 0x18) = 3;
  puVar6 = operator_new__(0x48);
  *puVar6 = 8;
  puVar7 = puVar6 + 1;
  do {
    *puVar7 = 0;
    puVar7 = puVar7 + 1;
  } while (puVar7 != puVar6 + 9);
  *(undefined8 **)((longlong)pcStack_128 + 0x10) = puVar6 + 1;
  *(undefined4 *)((longlong)pcStack_128 + 0x1c) = 1;
  puStack_10 = (undefined8 *)pcStack_128;
  piStack_28 = (int *)CONCAT44(piStack_28._4_4_,0x800);
  uStack_18 = 0;
  puStack_20 = ppuStack_130;
  uVar16 = 0;
  do {
    uVar4 = uVar16;
    uVar16 = uVar4 + 1;
  } while ((&DAT_00b03146)[uVar16] != '\0');
  uVar4 = uVar4 + 2 + (uVar16 >> 1);
  if (uVar4 < 0x20) {
    uVar15 = 0x30;
    pcStack_128._0_4_ = 0x20;
  }
  else {
    uVar15 = (longlong)(int)uVar4 + 0x10;
    pcStack_128._0_4_ = uVar4;
  }
  uStack_a0 = 5;
  ppuStack_130._0_4_ = uVar16;
  apuStack_38[0] = operator_new__(uVar15);
  apuStack_38[0][2] = 1;
  apuStack_38[0][1] = (uint)pcStack_128;
  *apuStack_38[0] = (uint)ppuStack_130;
  *(undefined1 *)((longlong)apuStack_38[0] + (longlong)(int)(uint)ppuStack_130 + 0xc) = 0;
  if ((uint)ppuStack_130 == 0) {
LAB_0048d3ef:
    plVar8 = (longlong *)puStack_120[4];
    if (*(int *)((longlong)plVar8 + 0x1c) < 2) goto LAB_0048eaea;
LAB_0048d402:
    uStack_a0 = 6;
    ppuStack_130 = (uint **)CONCAT44(ppuStack_130._4_4_,(int)plVar8[3]);
    plStack_110 = operator_new(0x20);
    *plStack_110 = 0;
    plStack_110[1] = 0;
    *(uint *)(plStack_110 + 3) = (uint)ppuStack_130;
    uStack_a0 = 6;
    ppuStack_130 = (uint **)(longlong)(1 << ((byte)ppuStack_130 & 0x1f));
    uVar15 = 0xffffffffffffffff;
    if (ppuStack_130 < (longlong *)0xfe0000000000001) {
      uVar15 = (longlong)ppuStack_130 * 8 + 8;
    }
    puVar7 = operator_new__(uVar15);
    *puVar7 = ppuStack_130;
    plVar8 = (longlong *)0x0;
    if (ppuStack_130 != (uint **)0x0) {
      do {
        (puVar7 + 1)[(longlong)plVar8] = 0;
        plVar8 = (longlong *)((longlong)plVar8 + 1);
      } while (ppuStack_130 != (uint **)plVar8);
    }
    plStack_110[2] = (longlong)(puVar7 + 1);
    *(undefined4 *)((longlong)plStack_110 + 0x1c) = 1;
    lVar17 = *plStack_110;
    plStack_e8 = (longlong *)puStack_120[4];
    lVar9 = *plStack_e8;
    if (lVar17 != lVar9) {
      if (lVar17 != 0) {
        *(int *)(lVar17 + 8) = *(int *)(lVar17 + 8) + -1;
        pvVar10 = (void *)*plStack_110;
        if (*(int *)((longlong)pvVar10 + 8) == 0) {
          lVar17 = *(longlong *)((longlong)pvVar10 + 0x10);
          if (lVar17 != 0) {
            lStack_e0 = lVar17 + *(longlong *)(lVar17 + -8) * 0x20;
            lStack_d0 = lStack_e0;
            if (lVar17 != lStack_e0) {
              do {
                puStack_108 = (uint *)(lStack_e0 - lStack_d0);
                uStack_100 = lStack_d0 - 8;
                piVar12 = (int *)(*(longlong *)(lStack_e0 + -8) + 0x1c);
                *piVar12 = *piVar12 + -1;
                ppuStack_130 = *(uint ***)(lStack_e0 + -8);
                if (*(int *)((longlong)ppuStack_130 + 0x1c) == 0) {
                  plVar8 = (longlong *)ppuStack_130[2];
                  if (plVar8 != (longlong *)0x0) {
                    ppuStack_130 = (uint **)(plVar8 + plVar8[-1]);
                    for (plStack_118 = (longlong *)ppuStack_130; plVar8 != plStack_118;
                        plStack_118 = plStack_118 + -1) {
                      pcStack_128 = (code *)((longlong)plStack_118 - (longlong)ppuStack_130);
                      if (plStack_118[-1] != 0) {
                        piVar12 = (int *)(plStack_118[-1] + 8);
                        *piVar12 = *piVar12 + -1;
                        pvVar10 = (void *)plStack_118[-1];
                        if (*(int *)((longlong)pvVar10 + 8) == 0) {
                          if (*(void **)((longlong)pvVar10 + 0x10) != (void *)0x0) {
                            operator_delete__(*(void **)((longlong)pvVar10 + 0x10));
                            pvVar10 = *(void **)((longlong)((longlong)pcStack_128 + -8) +
                                                (longlong)ppuStack_130);
                          }
                          operator_delete(pvVar10);
                        }
                        *(undefined8 *)
                         ((longlong)((longlong)pcStack_128 + -8) + (longlong)ppuStack_130) = 0;
                        plVar8 = *(longlong **)
                                  (*(longlong *)((longlong)puStack_108 + uStack_100) + 0x10);
                      }
                    }
                    operator_delete__(plVar8 + -1);
                    ppuStack_130 = *(uint ***)((longlong)puStack_108 + lStack_d0 + -8);
                    if (ppuStack_130 == (uint **)0x0) goto LAB_0048d6ec;
                  }
                  if (ppuStack_130[1] != (uint *)0x0) {
                    piVar12 = (int *)((longlong)ppuStack_130[1] + 8);
                    *piVar12 = *piVar12 + -1;
                    pvVar10 = ppuStack_130[1];
                    if (*(int *)((longlong)pvVar10 + 8) == 0) {
                      plVar8 = *(longlong **)((longlong)pvVar10 + 0x10);
                      if (plVar8 != (longlong *)0x0) {
                        pcStack_128 = (code *)(plVar8 + plVar8[-1]);
                        while ((code *)plVar8 != pcStack_128) {
                          *(int *)(*(longlong *)((longlong)pcStack_128 + -8) + 8) =
                               *(int *)(*(longlong *)((longlong)pcStack_128 + -8) + 8) + -1;
                          puVar2 = *(undefined **)((longlong)pcStack_128 + -8);
                          if ((puVar2 != &DAT_00cfd470) && (*(int *)(puVar2 + 8) == 0)) {
                            operator_delete__(puVar2);
                          }
                          pcStack_128 = (code *)((longlong)pcStack_128 + -8);
                          plVar8 = *(longlong **)((longlong)ppuStack_130[1] + 0x10);
                        }
                        operator_delete__(plVar8 + -1);
                        pvVar10 = ppuStack_130[1];
                      }
                      operator_delete(pvVar10);
                    }
                    ppuStack_130[1] = (uint *)0x0;
                  }
                  FUN_0094a890(ppuStack_130);
                  operator_delete(ppuStack_130);
                }
LAB_0048d6ec:
                lStack_e0 = lStack_e0 + -0x20;
                lVar17 = *(longlong *)(*plStack_110 + 0x10);
              } while (lVar17 != lStack_e0);
            }
            operator_delete__((void *)(lVar17 + -8));
            pvVar10 = (void *)*plStack_110;
          }
          operator_delete(pvVar10);
        }
        *plStack_110 = 0;
        lVar9 = *plStack_e8;
      }
      *plStack_110 = lVar9;
      if (lVar9 != 0) {
        *(int *)(lVar9 + 8) = *(int *)(lVar9 + 8) + 1;
      }
      plStack_e8 = (longlong *)puStack_120[4];
    }
    lVar17 = plStack_110[1];
    lVar9 = plStack_e8[1];
    if (lVar17 != lVar9) {
      if (lVar17 != 0) {
        *(int *)(lVar17 + 8) = *(int *)(lVar17 + 8) + -1;
        pvVar10 = (void *)plStack_110[1];
        if (*(int *)((longlong)pvVar10 + 8) == 0) {
          plVar8 = *(longlong **)((longlong)pvVar10 + 0x10);
          if (plVar8 != (longlong *)0x0) {
            ppuStack_130 = (uint **)(plVar8 + plVar8[-1]);
            while ((uint **)plVar8 != ppuStack_130) {
              *(int *)((longlong)ppuStack_130[-1] + 8) =
                   *(int *)((longlong)ppuStack_130[-1] + 8) + -1;
              puVar2 = (undefined *)ppuStack_130[-1];
              if ((puVar2 != &DAT_00cfd470) && (*(int *)(puVar2 + 8) == 0)) {
                operator_delete__(puVar2);
              }
              ppuStack_130 = ppuStack_130 + -1;
              plVar8 = *(longlong **)(plStack_110[1] + 0x10);
            }
            operator_delete__(plVar8 + -1);
            pvVar10 = (void *)plStack_110[1];
          }
          operator_delete(pvVar10);
        }
        plStack_110[1] = 0;
        lVar9 = plStack_e8[1];
      }
      plStack_110[1] = lVar9;
      if (lVar9 != 0) {
        *(int *)(lVar9 + 8) = *(int *)(lVar9 + 8) + 1;
      }
      plStack_e8 = (longlong *)puStack_120[4];
    }
    plVar8 = plStack_e8;
    if (0 < 1 << ((byte)(int)plStack_e8[3] & 0x1f)) {
      ppuStack_130 = (uint **)0x0;
      do {
        pcStack_128 = (code *)((longlong)ppuStack_130 * 8 + plStack_110[2]);
        plStack_118 = (longlong *)((longlong)ppuStack_130 * 8 + plVar8[2]);
        lVar17 = *(longlong *)pcStack_128;
        lVar9 = *plStack_118;
        if (lVar17 != lVar9) {
          if (lVar17 != 0) {
            *(int *)(lVar17 + 8) = *(int *)(lVar17 + 8) + -1;
            pvVar10 = *(void **)pcStack_128;
            if (*(int *)((longlong)pvVar10 + 8) == 0) {
              if (*(void **)((longlong)pvVar10 + 0x10) != (void *)0x0) {
                operator_delete__(*(void **)((longlong)pvVar10 + 0x10));
                pvVar10 = *(void **)pcStack_128;
              }
              operator_delete(pvVar10);
            }
            *(longlong *)pcStack_128 = 0;
            lVar9 = *plStack_118;
          }
          *(longlong *)pcStack_128 = lVar9;
          if (lVar9 != 0) {
            *(int *)(lVar9 + 8) = *(int *)(lVar9 + 8) + 1;
          }
          plVar8 = (longlong *)puStack_120[4];
        }
        plVar1 = (longlong *)((longlong)ppuStack_130 + 1);
        iVar3 = (uint)ppuStack_130 + 1;
        ppuStack_130 = (uint **)plVar1;
      } while (iVar3 < 1 << ((byte)(int)plVar8[3] & 0x1f));
    }
    plStack_e8 = plVar8;
    *(int *)((longlong)plStack_e8 + 0x1c) = *(int *)((longlong)plStack_e8 + 0x1c) + -1;
    plStack_e8 = (longlong *)puStack_120[4];
    if (*(int *)((longlong)plStack_e8 + 0x1c) == 0) {
      plVar8 = (longlong *)plStack_e8[2];
      if (plVar8 != (longlong *)0x0) {
        ppuStack_130 = (uint **)(plVar8 + plVar8[-1]);
        for (pcStack_128 = (code *)ppuStack_130; (code *)plVar8 != pcStack_128;
            pcStack_128 = (code *)((longlong)pcStack_128 + -8)) {
          plStack_118 = (longlong *)((longlong)pcStack_128 - (longlong)ppuStack_130);
          if (*(longlong *)((longlong)pcStack_128 + -8) != 0) {
            piVar12 = (int *)(*(longlong *)((longlong)pcStack_128 + -8) + 8);
            *piVar12 = *piVar12 + -1;
            pvVar10 = *(void **)((longlong)pcStack_128 + -8);
            if (*(int *)((longlong)pvVar10 + 8) == 0) {
              if (*(void **)((longlong)pvVar10 + 0x10) != (void *)0x0) {
                operator_delete__(*(void **)((longlong)pvVar10 + 0x10));
                pvVar10 = *(void **)((longlong)(ppuStack_130 + -1) + (longlong)plStack_118);
              }
              operator_delete(pvVar10);
            }
            *(undefined8 *)((longlong)(ppuStack_130 + -1) + (longlong)plStack_118) = 0;
            plVar8 = *(longlong **)(puStack_120[4] + 0x10);
          }
        }
        operator_delete__(plVar8 + -1);
        plStack_e8 = (longlong *)puStack_120[4];
        if (plStack_e8 == (longlong *)0x0) goto LAB_0048dcf7;
      }
      if (plStack_e8[1] != 0) {
        piVar12 = (int *)(plStack_e8[1] + 8);
        *piVar12 = *piVar12 + -1;
        pvVar10 = (void *)plStack_e8[1];
        if (*(int *)((longlong)pvVar10 + 8) == 0) {
          plVar8 = *(longlong **)((longlong)pvVar10 + 0x10);
          if (plVar8 != (longlong *)0x0) {
            ppuStack_130 = (uint **)(plVar8 + plVar8[-1]);
            while ((uint **)plVar8 != ppuStack_130) {
              *(int *)((longlong)ppuStack_130[-1] + 8) =
                   *(int *)((longlong)ppuStack_130[-1] + 8) + -1;
              puVar2 = (undefined *)ppuStack_130[-1];
              if ((puVar2 != &DAT_00cfd470) && (*(int *)(puVar2 + 8) == 0)) {
                operator_delete__(puVar2);
              }
              ppuStack_130 = ppuStack_130 + -1;
              plVar8 = *(longlong **)(plStack_e8[1] + 0x10);
            }
            operator_delete__(plVar8 + -1);
            pvVar10 = (void *)plStack_e8[1];
          }
          operator_delete(pvVar10);
        }
        plStack_e8[1] = 0;
      }
      if (*plStack_e8 != 0) {
        piVar12 = (int *)(*plStack_e8 + 8);
        *piVar12 = *piVar12 + -1;
        pvVar10 = (void *)*plStack_e8;
        if (*(int *)((longlong)pvVar10 + 8) == 0) {
          lVar17 = *(longlong *)((longlong)pvVar10 + 0x10);
          if (lVar17 != 0) {
            lStack_e0 = *(longlong *)(lVar17 + -8) * 0x20 + lVar17;
            lStack_d0 = lStack_e0;
            if (lVar17 != lStack_e0) {
              do {
                puStack_108 = (uint *)(lStack_e0 - lStack_d0);
                uStack_100 = lStack_d0 - 8;
                piVar12 = (int *)(*(longlong *)(lStack_e0 + -8) + 0x1c);
                *piVar12 = *piVar12 + -1;
                ppuStack_130 = *(uint ***)(lStack_e0 + -8);
                if (*(int *)((longlong)ppuStack_130 + 0x1c) == 0) {
                  plVar8 = (longlong *)ppuStack_130[2];
                  if (plVar8 != (longlong *)0x0) {
                    ppuStack_130 = (uint **)(plVar8 + plVar8[-1]);
                    for (plStack_118 = (longlong *)ppuStack_130; plVar8 != plStack_118;
                        plStack_118 = plStack_118 + -1) {
                      pcStack_128 = (code *)((longlong)plStack_118 - (longlong)ppuStack_130);
                      if (plStack_118[-1] != 0) {
                        piVar12 = (int *)(plStack_118[-1] + 8);
                        *piVar12 = *piVar12 + -1;
                        pvVar10 = (void *)plStack_118[-1];
                        if (*(int *)((longlong)pvVar10 + 8) == 0) {
                          if (*(void **)((longlong)pvVar10 + 0x10) != (void *)0x0) {
                            operator_delete__(*(void **)((longlong)pvVar10 + 0x10));
                            pvVar10 = *(void **)((longlong)(ppuStack_130 + -1) +
                                                (longlong)pcStack_128);
                          }
                          operator_delete(pvVar10);
                        }
                        *(undefined8 *)((longlong)(ppuStack_130 + -1) + (longlong)pcStack_128) = 0;
                        plVar8 = *(longlong **)
                                  (*(longlong *)((longlong)puStack_108 + uStack_100) + 0x10);
                      }
                    }
                    operator_delete__(plVar8 + -1);
                    ppuStack_130 = *(uint ***)(lStack_d0 + -8 + (longlong)puStack_108);
                    if (ppuStack_130 == (uint **)0x0) goto LAB_0048dcab;
                  }
                  if (ppuStack_130[1] != (uint *)0x0) {
                    piVar12 = (int *)((longlong)ppuStack_130[1] + 8);
                    *piVar12 = *piVar12 + -1;
                    pvVar10 = ppuStack_130[1];
                    if (*(int *)((longlong)pvVar10 + 8) == 0) {
                      plVar8 = *(longlong **)((longlong)pvVar10 + 0x10);
                      if (plVar8 != (longlong *)0x0) {
                        pcStack_128 = (code *)(plVar8 + plVar8[-1]);
                        while ((code *)plVar8 != pcStack_128) {
                          *(int *)(*(longlong *)((longlong)pcStack_128 + -8) + 8) =
                               *(int *)(*(longlong *)((longlong)pcStack_128 + -8) + 8) + -1;
                          puVar2 = *(undefined **)((longlong)pcStack_128 + -8);
                          if ((puVar2 != &DAT_00cfd470) && (*(int *)(puVar2 + 8) == 0)) {
                            operator_delete__(puVar2);
                          }
                          pcStack_128 = (code *)((longlong)pcStack_128 + -8);
                          plVar8 = *(longlong **)((longlong)ppuStack_130[1] + 0x10);
                        }
                        operator_delete__(plVar8 + -1);
                        pvVar10 = ppuStack_130[1];
                      }
                      operator_delete(pvVar10);
                    }
                    ppuStack_130[1] = (uint *)0x0;
                  }
                  FUN_0094a890(ppuStack_130);
                  operator_delete(ppuStack_130);
                }
LAB_0048dcab:
                lStack_e0 = lStack_e0 + -0x20;
                lVar17 = *(longlong *)(*plStack_e8 + 0x10);
              } while (lVar17 != lStack_e0);
            }
            operator_delete__((void *)(lVar17 + -8));
            pvVar10 = (void *)*plStack_e8;
          }
          operator_delete(pvVar10);
        }
        *plStack_e8 = 0;
      }
      operator_delete(plStack_e8);
    }
LAB_0048dcf7:
    ppuStack_130 = (uint **)plStack_110;
    puStack_120[4] = plStack_110;
    uVar16 = *apuStack_38[0];
    if ((int)uVar16 < 1) goto LAB_0048eb03;
LAB_0048dd1e:
    lVar17 = 0;
    uVar4 = 0;
    do {
      lVar9 = lVar17 + 0xc;
      lVar17 = lVar17 + 2;
      uVar4 = (int)*(char *)((longlong)apuStack_38[0] + lVar9) ^
              (uVar4 >> 1 | (uint)((uVar4 & 1) != 0) << 0x1f);
    } while ((int)lVar17 < (int)uVar16);
  }
  else {
    puVar14 = apuStack_38[0] + 3;
    if ((uint *)0xb03145 < puVar14) {
      if ((&DAT_00b03146 < puVar14) &&
         (ppuStack_130._0_4_ = (uint)ppuStack_130 - 1, -1 < (int)(uint)ppuStack_130)) {
        uVar15 = 0;
        do {
          *(undefined *)((longlong)puVar14 + uVar15 + (longlong)(int)(uint)ppuStack_130) =
               (&DAT_00b03146)[uVar15 + (longlong)(int)(uint)ppuStack_130];
          uVar15 = uVar15 - 1;
        } while (uVar15 != ~(ulonglong)(uint)ppuStack_130);
      }
      goto LAB_0048d3ef;
    }
    if ((int)(uint)ppuStack_130 < 1) goto LAB_0048d3ef;
    lVar17 = 0;
    do {
      *(undefined *)((longlong)puVar14 + lVar17) = (&DAT_00b03146)[lVar17];
      lVar17 = lVar17 + 1;
    } while ((int)lVar17 < (int)(uint)ppuStack_130);
    plVar8 = (longlong *)puStack_120[4];
    if (1 < *(int *)((longlong)plVar8 + 0x1c)) goto LAB_0048d402;
LAB_0048eaea:
    uVar16 = *apuStack_38[0];
    ppuStack_130 = (uint **)plVar8;
    if (0 < (int)uVar16) goto LAB_0048dd1e;
LAB_0048eb03:
    uVar4 = 0;
  }
  plStack_118 = (undefined8 *)0x0;
  lStack_e0 = (longlong)(int)((1 << ((byte)(int)ppuStack_130[3] & 0x1f)) - 1U & uVar4) * 8;
  while( true ) {
    pcStack_128 = (code *)(lStack_e0 + (longlong)ppuStack_130[2]);
    puVar14 = *(uint **)pcStack_128;
    if (puVar14 == (uint *)0x0) break;
    uVar16 = *puVar14;
    plStack_110 = (longlong *)CONCAT44(plStack_110._4_4_,uVar16);
    if ((int)uVar16 <= (int)(uint)plStack_118) break;
    if (1 < (int)puVar14[2]) {
      uStack_a0 = 6;
      uVar16 = uVar16 + 1 + (uVar16 >> 1);
      if (uVar16 < 0x20) {
        uVar16 = 0x20;
      }
      ppuStack_130 = (uint **)CONCAT44(ppuStack_130._4_4_,uVar16);
      puStack_108 = operator_new(0x18);
      uStack_a0 = 6;
      uVar15 = (longlong)(int)(uint)ppuStack_130 * 4;
      if (0x1fc0000000000000 < (ulonglong)(longlong)(int)(uint)ppuStack_130) {
        uVar15 = 0xffffffffffffffff;
      }
      pvVar10 = operator_new__(uVar15);
      *(void **)(puStack_108 + 4) = pvVar10;
      *puStack_108 = (uint)plStack_110;
      puStack_108[1] = (uint)ppuStack_130;
      puStack_108[2] = 1;
      piVar12 = *(int **)pcStack_128;
      if (*piVar12 == 0) {
LAB_0048de3c:
        piVar12[2] = piVar12[2] + -1;
        pvVar10 = *(void **)pcStack_128;
        if (*(int *)((longlong)pvVar10 + 8) == 0) {
          if (*(void **)((longlong)pvVar10 + 0x10) != (void *)0x0) {
            operator_delete__(*(void **)((longlong)pvVar10 + 0x10));
            pvVar10 = *(void **)pcStack_128;
          }
          operator_delete(pvVar10);
        }
      }
      else {
        FUN_008de3b0(pvVar10,*(undefined8 *)(piVar12 + 4));
        piVar12 = *(int **)pcStack_128;
        if (piVar12 != (int *)0x0) goto LAB_0048de3c;
      }
      *(uint **)pcStack_128 = puStack_108;
      ppuStack_130 = (uint **)puStack_120[4];
      puVar14 = puStack_108;
    }
    plStack_110 = (longlong *)
                  CONCAT44(plStack_110._4_4_,
                           *(undefined4 *)(*(longlong *)(puVar14 + 4) + (longlong)plStack_118 * 4));
    puVar14 = ppuStack_130[1];
    if ((puVar14 != (uint *)0x0) && (1 < (int)puVar14[2])) {
      uVar16 = *puVar14;
      uStack_a0 = 6;
      plStack_e8 = (longlong *)CONCAT44(plStack_e8._4_4_,uVar16);
      uVar16 = uVar16 + 1 + (uVar16 >> 1);
      if (uVar16 < 0x20) {
        uVar16 = 0x20;
      }
      pcStack_128 = (code *)CONCAT44(pcStack_128._4_4_,uVar16);
      puStack_108 = operator_new(0x18);
      uStack_100 = (ulonglong)(int)(uint)pcStack_128;
      uStack_a0 = 6;
      uVar15 = 0xffffffffffffffff;
      if (uStack_100 < 0xfe0000000000001) {
        uVar15 = uStack_100 * 8 + 8;
      }
      puVar11 = operator_new__(uVar15);
      puVar13 = puVar11 + 1;
      uVar15 = 0;
      *puVar11 = uStack_100;
      do {
        puVar13[uVar15] = (ulonglong)&DAT_00cfd470;
        DAT_00cfd47c = 0;
        *(undefined4 *)puVar13[uVar15] = 0;
        *(undefined4 *)(puVar13[uVar15] + 4) = 0;
        puVar11 = puVar13 + uVar15;
        uVar15 = uVar15 + 1;
        *(int *)(*puVar11 + 8) = *(int *)(*puVar11 + 8) + 1;
      } while (uStack_100 != uVar15);
      puStack_108[2] = 1;
      puStack_108[1] = (uint)pcStack_128;
      *(ulonglong **)(puStack_108 + 4) = puVar13;
      *puStack_108 = (uint)plStack_e8;
      piVar12 = (int *)ppuStack_130[1];
      if (*piVar12 == 0) {
LAB_0048dfaa:
        piVar12[2] = piVar12[2] + -1;
        pvVar10 = ppuStack_130[1];
        if (*(int *)((longlong)pvVar10 + 8) == 0) {
          puVar13 = *(ulonglong **)((longlong)pvVar10 + 0x10);
          if (puVar13 != (ulonglong *)0x0) {
            pcStack_128 = (code *)(puVar13 + puVar13[-1]);
            while ((code *)puVar13 != pcStack_128) {
              *(int *)(*(ulonglong *)((longlong)pcStack_128 + -8) + 8) =
                   *(int *)(*(ulonglong *)((longlong)pcStack_128 + -8) + 8) + -1;
              puVar2 = *(undefined **)((longlong)pcStack_128 + -8);
              if ((puVar2 != &DAT_00cfd470) && (*(int *)(puVar2 + 8) == 0)) {
                operator_delete__(puVar2);
              }
              pcStack_128 = (code *)((longlong)pcStack_128 + -8);
              puVar13 = *(ulonglong **)((longlong)ppuStack_130[1] + 0x10);
            }
            operator_delete__(puVar13 + -1);
            pvVar10 = ppuStack_130[1];
          }
          operator_delete(pvVar10);
        }
      }
      else {
        uStack_a0 = 6;
        FUN_008dc690(puVar13,*(undefined8 *)(piVar12 + 4));
        piVar12 = (int *)ppuStack_130[1];
        if (piVar12 != (int *)0x0) goto LAB_0048dfaa;
      }
      ppuStack_130[1] = puStack_108;
      puVar14 = puStack_108;
    }
    puVar14 = *(uint **)(*(longlong *)(puVar14 + 4) + (longlong)(int)(uint)plStack_110 * 8);
    uVar16 = *puVar14;
    if (uVar16 == *apuStack_38[0]) {
      if ((uVar16 == 0) || ((int)uVar16 < 1)) {
LAB_0048e0b5:
        if (-1 < (int)(uint)plStack_110) goto LAB_0048e0c3;
        break;
      }
      if ((char)puVar14[3] == (char)apuStack_38[0][3]) {
        uVar15 = 0;
        do {
          if (uVar15 == uVar16 - 1) goto LAB_0048e0b5;
          lVar9 = uVar15 + 0xd;
          lVar17 = uVar15 + 0xd;
          uVar15 = uVar15 + 1;
        } while (*(char *)((longlong)puVar14 + lVar9) ==
                 *(char *)((longlong)apuStack_38[0] + lVar17));
      }
    }
    plStack_118 = (longlong *)((longlong)plStack_118 + 1);
    ppuStack_130 = (uint **)puStack_120[4];
  }
  uStack_a0 = 6;
  uVar5 = FUN_0090f670(puStack_120 + 4,apuStack_38);
  plStack_110 = (longlong *)CONCAT44(plStack_110._4_4_,uVar5);
LAB_0048e0c3:
  plStack_e8 = (longlong *)puStack_120[4];
  puVar14 = (uint *)*plStack_e8;
  if ((puVar14 != (uint *)0x0) && (1 < (int)puVar14[2])) {
    uVar16 = *puVar14;
    uStack_a0 = 6;
    uStack_100 = CONCAT44(uStack_100._4_4_,uVar16);
    uVar16 = uVar16 + 1 + (uVar16 >> 1);
    if (uVar16 < 0x20) {
      uVar16 = 0x20;
    }
    puStack_108 = (uint *)CONCAT44(puStack_108._4_4_,uVar16);
    puStack_b8 = operator_new(0x18);
    uStack_b0 = (ulonglong)(int)(uint)puStack_108;
    uVar15 = 0xffffffffffffffff;
    if (uStack_b0 < 0x3f8000000000001) {
      uVar15 = uStack_b0 * 0x20 + 8;
    }
    uStack_a0 = 6;
    puStack_f0 = operator_new__(uVar15);
    puStack_f8 = puStack_f0 + 1;
    *puStack_f0 = uStack_b0;
    ppuStack_130 = (uint **)(uStack_b0 - 1);
    pcStack_128 = (code *)puStack_f8;
    do {
      uStack_a0 = 9;
      plStack_d8 = (longlong *)ppuStack_130;
      plStack_118 = operator_new(0x20);
      *plStack_118 = 0;
      plStack_118[1] = 0;
      *(undefined4 *)(plStack_118 + 3) = 3;
      puVar6 = operator_new__(0x48);
      *puVar6 = 8;
      puVar7 = puVar6 + 1;
      do {
        *puVar7 = 0;
        puVar7 = puVar7 + 1;
      } while (puVar7 != puVar6 + 9);
      ppuStack_130 = (uint **)((longlong)ppuStack_130 + -1);
      plStack_118[2] = (longlong)(puVar6 + 1);
      puVar13 = (ulonglong *)((longlong)pcStack_128 + 0x20);
      *(undefined4 *)((longlong)plStack_118 + 0x1c) = 1;
      *(longlong **)((longlong)puStack_f8 + (longlong)pcStack_128 + (0x10 - (longlong)puStack_f0)) =
           plStack_118;
      *(undefined4 *)pcStack_128 = 0;
      *(undefined4 *)((longlong)pcStack_128 + 0x10) = 0;
      *(ulonglong *)((longlong)pcStack_128 + 8) = 0;
      pcStack_128 = (code *)puVar13;
    } while (ppuStack_130 != (uint **)0xffffffffffffffff);
    *(ulonglong **)(puStack_b8 + 4) = puStack_f8;
    puStack_b8[1] = (uint)puStack_108;
    *puStack_b8 = (uint)uStack_100;
    puStack_b8[2] = 1;
    piVar12 = (int *)*plStack_e8;
    if (*piVar12 == 0) {
LAB_0048e278:
      piVar12[2] = piVar12[2] + -1;
      pvVar10 = (void *)*plStack_e8;
      if (*(int *)((longlong)pvVar10 + 8) == 0) {
        lVar17 = *(longlong *)((longlong)pvVar10 + 0x10);
        if (lVar17 != 0) {
          lStack_e0 = *(longlong *)(lVar17 + -8) * 0x20 + lVar17;
          lStack_d0 = lStack_e0;
          if (lVar17 != lStack_e0) {
            do {
              puStack_108 = (uint *)(lStack_e0 - lStack_d0);
              uStack_100 = lStack_d0 - 8;
              piVar12 = (int *)(*(longlong *)(lStack_e0 + -8) + 0x1c);
              *piVar12 = *piVar12 + -1;
              ppuStack_130 = *(uint ***)(lStack_e0 + -8);
              if (*(int *)((longlong)ppuStack_130 + 0x1c) == 0) {
                puVar7 = (undefined8 *)ppuStack_130[2];
                if (puVar7 != (undefined8 *)0x0) {
                  ppuStack_130 = (uint **)(puVar7 + puVar7[-1]);
                  for (plStack_118 = (longlong *)ppuStack_130; puVar7 != plStack_118;
                      plStack_118 = plStack_118 + -1) {
                    pcStack_128 = (code *)((longlong)plStack_118 - (longlong)ppuStack_130);
                    if (plStack_118[-1] != 0) {
                      piVar12 = (int *)(plStack_118[-1] + 8);
                      *piVar12 = *piVar12 + -1;
                      pvVar10 = (void *)plStack_118[-1];
                      if (*(int *)((longlong)pvVar10 + 8) == 0) {
                        if (*(void **)((longlong)pvVar10 + 0x10) != (void *)0x0) {
                          operator_delete__(*(void **)((longlong)pvVar10 + 0x10));
                          pvVar10 = *(void **)((longlong)((longlong)pcStack_128 + -8) +
                                              (longlong)ppuStack_130);
                        }
                        operator_delete(pvVar10);
                      }
                      *(undefined8 *)
                       ((longlong)((longlong)pcStack_128 + -8) + (longlong)ppuStack_130) = 0;
                      puVar7 = *(undefined8 **)
                                (*(longlong *)((longlong)puStack_108 + uStack_100) + 0x10);
                    }
                  }
                  operator_delete__(puVar7 + -1);
                  ppuStack_130 = *(uint ***)(lStack_d0 + -8 + (longlong)puStack_108);
                  if (ppuStack_130 == (uint **)0x0) goto LAB_0048e47a;
                }
                if (ppuStack_130[1] != (uint *)0x0) {
                  piVar12 = (int *)((longlong)ppuStack_130[1] + 8);
                  *piVar12 = *piVar12 + -1;
                  pvVar10 = ppuStack_130[1];
                  if (*(int *)((longlong)pvVar10 + 8) == 0) {
                    puVar13 = *(ulonglong **)((longlong)pvVar10 + 0x10);
                    if (puVar13 != (ulonglong *)0x0) {
                      pcStack_128 = (code *)(puVar13 + puVar13[-1]);
                      while ((code *)puVar13 != pcStack_128) {
                        *(int *)(*(ulonglong *)((longlong)pcStack_128 + -8) + 8) =
                             *(int *)(*(ulonglong *)((longlong)pcStack_128 + -8) + 8) + -1;
                        puVar2 = *(undefined **)((longlong)pcStack_128 + -8);
                        if ((puVar2 != &DAT_00cfd470) && (*(int *)(puVar2 + 8) == 0)) {
                          operator_delete__(puVar2);
                        }
                        pcStack_128 = (code *)((longlong)pcStack_128 + -8);
                        puVar13 = *(ulonglong **)((longlong)ppuStack_130[1] + 0x10);
                      }
                      operator_delete__(puVar13 + -1);
                      pvVar10 = ppuStack_130[1];
                    }
                    operator_delete(pvVar10);
                  }
                  ppuStack_130[1] = (uint *)0x0;
                }
                FUN_0094a890(ppuStack_130);
                operator_delete(ppuStack_130);
              }
LAB_0048e47a:
              lStack_e0 = lStack_e0 + -0x20;
              lVar17 = *(longlong *)(*plStack_e8 + 0x10);
            } while (lVar17 != lStack_e0);
          }
          operator_delete__((void *)(lVar17 + -8));
          pvVar10 = (void *)*plStack_e8;
        }
        operator_delete(pvVar10);
      }
    }
    else {
      FUN_008da710(puStack_f8,*(undefined8 *)(piVar12 + 4));
      piVar12 = (int *)*plStack_e8;
      if (piVar12 != (int *)0x0) goto LAB_0048e278;
    }
    *plStack_e8 = (longlong)puStack_b8;
    puVar14 = puStack_b8;
  }
  plStack_110 = (longlong *)((longlong)(int)(uint)plStack_110 * 0x20 + *(longlong *)(puVar14 + 4));
  *(undefined4 *)plStack_110 = piStack_28._0_4_;
  *(undefined8 **)((longlong)plStack_110 + 8) = puStack_20;
  *(undefined4 *)((longlong)plStack_110 + 0x10) = uStack_18;
  if (puStack_10 != *(undefined8 **)((longlong)plStack_110 + 0x18)) {
    piVar12 = (int *)((longlong)*(undefined8 **)((longlong)plStack_110 + 0x18) + 0x1c);
    *piVar12 = *piVar12 + -1;
    ppuStack_130 = *(uint ***)((longlong)plStack_110 + 0x18);
    if (*(int *)((longlong)ppuStack_130 + 0x1c) == 0) {
      puVar7 = (undefined8 *)ppuStack_130[2];
      if (puVar7 != (undefined8 *)0x0) {
        ppuStack_130 = (uint **)(puVar7 + puVar7[-1]);
        for (plStack_118 = (longlong *)ppuStack_130; puVar7 != plStack_118;
            plStack_118 = plStack_118 + -1) {
          pcStack_128 = (code *)((longlong)plStack_118 - (longlong)ppuStack_130);
          if (plStack_118[-1] != 0) {
            piVar12 = (int *)(plStack_118[-1] + 8);
            *piVar12 = *piVar12 + -1;
            pvVar10 = (void *)plStack_118[-1];
            if (*(int *)((longlong)pvVar10 + 8) == 0) {
              if (*(void **)((longlong)pvVar10 + 0x10) != (void *)0x0) {
                operator_delete__(*(void **)((longlong)pvVar10 + 0x10));
                pvVar10 = *(void **)((longlong)((longlong)pcStack_128 + -8) + (longlong)ppuStack_130
                                    );
              }
              operator_delete(pvVar10);
            }
            *(undefined8 *)((longlong)((longlong)pcStack_128 + -8) + (longlong)ppuStack_130) = 0;
            puVar7 = *(undefined8 **)(*(longlong *)((longlong)plStack_110 + 0x18) + 0x10);
          }
        }
        operator_delete__(puVar7 + -1);
        ppuStack_130 = *(uint ***)((longlong)plStack_110 + 0x18);
        if (ppuStack_130 == (uint **)0x0) goto LAB_0048e6ab;
      }
      if (ppuStack_130[1] != (uint *)0x0) {
        piVar12 = (int *)((longlong)ppuStack_130[1] + 8);
        *piVar12 = *piVar12 + -1;
        pvVar10 = ppuStack_130[1];
        if (*(int *)((longlong)pvVar10 + 8) == 0) {
          puVar13 = *(ulonglong **)((longlong)pvVar10 + 0x10);
          if (puVar13 != (ulonglong *)0x0) {
            pcStack_128 = (code *)(puVar13 + puVar13[-1]);
            while ((code *)puVar13 != pcStack_128) {
              *(int *)(*(ulonglong *)((longlong)pcStack_128 + -8) + 8) =
                   *(int *)(*(ulonglong *)((longlong)pcStack_128 + -8) + 8) + -1;
              puVar2 = *(undefined **)((longlong)pcStack_128 + -8);
              if ((puVar2 != &DAT_00cfd470) && (*(int *)(puVar2 + 8) == 0)) {
                operator_delete__(puVar2);
              }
              pcStack_128 = (code *)((longlong)pcStack_128 + -8);
              puVar13 = *(ulonglong **)((longlong)ppuStack_130[1] + 0x10);
            }
            operator_delete__(puVar13 + -1);
            pvVar10 = ppuStack_130[1];
          }
          operator_delete(pvVar10);
        }
        ppuStack_130[1] = (uint *)0x0;
      }
      FUN_0094a890(ppuStack_130);
      operator_delete(ppuStack_130);
    }
LAB_0048e6ab:
    *(undefined8 **)((longlong)plStack_110 + 0x18) = puStack_10;
    *(int *)((longlong)puStack_10 + 0x1c) = *(int *)((longlong)puStack_10 + 0x1c) + 1;
  }
  uVar16 = apuStack_38[0][2];
  apuStack_38[0][2] = uVar16 - 1;
  if ((apuStack_38[0] != (uint *)&DAT_00cfd470) && (uVar16 - 1 == 0)) {
    operator_delete__(apuStack_38[0]);
  }
  *(int *)((longlong)puStack_10 + 0x1c) = *(int *)((longlong)puStack_10 + 0x1c) + -1;
  ppuStack_130 = (uint **)puStack_10;
  if (*(int *)((longlong)puStack_10 + 0x1c) == 0) {
    puVar7 = (undefined8 *)puStack_10[2];
    if (puVar7 != (undefined8 *)0x0) {
      ppuStack_130 = (uint **)(puVar7 + puVar7[-1]);
      for (plStack_118 = (longlong *)ppuStack_130; puVar7 != plStack_118;
          plStack_118 = plStack_118 + -1) {
        pcStack_128 = (code *)((longlong)plStack_118 - (longlong)ppuStack_130);
        if (plStack_118[-1] != 0) {
          piVar12 = (int *)(plStack_118[-1] + 8);
          *piVar12 = *piVar12 + -1;
          pvVar10 = (void *)plStack_118[-1];
          if (*(int *)((longlong)pvVar10 + 8) == 0) {
            if (*(void **)((longlong)pvVar10 + 0x10) != (void *)0x0) {
              operator_delete__(*(void **)((longlong)pvVar10 + 0x10));
              pvVar10 = *(void **)((longlong)((longlong)pcStack_128 + -8) + (longlong)ppuStack_130);
            }
            operator_delete(pvVar10);
          }
          *(undefined8 *)((longlong)((longlong)pcStack_128 + -8) + (longlong)ppuStack_130) = 0;
          puVar7 = (undefined8 *)puStack_10[2];
        }
      }
      operator_delete__(puVar7 + -1);
      ppuStack_130 = (uint **)puStack_10;
      if (puStack_10 == (undefined8 *)0x0) goto LAB_0048e87a;
    }
    ppuStack_130 = (uint **)puStack_10;
    if (puStack_10[1] != 0) {
      piVar12 = (int *)(puStack_10[1] + 8);
      *piVar12 = *piVar12 + -1;
      pvVar10 = (void *)puStack_10[1];
      if (*(int *)((longlong)pvVar10 + 8) == 0) {
        puVar13 = *(ulonglong **)((longlong)pvVar10 + 0x10);
        if (puVar13 != (ulonglong *)0x0) {
          pcStack_128 = (code *)(puVar13 + puVar13[-1]);
          while ((code *)puVar13 != pcStack_128) {
            *(int *)(*(ulonglong *)((longlong)pcStack_128 + -8) + 8) =
                 *(int *)(*(ulonglong *)((longlong)pcStack_128 + -8) + 8) + -1;
            puVar2 = *(undefined **)((longlong)pcStack_128 + -8);
            if ((puVar2 != &DAT_00cfd470) && (*(int *)(puVar2 + 8) == 0)) {
              operator_delete__(puVar2);
            }
            pcStack_128 = (code *)((longlong)pcStack_128 + -8);
            puVar13 = *(ulonglong **)((longlong)ppuStack_130[1] + 0x10);
          }
          operator_delete__(puVar13 + -1);
          pvVar10 = ppuStack_130[1];
        }
        operator_delete(pvVar10);
      }
      ppuStack_130[1] = (uint *)0x0;
    }
    FUN_0094a890(ppuStack_130);
    operator_delete(ppuStack_130);
  }
LAB_0048e87a:
  pcStack_128 = *(code **)(*_DAT_00cf4050 + 0x100);
  uVar16 = 0;
  do {
    uVar4 = uVar16;
    uVar16 = uVar4 + 1;
  } while ("~PBUS"[uVar16] != '\0');
  ppuStack_130 = (uint **)CONCAT44(ppuStack_130._4_4_,uVar16);
  uVar16 = uVar4 + 2 + (uVar16 >> 1);
  if (uVar16 < 0x20) {
    uVar15 = 0x30;
    plStack_118._0_4_ = 0x20;
  }
  else {
    uVar15 = (longlong)(int)uVar16 + 0x10;
    plStack_118._0_4_ = uVar16;
  }
  uStack_a0 = 4;
  piStack_28 = operator_new__(uVar15);
  piStack_28[2] = 1;
  piStack_28[1] = (uint)plStack_118;
  *piStack_28 = (uint)ppuStack_130;
  *(undefined1 *)((longlong)piStack_28 + (longlong)(int)(uint)ppuStack_130 + 0xc) = 0;
  if ((uint)ppuStack_130 != 0) {
    piVar12 = piStack_28 + 3;
    if ((int *)((longlong)&UINT_00b0313c + 3) < piVar12) {
      if (("~PBUS" < piVar12) &&
         (ppuStack_130._0_4_ = (uint)ppuStack_130 - 1, -1 < (int)(uint)ppuStack_130)) {
        uVar15 = 0;
        do {
          *(char *)((longlong)piVar12 + uVar15 + (longlong)(int)(uint)ppuStack_130) =
               "~PBUS"[uVar15 + (longlong)(int)(uint)ppuStack_130];
          uVar15 = uVar15 - 1;
        } while (uVar15 != ~(ulonglong)(uint)ppuStack_130);
      }
    }
    else if (0 < (int)(uint)ppuStack_130) {
      lVar17 = 0;
      do {
        *(char *)((longlong)piVar12 + lVar17) = "~PBUS"[lVar17];
        lVar17 = lVar17 + 1;
      } while ((int)lVar17 < (int)(uint)ppuStack_130);
    }
  }
  ppuStack_130 = apuStack_38;
  uStack_a0 = 7;
  FUN_0041f0b0(ppuStack_130,puStack_120);
  uStack_a0 = 8;
  uVar5 = (*pcStack_128)(_DAT_00cf4050,ppuStack_130,ppiStack_c8,1);
  *(undefined4 *)((longlong)puStack_120 + 0x2c) = uVar5;
  uVar16 = apuStack_38[0][2];
  apuStack_38[0][2] = uVar16 - 1;
  if ((apuStack_38[0] != (uint *)&DAT_00cfd470) && (uVar16 - 1 == 0)) {
    operator_delete__(apuStack_38[0]);
  }
  iVar3 = piStack_28[2];
  piStack_28[2] = iVar3 + -1;
  if ((piStack_28 != (int *)&DAT_00cfd470) && (iVar3 + -1 == 0)) {
    operator_delete__(piStack_28);
  }
  _Unwind_SjLj_Unregister(puStack_c0);
  return;
}


