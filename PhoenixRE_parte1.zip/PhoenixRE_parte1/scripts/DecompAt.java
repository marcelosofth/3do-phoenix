import ghidra.app.script.GhidraScript;
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.*;
import java.io.*;
public class DecompAt extends GhidraScript {
    @Override
    public void run() throws Exception {
        String[] a = getScriptArgs();
        String out = a[0];
        DecompInterface di = new DecompInterface();
        di.openProgram(currentProgram);
        for (int i = 1; i < a.length; i++) {
            Address ad = toAddr(a[i]);
            Function f = getFunctionContaining(ad);
            if (f == null) { println("no func at " + a[i]); continue; }
            DecompileResults r = di.decompileFunction(f, 120, monitor);
            try (PrintWriter w = new PrintWriter(new FileWriter(out + "/dec_" + f.getEntryPoint() + ".c"))) {
                w.println("// " + f.getName(true) + " @ " + f.getEntryPoint() + " size=" + f.getBody().getNumAddresses());
                StringBuilder cs = new StringBuilder("// callers: ");
                for (Function c : f.getCallingFunctions(monitor)) cs.append(c.getEntryPoint()).append(" ");
                w.println(cs);
                cs = new StringBuilder("// callees: ");
                for (Function c : f.getCalledFunctions(monitor)) cs.append(c.getEntryPoint()).append(":").append(c.getName()).append(" ");
                w.println(cs);
                w.println(r.decompileCompleted() ? r.getDecompiledFunction().getC() : "// decompile failed: " + r.getErrorMessage());
            }
        }
    }
}
