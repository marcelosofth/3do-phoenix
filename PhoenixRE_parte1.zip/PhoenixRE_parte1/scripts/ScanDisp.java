import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.scalar.*;
import java.io.*;
import java.util.*;
public class ScanDisp extends GhidraScript {
    @Override
    public void run() throws Exception {
        String out = getScriptArgs()[0];
        long[][] ranges = { {0x1087454L, 0x1097454L, 0}, {0x1000578L, 0x1000d78L, 1}, {0x129755cL, 0x159755cL, 2}, {0x159755cL, 0x15a755cL, 3} };
        String[] names = {"CLIO","MADAM","RAM","NVRAM"};
        Map<String,int[]> cnt = new TreeMap<>();
        Map<String,String> lows = new HashMap<>();
        try (PrintWriter w = new PrintWriter(new FileWriter(out + "/disp_hits.tsv"))) {
            w.println("region\tfunc\tfuncSize\tinsnAddr\tvalue\toffsetInRegion\tmnemonic");
            for (Function f : currentProgram.getFunctionManager().getFunctions(true)) {
                InstructionIterator it = currentProgram.getListing().getInstructions(f.getBody(), true);
                while (it.hasNext()) {
                    Instruction ins = it.next();
                    for (int o = 0; o < ins.getNumOperands(); o++) {
                        for (Object ob : ins.getOpObjects(o)) {
                            if (ob instanceof Scalar) {
                                long v = ((Scalar) ob).getUnsignedValue();
                                for (long[] r : ranges) {
                                    if (v >= r[0] && v < r[1]) {
                                        w.println(names[(int) r[2]] + "\t" + f.getEntryPoint() + "\t" + f.getBody().getNumAddresses() + "\t" + ins.getAddress() + "\t0x" + Long.toHexString(v) + "\t0x" + Long.toHexString(v - r[0]) + "\t" + ins.getMnemonicString());
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
