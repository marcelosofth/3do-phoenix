import ghidra.app.script.GhidraScript;
public class DisableHeavy extends GhidraScript {
    @Override
    public void run() throws Exception {
        for (String n : new String[]{"x86 Constant Reference Analyzer","Stack","Decompiler Parameter ID","Non-Returning Functions - Discovered"}) {
            try { setAnalysisOption(currentProgram, n, "false"); println("disabled " + n); } catch (Exception e) { println("skip " + n + ": " + e.getMessage()); }
        }
    }
}
