import ghidra.app.script.GhidraScript;
import ghidra.program.model.listing.*;
import ghidra.program.model.address.*;
import ghidra.program.model.symbol.*;
import ghidra.program.model.data.*;
import java.io.*;

public class ExportInfo extends GhidraScript {
    @Override
    public void run() throws Exception {
        String out = getScriptArgs().length > 0 ? getScriptArgs()[0] : "/tmp";
        // functions
        try (PrintWriter w = new PrintWriter(new FileWriter(out + "/functions.tsv"))) {
            w.println("addr\tsize\tname\tcalledBy\tcalling");
            for (Function f : currentProgram.getFunctionManager().getFunctions(true)) {
                w.println(f.getEntryPoint() + "\t" + f.getBody().getNumAddresses() + "\t" + f.getName(true)
                    + "\t" + f.getCallingFunctions(monitor).size() + "\t" + f.getCalledFunctions(monitor).size());
            }
        }
        // defined strings
        try (PrintWriter w = new PrintWriter(new FileWriter(out + "/strings.tsv"))) {
            w.println("addr\tstring\txrefs");
            DataIterator it = currentProgram.getListing().getDefinedData(true);
            while (it.hasNext()) {
                Data d = it.next();
                if (d.hasStringValue()) {
                    String s = String.valueOf(d.getValue()).replace("\n", "\\n").replace("\t", "\\t");
                    int n = d.getReferenceIteratorTo() != null ? 0 : 0;
                    ReferenceIterator ri = d.getReferenceIteratorTo();
                    StringBuilder sb = new StringBuilder();
                    int c = 0;
                    while (ri.hasNext() && c < 6) { sb.append(ri.next().getFromAddress()).append(","); c++; }
                    w.println(d.getAddress() + "\t" + s + "\t" + sb);
                }
            }
        }
        // imports
        try (PrintWriter w = new PrintWriter(new FileWriter(out + "/imports.tsv"))) {
            for (Symbol s : currentProgram.getSymbolTable().getExternalSymbols()) {
                w.println(s.getParentNamespace().getName() + "\t" + s.getName());
            }
        }
        // memory blocks
        try (PrintWriter w = new PrintWriter(new FileWriter(out + "/blocks.tsv"))) {
            for (var b : currentProgram.getMemory().getBlocks()) {
                w.println(b.getName() + "\t" + b.getStart() + "\t" + b.getEnd() + "\t" + b.getSize());
            }
        }
    }
}
