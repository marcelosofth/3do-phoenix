// FUN_00498540 @ 00498540 size=39
// callers: 0048f690 0048f170 
// callees: 

undefined8 FUN_00498540(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = *(longlong **)(param_1 + 0x3e0 + (ulonglong)(*(byte *)(param_1 + 0x460) & 0xf) * 8);
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00498561. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0xa8))();
    return uVar2;
  }
  return 0;
}


