// FUN_00498500 @ 00498500 size=41
// callers: 0048f9f0 
// callees: 

void FUN_00498500(longlong param_1,undefined1 param_2)

{
  longlong *plVar1;
  
  plVar1 = *(longlong **)(param_1 + 0x3e0 + (ulonglong)(*(byte *)(param_1 + 0x460) & 0xf) * 8);
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00498524. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar1 + 0x90))(plVar1,param_2);
    return;
  }
  return;
}


