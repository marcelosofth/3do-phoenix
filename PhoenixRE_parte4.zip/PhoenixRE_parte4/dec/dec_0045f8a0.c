// FUN_0045f8a0 @ 0045f8a0 size=21
// callers: 0048f9f0 
// callees: 

void FUN_0045f8a0(longlong param_1,uint param_2,undefined2 param_3)

{
  if ((ushort)param_2 < 0x100) {
    *(undefined2 *)(param_1 + 0x11894 + (ulonglong)(param_2 & 0x7f) * 2) = param_3;
  }
  return;
}


