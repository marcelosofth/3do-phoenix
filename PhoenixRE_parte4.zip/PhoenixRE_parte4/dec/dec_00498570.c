// FUN_00498570 @ 00498570 size=89
// callers: 0048f690 0048f170 
// callees: 

uint FUN_00498570(longlong param_1)

{
  longlong *plVar1;
  uint uVar2;
  
  plVar1 = *(longlong **)(param_1 + 0x3e0 + (ulonglong)(*(byte *)(param_1 + 0x460) & 0xf) * 8);
  if (plVar1 != (longlong *)0x0) {
    uVar2 = (**(code **)(*plVar1 + 0x98))();
    if (*(char *)(param_1 + 0x460) < '\0') {
      uVar2 = uVar2 & 0xf;
    }
    return uVar2;
  }
  uVar2 = 0x30;
  if ((char)*(byte *)(param_1 + 0x460) < '\0') {
    uVar2 = 0;
  }
  return uVar2;
}


