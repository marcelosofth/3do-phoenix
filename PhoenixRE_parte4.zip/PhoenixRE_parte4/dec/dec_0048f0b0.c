// FUN_0048f0b0 @ 0048f0b0 size=104
// callers: 
// callees: 

bool FUN_0048f0b0(longlong param_1,char param_2)

{
  int iVar1;
  bool bVar3;
  code *pcVar2;
  
  if (*(longlong *)(param_1 + 0x966b0) == 0) {
    iVar1 = *(int *)(param_1 + 0x966c8);
  }
  else {
    pcVar2 = *(code **)(param_1 + 0x966b8);
    if (((ulonglong)pcVar2 & 1) != 0) {
      pcVar2 = *(code **)(pcVar2 + *(longlong *)
                                    (*(longlong *)(param_1 + 0x966b0) +
                                    *(longlong *)(param_1 + 0x966c0)) + -1);
    }
    iVar1 = (*pcVar2)();
  }
  bVar3 = false;
  if (iVar1 != 0) {
    bVar3 = (*(uint *)(param_1 + 0x86990) & 1 << (param_2 + 0x10U & 0x1f)) != 0;
  }
  return bVar3;
}


