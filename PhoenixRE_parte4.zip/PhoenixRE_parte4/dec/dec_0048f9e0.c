// FUN_0048f9e0 @ 0048f9e0 size=10
// callers: 
// callees: 0048f950:FUN_0048f950 

void FUN_0048f9e0(undefined8 param_1)

{
  FUN_0048f950(param_1,0x40);
  return;
}


