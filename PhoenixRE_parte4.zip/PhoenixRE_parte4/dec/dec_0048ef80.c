// FUN_0048ef80 @ 0048ef80 size=129
// callers: 0048f690 004910c0 0048f540 00490360 00490890 0048f010 
// callees: 0047b7c0:FUN_0047b7c0 0047b8e0:FUN_0047b8e0 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0048ef80(longlong param_1,uint param_2,uint param_3)

{
  uint *puVar1;
  char cVar2;
  
  cVar2 = '\0';
  if (*(char *)(param_1 + 0x86680) != '\0') {
    FUN_0047b7c0(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x8667c));
    cVar2 = *(char *)(param_1 + 0x86680);
  }
  param_2 = param_2 | *(uint *)(param_1 + 0x866cc);
  puVar1 = (uint *)(param_1 + 0x866ec);
  *puVar1 = *puVar1 | param_3;
  *(uint *)(param_1 + 0x866cc) = param_2;
  if (*puVar1 != 0) {
    *(uint *)(param_1 + 0x866cc) = param_2 | 0x80000000;
  }
  if (cVar2 == '\0') {
    return;
  }
  FUN_0047b8e0(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x8667c));
  return;
}


