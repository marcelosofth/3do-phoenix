// FUN_0045f8c0 @ 0045f8c0 size=22
// callers: 0048f170 
// callees: 

undefined2 FUN_0045f8c0(longlong param_1,ushort param_2)

{
  undefined2 uVar1;
  
  uVar1 = 0;
  if (0x2ff < param_2) {
    uVar1 = *(undefined2 *)(param_1 + 0x11b94 + (ulonglong)(byte)param_2 * 2);
  }
  return uVar1;
}


