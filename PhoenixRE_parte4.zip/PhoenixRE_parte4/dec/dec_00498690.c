// FUN_00498690 @ 00498690 size=7
// callers: 0048f9f0 0048f690 
// callees: 

void FUN_00498690(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x460) = param_2;
  return;
}


