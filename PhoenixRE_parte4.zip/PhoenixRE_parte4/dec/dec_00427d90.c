// FUN_00427d90 @ 00427d90 size=202
// callers: 0048f9f0 
// callees: 0047ac00:FUN_0047ac00 0047ac10:FUN_0047ac10 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00427d90(longlong param_1,char param_2)

{
  char cVar1;
  
  if (*(char *)(param_1 + 0x28) != '\0') {
    *(undefined1 *)(param_1 + 0x34) = 1;
    while( true ) {
      cVar1 = FUN_0047ac10();
      if (cVar1 != '\0') break;
      FUN_0047ac00(_DAT_00cf4050,0);
    }
    *(undefined1 *)(param_1 + 0x34) = 0;
  }
  if (param_2 == '\0') {
    *(undefined2 *)(param_1 + 0x11da0) = 0x237;
  }
  else {
    *(short *)(param_1 + 0x11da0) = *(short *)(param_1 + 0x11d72) + -1;
  }
  *(uint *)(param_1 + 0x11dbc) = *(uint *)(param_1 + 0x11dbc) | 4;
  *(undefined2 *)(param_1 + 0x11d96) = 0;
  *(undefined2 *)(param_1 + 0x11d98) = 0;
  *(undefined2 *)(param_1 + 0x11da4) = 0;
  *(undefined1 *)(param_1 + 0x11da2) = 0;
  *(undefined4 *)(param_1 + 0x11dc0) = 0;
  *(undefined1 *)(param_1 + 0x11db8) = 1;
  *(undefined2 *)(param_1 + 0x11d94) = 1;
  *(undefined2 *)(param_1 + 0x11dc4) = *(undefined2 *)(param_1 + 0x10894);
  return;
}


