// FUN @ 0047f9e0 size=1
// callees: []

undefined8
FUN_0047f9e0(longlong param_1,undefined2 param_2,int param_3,int param_4,undefined8 param_5,
            undefined8 param_6,undefined8 param_7,undefined8 param_8,undefined8 param_9,
            undefined8 param_10)

{
  int iVar1;
  int iVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  bool bVar6;
  bool bVar7;
  bool bVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  undefined8 uVar14;
  uint uVar15;
  int iVar16;
  int iVar17;
  int iVar18;
  int iVar19;
  uint uVar20;
  int iVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  uint uVar26;
  int iVar27;
  int iStack_d0;
  int iStack_cc;
  int iStack_c8;
  int iStack_c4;
  int iStack_c0;
  int aiStack_68 [4];
  int aiStack_58 [6];
  
  iVar10 = (int)param_5._2_2_;
  uVar23 = param_4 >> 0x10;
  iVar18 = (int)param_7._2_2_;
  param_3 = param_3 >> 0x10;
  uVar15 = (uint)param_6._2_2_;
  uVar26 = (uint)param_10._2_2_;
  iVar19 = (int)param_9._2_2_;
  uVar20 = (uint)param_8._2_2_;
  if (((param_3 == iVar10) && (iVar10 == iVar18)) && (iVar18 == iVar19)) {
code_r0x0047fdf8:
    uVar14 = 0;
  }
  else {
    iVar11 = *(int *)(param_1 + 0x1000350) + 1;
    uVar12 = *(int *)(param_1 + 0x1000354) + 1;
    if (*(int *)(param_1 + 0x10002a0) < 0) {
      if (((-1 < *(int *)(param_1 + 0x1000298)) || (-1 < param_3)) ||
         ((-1 < iVar10 || ((-1 < iVar18 || (-1 < iVar19)))))) goto code_r0x0047fa95;
    }
    else if ((*(int *)(param_1 + 0x10002a0) == 0) ||
            ((((*(int *)(param_1 + 0x1000298) < 1 || (param_3 < iVar11)) || (iVar10 < iVar11)) ||
             ((iVar18 < iVar11 || (iVar19 < iVar11)))))) {
code_r0x0047fa95:
      if (*(int *)(param_1 + 0x10002a4) < 0) {
        if (((-1 < *(int *)(param_1 + 0x100029c)) || (-1 < param_4)) ||
           ((param_6._2_2_ >> 7 == 0 || ((param_8._2_2_ >> 7 == 0 || (param_10._2_2_ >> 7 == 0))))))
        goto code_r0x0047fac0;
      }
      else if ((*(int *)(param_1 + 0x10002a4) == 0) ||
              ((((*(int *)(param_1 + 0x100029c) < 1 || ((int)uVar23 < (int)uVar12)) ||
                ((int)uVar15 < (int)uVar12)) ||
               (((int)uVar20 < (int)uVar12 || ((int)uVar26 < (int)uVar12)))))) {
code_r0x0047fac0:
        uVar25 = uVar26;
        if ((int)uVar20 <= (int)uVar26) {
          uVar25 = uVar20;
        }
        if ((int)uVar15 < (int)uVar25) {
          uVar25 = uVar15;
        }
        if ((int)uVar23 < (int)uVar25) {
          uVar25 = uVar23;
        }
        uVar24 = uVar26;
        if ((int)uVar26 <= (int)uVar20) {
          uVar24 = uVar20;
        }
        if ((int)uVar24 < (int)uVar15) {
          uVar24 = uVar15;
        }
        if ((int)uVar24 < (int)uVar23) {
          uVar24 = uVar23;
        }
        uVar22 = 0;
        if (-1 < (int)uVar25) {
          uVar22 = uVar25;
        }
        if ((int)uVar12 < (int)uVar24) {
          uVar24 = uVar12;
        }
        if ((int)uVar22 < (int)uVar24) {
          iStack_c0 = (iVar19 - param_3) * (uVar22 - uVar23);
          iStack_cc = (param_3 - iVar19) * (uVar22 - uVar26);
          iStack_c4 = (uVar22 - uVar26) * (iVar18 - iVar19);
          iVar27 = (iVar19 - iVar18) * (uVar22 - uVar20);
          iStack_c8 = (uVar22 - uVar20) * (iVar10 - iVar18);
          iVar17 = (iVar18 - iVar10) * (uVar22 - uVar15);
          iStack_d0 = (uVar22 - uVar15) * (param_3 - iVar10);
          iVar21 = (uVar22 - uVar23) * (iVar10 - param_3);
          bVar3 = (int)uVar22 < (int)uVar15;
          bVar6 = (int)uVar23 <= (int)uVar22;
          if ((int)uVar22 < (int)uVar23) goto code_r0x0047fe7c;
code_r0x0047fc30:
          if (!bVar3) goto code_r0x0047fe7c;
          uVar12 = 1;
          aiStack_58[0] = 1;
          aiStack_68[0] = iVar21 / (int)(uVar15 - uVar23) + param_3;
          bVar4 = (int)uVar22 < (int)uVar20;
code_r0x0047fc5f:
          bVar3 = (bool)(bVar3 & (int)uVar20 <= (int)uVar22);
          uVar25 = uVar12;
          if (bVar3) {
            uVar25 = uVar12 + 1;
            aiStack_58[(int)uVar12] = 0;
            aiStack_68[(int)uVar12] = iStack_c8 / (int)(uVar15 - uVar20) + iVar18;
          }
          bVar5 = (int)uVar22 < (int)uVar26;
          if (!bVar3 && (int)uVar20 > (int)uVar22) goto code_r0x0047fef0;
          if (!bVar5) goto code_r0x0047fef0;
          aiStack_58[(int)uVar25] = 1;
          aiStack_68[(int)uVar25] = iVar27 / (int)(uVar26 - uVar20) + iVar18;
          uVar12 = uVar25 + 1;
          do {
            if ((uVar12 & 1) == 0) {
              if (uVar12 != 0) goto code_r0x0047fd0a;
            }
            else {
              if (((int)uVar22 < (int)uVar26) || ((int)uVar23 <= (int)uVar22)) {
                if ((bVar5) && (bVar6)) {
                  aiStack_58[(int)uVar12] = 0;
                  aiStack_68[(int)uVar12] = iStack_c0 / (int)(uVar26 - uVar23) + param_3;
                }
              }
              else {
                aiStack_58[(int)uVar12] = 1;
                aiStack_68[(int)uVar12] = iStack_cc / (int)(uVar23 - uVar26) + iVar19;
              }
code_r0x0047fd0a:
              iVar9 = aiStack_58[3];
              iVar2 = aiStack_58[2];
              iVar1 = aiStack_58[0];
              iVar16 = aiStack_68[2];
              iVar13 = aiStack_68[0];
              if (aiStack_68[1] < aiStack_68[0]) {
                aiStack_68[0] = aiStack_68[1];
                aiStack_68[1] = iVar13;
                aiStack_58[0] = aiStack_58[1];
                aiStack_58[1] = iVar1;
              }
              iVar1 = aiStack_58[0];
              iVar13 = aiStack_68[0];
              if (uVar12 == 3) {
                if (aiStack_68[2] < aiStack_68[1]) {
                  aiStack_68[2] = aiStack_68[1];
                  aiStack_68[1] = iVar16;
                  aiStack_58[2] = aiStack_58[1];
                  aiStack_58[1] = iVar2;
                  if (iVar16 < aiStack_68[0]) {
                    aiStack_68[0] = iVar16;
                    aiStack_68[1] = iVar13;
                    aiStack_58[0] = iVar2;
                    aiStack_58[1] = iVar1;
                  }
                }
                iVar13 = aiStack_68[2];
                iVar16 = aiStack_68[3];
                if (aiStack_68[3] < aiStack_68[2]) {
                  iVar1 = aiStack_58[3];
                  aiStack_68[2] = aiStack_68[3];
                  aiStack_58[3] = aiStack_58[2];
                  iVar2 = aiStack_68[1];
                  aiStack_58[2] = iVar9;
                  iVar16 = iVar13;
                  if (aiStack_68[3] < aiStack_68[1]) {
                    aiStack_68[2] = aiStack_68[1];
                    aiStack_58[2] = aiStack_58[1];
                    aiStack_68[1] = aiStack_68[3];
                    aiStack_58[1] = iVar1;
                    if (aiStack_68[3] < aiStack_68[0]) {
                      aiStack_68[1] = aiStack_68[0];
                      aiStack_58[1] = aiStack_58[0];
                      aiStack_68[0] = aiStack_68[3];
                      aiStack_58[0] = iVar1;
                    }
                  }
                }
                aiStack_68[3] = iVar16;
                uVar12 = *(uint *)(param_1 + 0x100027c);
                uVar25 = uVar12 & 0x40000;
                if (((uVar25 != 0) && (aiStack_58[2] == 0)) ||
                   (((uVar12 & 0x20000) != 0 && (aiStack_58[2] == 1)))) {
                  iVar13 = 0;
                  if (-1 < aiStack_68[2]) {
                    iVar13 = aiStack_68[2];
                  }
                  iVar16 = aiStack_68[3];
                  if (iVar11 <= aiStack_68[3]) {
                    iVar16 = iVar11;
                  }
                  if (iVar13 < iVar16) {
                    do {
                      uVar25 = *(int *)(param_1 + 0x100035c) * ((int)uVar22 >> 1) + (uVar22 & 1) * 2
                               + *(int *)(param_1 + 0x1000348) + iVar13 * 4;
                      if (uVar25 < 0x300000) {
                        *(undefined2 *)
                         (*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar25 ^ 2)) = param_2;
                        uVar12 = *(uint *)(param_1 + 0x100027c);
                      }
                      if ((uVar12 & 0x1000) != 0) goto code_r0x0047fdf8;
                      iVar13 = iVar13 + 1;
                    } while (iVar13 != iVar16);
                    uVar25 = uVar12 & 0x40000;
                  }
                }
              }
              else {
                uVar12 = *(uint *)(param_1 + 0x100027c);
                uVar25 = uVar12 & 0x40000;
              }
              if (((uVar25 != 0) && (aiStack_58[0] == 0)) ||
                 (((uVar12 & 0x20000) != 0 && (aiStack_58[0] == 1)))) {
                iVar13 = 0;
                if (-1 < aiStack_68[0]) {
                  iVar13 = aiStack_68[0];
                }
                iVar16 = aiStack_68[1];
                if (iVar11 <= aiStack_68[1]) {
                  iVar16 = iVar11;
                }
                if (iVar13 < iVar16) {
                  do {
                    uVar25 = *(int *)(param_1 + 0x100035c) * ((int)uVar22 >> 1) + (uVar22 & 1) * 2 +
                             *(int *)(param_1 + 0x1000348) + iVar13 * 4;
                    if (uVar25 < 0x300000) {
                      *(undefined2 *)(*(longlong *)(param_1 + 0x1000258) + (ulonglong)(uVar25 ^ 2))
                           = param_2;
                      uVar12 = *(uint *)(param_1 + 0x100027c);
                    }
                    if ((uVar12 & 0x1000) != 0) goto code_r0x0047fdf8;
                    iVar13 = iVar13 + 1;
                  } while (iVar13 != iVar16);
                }
              }
            }
            uVar22 = uVar22 + 1;
            iVar27 = iVar27 + (iVar19 - iVar18);
            iVar17 = iVar17 + (iVar18 - iVar10);
            iVar21 = iVar21 + (iVar10 - param_3);
            iStack_c0 = iStack_c0 + (iVar19 - param_3);
            iStack_cc = iStack_cc + (param_3 - iVar19);
            iStack_c4 = iStack_c4 + (iVar18 - iVar19);
            iStack_c8 = iStack_c8 + (iVar10 - iVar18);
            iStack_d0 = iStack_d0 + (param_3 - iVar10);
            if (uVar22 == uVar24) break;
            bVar3 = (int)uVar22 < (int)uVar15;
            bVar6 = (int)uVar23 <= (int)uVar22;
            if ((int)uVar23 <= (int)uVar22) goto code_r0x0047fc30;
code_r0x0047fe7c:
            bVar7 = (int)uVar15 <= (int)uVar22;
            bVar5 = (int)uVar22 < (int)uVar23;
            bVar8 = bVar7;
            if (bVar5 && bVar7) {
              aiStack_58[0] = 0;
              aiStack_68[0] = iStack_d0 / (int)(uVar23 - uVar15) + iVar10;
              bVar8 = bVar5 && bVar7;
            }
            uVar12 = (uint)(bVar5 && bVar7);
            bVar4 = (int)uVar22 < (int)uVar20;
            if ((!bVar8) || (!bVar4)) goto code_r0x0047fc5f;
            uVar12 = (uint)(bVar5 && bVar7);
            uVar25 = uVar12 + 1;
            aiStack_58[(int)uVar12] = 1;
            aiStack_68[(int)uVar12] = iVar17 / (int)(uVar20 - uVar15) + iVar10;
            bVar5 = (int)uVar22 < (int)uVar26;
code_r0x0047fef0:
            uVar12 = uVar25;
            if (((int)uVar26 <= (int)uVar22) && (bVar4)) {
              uVar12 = uVar25 + 1;
              aiStack_58[(int)uVar25] = 0;
              aiStack_68[(int)uVar25] = iStack_c4 / (int)(uVar20 - uVar26) + iVar19;
            }
          } while( true );
        }
        goto code_r0x0047fdf8;
      }
    }
    uVar14 = 0xffffffff;
  }
  return uVar14;
}


