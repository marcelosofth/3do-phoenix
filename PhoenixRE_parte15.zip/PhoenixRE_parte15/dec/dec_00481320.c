// FUN @ 00481320 size=1
// callees: []

void FUN_00481320(longlong param_1,uint *param_2)

{
  longlong *plVar1;
  byte bVar2;
  uint uVar3;
  uint *puVar4;
  uint *puVar5;
  longlong lVar6;
  int iVar7;
  undefined1 uVar8;
  uint *puVar9;
  uint *puVar10;
  undefined1 auStack_158 [32];
  uint uStack_138;
  uint uStack_130;
  longlong *plStack_120;
  ulonglong uStack_118;
  uint *puStack_110;
  uint uStack_104;
  undefined1 *puStack_100;
  uint *puStack_f8;
  longlong lStack_f0;
  int iStack_e8;
  uint uStack_e4;
  uint *puStack_e0;
  bool bStack_d5;
  int iStack_d4;
  longlong lStack_d0;
  undefined1 auStack_c8 [8];
  undefined4 uStack_c0;
  undefined *puStack_98;
  undefined *puStack_90;
  undefined1 *puStack_88;
  undefined *puStack_80;
  undefined1 *puStack_78;
  longlong lStack_60;
  longlong alStack_58 [2];
  undefined1 auStack_48 [8];
  
  puStack_78 = auStack_158;
  puStack_100 = auStack_c8;
  puStack_98 = &DAT_008ce270;
  puStack_90 = &UNK_00cc1530;
  puStack_88 = auStack_48;
  puStack_80 = &UNK_00481b1b;
  puStack_110 = param_2;
  lStack_f0 = param_1;
  func_0x008ce548(puStack_100);
  plVar1 = plRam0000000000cf4050;
  puStack_f8 = (uint *)CONCAT71(puStack_f8._1_7_,*(char *)((longlong)puStack_110 + 0x65));
  if (*(char *)((longlong)puStack_110 + 0x65) != '\0') goto code_r0x004813a8;
  uRam0000000000cfd490 = 0;
  iRam0000000000cfd498 = iRam0000000000cfd498 + 1;
  uRam0000000000cfd494 = 0;
  puStack_110[0x1c] = 1;
  puStack_e0 = *(uint **)(puStack_110 + 0x1e);
  uStack_118 = CONCAT44(uStack_118._4_4_,puStack_110[0x17]);
  plStack_120 = (longlong *)CONCAT44(plStack_120._4_4_,puStack_110[0x18]);
  alStack_58[0] = 0xcfd490;
  uStack_c0 = 1;
  uStack_104 = (**(code **)(*plVar1 + 0x90))();
  if (uStack_104 != 1) {
    iStack_e8 = (int)uStack_118 * uStack_104;
    if (iStack_e8 < 0x801) {
      uStack_e4 = (uint)plStack_120 * uStack_104;
      if ((int)uStack_e4 < 0x801) {
        plStack_120 = alStack_58;
        puStack_110[0x1c] = uStack_104;
        FUN_008fffc0(plStack_120,iStack_e8 * uStack_e4 * 4);
        FUN_008ffee0(plStack_120);
        puStack_e0 = (uint *)(alStack_58[0] + 0xc);
        uStack_118 = *(ulonglong *)(puStack_110 + 0x1e);
        uStack_130 = uStack_104;
        uStack_138 = puStack_110[0x18];
        plStack_120._0_4_ = puStack_110[0x17];
        (**(code **)(*plRam0000000000cf4050 + 0x98))
                  (plRam0000000000cf4050,puStack_e0,uStack_118,puStack_110[0x17]);
        plStack_120 = (longlong *)CONCAT44(plStack_120._4_4_,uStack_e4);
        uStack_118 = CONCAT44(uStack_118._4_4_,iStack_e8);
      }
    }
  }
  FUN_0047c610(uStack_118 & 0xffffffff,(ulonglong)plStack_120 & 0xffffffff,puStack_e0);
  uStack_e4 = (int)uStack_118 - 1;
  if (uStack_e4 == 0) {
    bStack_d5 = false;
    uStack_104 = 2;
  }
  else {
    bVar2 = FUN_0047c2d0(uStack_e4);
    uStack_104 = 1 << (bVar2 & 0x1f);
    bStack_d5 = 0x800 < (int)uStack_104;
  }
  iStack_e8 = 2;
  iStack_d4 = (uint)plStack_120 + -1;
  if (iStack_d4 != 0) {
    bVar2 = FUN_0047c2d0(iStack_d4);
    iStack_e8 = 1 << (bVar2 & 0x1f);
    puStack_f8 = (uint *)CONCAT71(puStack_f8._1_7_,0x800 < iStack_e8);
  }
  bStack_d5 = (bool)((byte)puStack_f8 | bStack_d5);
  if (bStack_d5 == false) {
    puStack_f8 = (uint *)(lStack_f0 + 0x78);
  }
  else {
    uStack_c0 = 1;
    lVar6 = -1;
    if ((ulonglong)(longlong)(int)(uStack_104 * iStack_e8) < 0x1fc0000000000001) {
      lVar6 = (longlong)(int)(uStack_104 * iStack_e8) * 4;
    }
    puStack_f8 = (uint *)func_0x008ce290(lVar6);
  }
  if ((int)(uint)plStack_120 < 1) {
    lStack_f0 = (ulonglong)lStack_f0._1_7_ << 8;
    if ((int)uStack_104 <= (int)uStack_118) goto code_r0x00481ae7;
code_r0x00481698:
    if ((int)(uint)plStack_120 < iStack_e8) {
      puStack_f8[(int)((uint)plStack_120 * uStack_104 + (int)uStack_118)] =
           puStack_f8
           [(longlong)(int)(((uint)plStack_120 * uStack_104 - uStack_104) + (int)uStack_118) + -1];
code_r0x004816ce:
      if (0 < (int)uStack_118) {
        lVar6 = (longlong)(int)((uint)plStack_120 * uStack_104 - uStack_104);
        puVar4 = puStack_f8 + lVar6;
        do {
          puVar4[(int)((uint)plStack_120 * uStack_104) - lVar6] = *puVar4;
          puVar4 = puVar4 + 1;
        } while (puVar4 != puStack_f8 + (ulonglong)uStack_e4 + lVar6 + 1);
        if ((int)((uint)plStack_120 + 1) < iStack_e8) {
          lVar6 = (longlong)(int)(iStack_d4 * uStack_104);
          puVar4 = puStack_f8 + lVar6;
          do {
            puVar4[(int)(iStack_d4 * uStack_104 + uStack_104 * 2) - lVar6] = *puVar4;
            puVar4 = puVar4 + 1;
          } while (puVar4 != puStack_f8 + (ulonglong)uStack_e4 + lVar6 + 1);
        }
      }
    }
  }
  else {
    lStack_d0 = (longlong)(int)uStack_104;
    uVar8 = 0;
    iVar7 = 0;
    lStack_60 = (longlong)(int)uStack_118;
    puVar4 = puStack_f8;
    puVar10 = puStack_e0;
    do {
      if (0 < (int)uStack_118) {
        puVar5 = puVar10;
        puVar9 = puVar4;
        do {
          uVar3 = *puVar5;
          if (((*puStack_e0 ^ uVar3) & 0x8000) != 0) {
            uVar8 = 1;
          }
          uVar3 = (uVar3 & 0x3e0) << 6 | (uVar3 & 0x1f) << 0x13 | (uVar3 & 0xffff) >> 7 & 0xf8;
          *puVar9 = uVar3;
          if (-1 < (int)*puVar5) {
            *puVar9 = uVar3 | 0xff000000;
          }
          puVar5 = puVar5 + 1;
          puVar9 = puVar9 + 1;
        } while (puVar5 != puVar10 + (ulonglong)uStack_e4 + 1);
      }
      iVar7 = iVar7 + 1;
      puVar10 = puVar10 + lStack_60;
      puVar4 = puVar4 + lStack_d0;
    } while (iVar7 != (uint)plStack_120);
    lStack_f0 = CONCAT71(lStack_f0._1_7_,uVar8);
    if ((int)uStack_118 < (int)uStack_104) {
      iVar7 = 0;
      puVar4 = puStack_f8 + lStack_60 + -1;
      do {
        puVar4[1] = *puVar4;
        if ((int)uStack_118 + 1 < (int)uStack_104) {
          puVar4[2] = *puVar4;
        }
        iVar7 = iVar7 + 1;
        puVar4 = puVar4 + lStack_d0;
      } while (iVar7 != (uint)plStack_120);
      goto code_r0x00481698;
    }
code_r0x00481ae7:
    if ((int)(uint)plStack_120 < iStack_e8) goto code_r0x004816ce;
  }
  uStack_c0 = 1;
  uVar3 = (**(code **)(*plRam0000000000cf4050 + 0x60))
                    (plRam0000000000cf4050,uStack_104,iStack_e8,puStack_f8);
  puStack_110[0x1a] = uVar3;
  puStack_110[0x1b] = 0xffffffff;
  if (((4 < (*puStack_110 & 7)) && ((*puStack_110 & 0x10) == 0)) || ((char)lStack_f0 != '\0')) {
    if ((int)(uint)plStack_120 < 1) {
      if ((int)uStack_104 <= (int)uStack_118) goto code_r0x00481b08;
code_r0x004818c8:
      if ((int)(uint)plStack_120 < iStack_e8) {
        puStack_f8[(int)((uint)plStack_120 * uStack_104 + (int)uStack_118)] =
             puStack_f8
             [(longlong)(int)(((uint)plStack_120 * uStack_104 - uStack_104) + (int)uStack_118) + -1]
        ;
code_r0x004818fe:
        if (0 < (int)uStack_118) {
          lVar6 = (longlong)(int)((uint)plStack_120 * uStack_104 - uStack_104);
          puVar4 = puStack_f8 + lVar6;
          do {
            puVar4[(int)((uint)plStack_120 * uStack_104) - lVar6] = *puVar4;
            puVar4 = puVar4 + 1;
          } while (puVar4 != puStack_f8 + (ulonglong)uStack_e4 + lVar6 + 1);
          if ((int)((uint)plStack_120 + 1) < iStack_e8) {
            lVar6 = (longlong)(int)(iStack_d4 * uStack_104);
            puVar4 = puStack_f8 + lVar6;
            do {
              puVar4[(int)(iStack_d4 * uStack_104 + uStack_104 * 2) - lVar6] = *puVar4;
              puVar4 = puVar4 + 1;
            } while (puVar4 != puStack_f8 + (ulonglong)uStack_e4 + lVar6 + 1);
          }
        }
      }
    }
    else {
      iVar7 = 0;
      lStack_f0 = (longlong)(int)uStack_104;
      puVar4 = puStack_f8;
      puVar10 = puStack_e0;
      do {
        if (0 < (int)uStack_118) {
          puVar5 = puVar10;
          puVar9 = puVar4;
          do {
            uVar3 = *puVar5 >> 0x10;
            uVar3 = ((uVar3 & 0x1ff) >> 6) << 0x15 | (uVar3 & 7) << 5 | (uVar3 & 0x38) << 10;
            *puVar9 = uVar3;
            if ((*puVar5 & 0x8000) != 0) {
              *puVar9 = uVar3 | 0xff000000;
            }
            puVar5 = puVar5 + 1;
            puVar9 = puVar9 + 1;
          } while (puVar5 != puVar10 + (ulonglong)uStack_e4 + 1);
        }
        iVar7 = iVar7 + 1;
        puVar10 = puVar10 + (int)uStack_118;
        puVar4 = puVar4 + lStack_f0;
      } while (iVar7 != (uint)plStack_120);
      if ((int)uStack_118 < (int)uStack_104) {
        iVar7 = 0;
        puVar4 = puStack_f8 + (longlong)(int)uStack_118 + -1;
        do {
          puVar4[1] = *puVar4;
          if ((int)uStack_118 + 1 < (int)uStack_104) {
            puVar4[2] = *puVar4;
          }
          iVar7 = iVar7 + 1;
          puVar4 = puVar4 + lStack_f0;
        } while (iVar7 != (uint)plStack_120);
        goto code_r0x004818c8;
      }
code_r0x00481b08:
      if ((int)(uint)plStack_120 < iStack_e8) goto code_r0x004818fe;
    }
    uStack_c0 = 1;
    uVar3 = (**(code **)(*plRam0000000000cf4050 + 0x60))
                      (plRam0000000000cf4050,uStack_104,iStack_e8,puStack_f8);
    puStack_110[0x1b] = uVar3;
  }
  *(undefined1 *)((longlong)puStack_110 + 0x65) = 1;
  if ((bStack_d5 != false) && (puStack_f8 != (uint *)0x0)) {
    func_0x008ce278();
  }
  FUN_008fff90(alStack_58);
code_r0x004813a8:
  func_0x008ce550(puStack_100);
  return;
}


