// FUN @ 0047ed60 size=1
// callees: []

bool FUN_0047ed60(longlong param_1,int param_2)

{
  double dVar1;
  double dVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  bool bVar10;
  double dVar11;
  double dVar12;
  double dVar13;
  double dVar14;
  
  uVar8 = *(uint *)(param_1 + 0x100027c) & 0x60000;
  if (uVar8 == 0x60000) {
    bVar10 = false;
  }
  else {
    dVar1 = *(double *)(param_1 + 0x10002d8);
    dVar12 = *(double *)(param_1 + 0x10002d0);
    dVar2 = *(double *)(param_1 + 0x10002e0);
    dVar14 = *(double *)(param_1 + 0x10002c8);
    dVar3 = *(double *)(param_1 + 0x10002c0);
    dVar5 = (double)param_2;
    dVar4 = *(double *)(param_1 + 0x10002b8);
    dVar13 = dVar3 * dVar5 + dVar2;
    dVar11 = dVar5 * dVar4 + dVar1;
    uVar6 = 0x40000;
    if (((dVar1 + dVar14) * (dVar12 - dVar2) + dVar2 * dVar1) - dVar12 * dVar14 < 0.0) {
      uVar6 = 0x20000;
    }
    uVar7 = 0x40000;
    if (((dVar14 + dVar11) * (dVar12 - dVar13) + dVar11 * dVar13) - dVar12 * dVar14 < 0.0) {
      uVar7 = 0x20000;
    }
    bVar10 = false;
    if (uVar6 == uVar7) {
      uVar9 = 0x40000;
      dVar11 = (double)*(int *)(param_1 + 0x1000274);
      dVar12 = dVar3 * dVar11 + dVar12;
      dVar14 = dVar11 * dVar4 + dVar14;
      uVar7 = 0x40000;
      if (((dVar1 + dVar14) * (dVar12 - dVar2) + dVar2 * dVar1) - dVar12 * dVar14 < 0.0) {
        uVar7 = 0x20000;
      }
      if (uVar6 == uVar7) {
        dVar11 = (double)*(int *)(param_1 + 0x1000274);
        dVar2 = dVar3 * dVar11 * dVar5 + dVar2;
        dVar1 = dVar4 * dVar11 * dVar5 + dVar1;
        if (((dVar14 + dVar1) * (dVar12 - dVar2) + dVar1 * dVar2) - dVar12 * dVar14 < 0.0) {
          uVar9 = 0x20000;
        }
        if (uVar6 == uVar9) {
          bVar10 = uVar8 == uVar6;
        }
      }
    }
  }
  return bVar10;
}


