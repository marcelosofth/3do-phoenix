// FUN @ 0047ccf0 size=1
// callees: []

bool FUN_0047ccf0(longlong param_1)

{
  uint uVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  
  if ((*(uint *)(param_1 + 0x1000210) & 0x100) == 0) {
    uVar3 = *(uint *)(param_1 + 0x1000110);
    cVar2 = FUN_0047cc60(param_1,uVar3 >> 0x10);
    if (cVar2 == '\0') {
      return false;
    }
    uVar3 = uVar3 & 0xffff;
  }
  else if ((*(uint *)(param_1 + 0x1000210) & 0x80) == 0) {
    uVar3 = (uint)*(ushort *)(param_1 + 0x1000110);
  }
  else {
    uVar3 = (uint)*(ushort *)(param_1 + 0x1000112);
  }
  uVar1 = *(uint *)(param_1 + 0x1000100);
  uVar4 = (int)uVar3 >> 6;
  if (((uVar1 >> 0x1c & 3) == 3) && ((uVar1 & 0x1000000) != 0)) {
    if ((uVar3 & 0x8000) != 0) {
      return false;
    }
    if ((uVar4 & 3) == 2) {
      return false;
    }
  }
  if (((int)uVar1 < 0) && ((uVar1 & 0x1000000) != 0)) {
    if ((uVar3 & 0x8000) != 0) {
      return false;
    }
    if ((uVar4 & 3) == 2) {
      return false;
    }
  }
  else if ((uVar4 & 3) == 2) {
    return false;
  }
  return (uVar3 & 0x8000) == 0;
}


