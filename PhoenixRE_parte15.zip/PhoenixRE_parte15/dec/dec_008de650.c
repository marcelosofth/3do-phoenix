// FUN @ 008de650 size=1
// callees: []

int FUN_008de650(longlong param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  bool bVar3;
  longlong lVar4;
  int iVar5;
  longlong lVar6;
  int iVar7;
  
  if (param_2 < 1) {
    iVar5 = 0;
  }
  else {
    lVar6 = 8;
    iVar5 = 0;
    iVar7 = 1;
    do {
      piVar1 = (int *)(param_1 + -8 + lVar6);
      piVar2 = (int *)(param_1 + -4 + lVar6);
      lVar4 = 0;
      if (iVar7 + -1 != param_2 + -1) {
        lVar4 = lVar6;
      }
      lVar6 = lVar6 + 8;
      iVar5 = iVar5 + (*piVar1 + *(int *)(lVar4 + param_1)) *
                      (*piVar2 - ((int *)(lVar4 + param_1))[1]);
      bVar3 = iVar7 < param_2;
      iVar7 = iVar7 + 1;
    } while (bVar3);
    iVar5 = iVar5 / 2;
  }
  return iVar5;
}


