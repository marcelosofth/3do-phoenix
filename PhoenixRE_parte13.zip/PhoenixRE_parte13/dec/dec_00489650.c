// FUN_00489650 @ 00489650 size=608
// callers: 0048adb0 
// callees: 00488700:FUN_00488700 00704850:FUN_00704850 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00489650(longlong param_1,uint param_2,ulonglong param_3)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  byte bVar5;
  uint uVar6;
  
  uVar1 = 0;
  if (param_2 < 0xc0) {
    param_2 = param_2 >> 2;
    uVar6 = (uint)param_3;
    if (0x1f < param_2) {
      *(uint *)(param_1 + 0x10000f0 + (ulonglong)(param_2 * 2 - 0x20) * 4) =
           (uint)(param_3 >> 0x10) & 0xffff;
      *(uint *)(param_1 + 0x10000f0 + (ulonglong)(param_2 * 2 - 0x1f) * 4) = uVar6 & 0xffff;
      return 0;
    }
    switch((ulonglong)param_2) {
    case 0:
      uVar1 = 0;
      if (*(int *)(param_1 + 0x10000ec) == 0) {
        *(undefined4 *)(param_1 + 0x10000ec) = 0x10;
        (**(code **)(*_DAT_00cf4050 + 0xd0))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x10000c4));
        bVar5 = 0;
        if (*(char *)(param_1 + 0x10000e0) != '\0') {
          bVar5 = *(byte *)(param_1 + 0x40) ^ 1;
        }
        uVar1 = FUN_00488700(param_1,bVar5);
        (**(code **)(*_DAT_00cf4050 + 0xd8))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x10000c4));
      }
      break;
    case 1:
      FUN_00704850(param_1);
      if (((*(char *)(param_1 + 0x10000e0) != '\0') && (*(int *)(param_1 + 0x10000ec) != 0)) &&
         (*(char *)(param_1 + 0x40) == '\0')) {
        (**(code **)(*_DAT_00cf4050 + 0xd0))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x10000c4));
        FUN_00488700(param_1,0);
        (**(code **)(*_DAT_00cf4050 + 0xd8))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x10000c4));
      }
      *(undefined4 *)(param_1 + 0x10000ec) = 0;
      uVar1 = 0;
      break;
    case 2:
      uVar1 = 0;
      if (*(int *)(param_1 + 0x10000ec) == 0x30) {
        *(undefined4 *)(param_1 + 0x10000ec) = 0x10;
      }
      break;
    case 3:
      uVar1 = 0;
      if (*(int *)(param_1 + 0x10000ec) == 0x10) {
        *(undefined4 *)(param_1 + 0x10000ec) = 0x30;
        uVar1 = 0;
      }
      break;
    default:
      *(uint *)(param_1 + 0x10000f0 + (ulonglong)param_2 * 4) = uVar6;
      uVar1 = 0;
      break;
    case 0xc:
      *(uint *)(param_1 + 0x1000120) = uVar6;
      iVar3 = 0x20;
      if ((((param_3 & 1) == 0) && (iVar3 = 0x200, (param_3 & 2) == 0)) &&
         (iVar3 = 0x100, (param_3 & 4) == 0)) {
        iVar3 = (uVar6 & 8) << 7;
      }
      uVar2 = 0x40;
      if (((param_3 & 0x10) == 0) && (uVar2 = 0x80, (param_3 & 0x20) == 0)) {
        uVar2 = uVar6 * 8 & 0x400;
      }
      uVar6 = uVar6 >> 8;
      iVar4 = 0x20;
      *(uint *)(param_1 + 0x100021c) = (uVar2 + iVar3) * 4;
      if ((((uVar6 & 1) == 0) && (iVar4 = 0x200, (param_3 & 0x200) == 0)) &&
         (iVar4 = 0x100, (param_3 & 0x400) == 0)) {
        iVar4 = (uVar6 & 8) << 7;
      }
      uVar2 = 0x40;
      if (((param_3 & 0x1000) == 0) && (uVar2 = 0x80, (param_3 & 0x2000) == 0)) {
        uVar2 = uVar6 * 8 & 0x400;
      }
      *(uint *)(param_1 + 0x1000220) = (uVar2 + iVar4) * 4;
      uVar1 = 0;
    }
  }
  return uVar1;
}


