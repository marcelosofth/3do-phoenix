// FUN_00704850 @ 00704850 size=565
// callers: 004898c0 004895d0 00489550 00489650 008eacc0 004894c0 
// callees: 0047ac10:FUN_0047ac10 008ce290:operator.new[] 008db890:FUN_008db890 008ce278:operator.delete[] 0047ac00:FUN_0047ac00 008ce280:operator.delete 008ce288:operator.new 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_00704850(longlong *param_1)

{
  ulonglong *puVar1;
  uint uVar2;
  code *pcVar3;
  char cVar4;
  uint *puVar5;
  ulonglong *puVar6;
  int *piVar7;
  ulonglong uVar8;
  void *pvVar9;
  int iVar10;
  longlong lVar11;
  longlong lVar12;
  ulonglong uVar13;
  uint uStack_4c;
  
  while (cVar4 = FUN_0047ac10(_DAT_00cf4050), cVar4 == '\0') {
    FUN_0047ac00(_DAT_00cf4050,0);
  }
  puVar5 = (uint *)param_1[7];
  iVar10 = 0;
  if (puVar5 == (uint *)0x0) goto LAB_007049dd;
LAB_007048a0:
  if ((int)*puVar5 <= iVar10) {
LAB_007049f0:
    if ((puVar5 != (uint *)0x0) && (*puVar5 != 0)) {
      if ((int)puVar5[2] < 2) {
        *puVar5 = 0;
      }
      else {
        puVar5[2] = puVar5[2] - 1;
        param_1[7] = 0;
      }
    }
    return;
  }
  do {
    pcVar3 = *(code **)(*param_1 + 0x50);
    if ((puVar5 != (uint *)0x0) && (1 < (int)puVar5[2])) {
      uVar2 = *puVar5;
      uStack_4c = uVar2 + 1 + (uVar2 >> 1);
      if (uStack_4c < 0x20) {
        lVar12 = 0x1f;
        uVar13 = 0x20;
        puVar5 = operator_new(0x18);
        uVar8 = 0x508;
        uStack_4c = 0x20;
      }
      else {
        uVar13 = (ulonglong)(int)uStack_4c;
        puVar5 = operator_new(0x18);
        if (uVar13 < 0x330000000000001) {
          uVar8 = uVar13 * 0x28 + 8;
          lVar12 = uVar13 - 1;
        }
        else {
          lVar12 = uVar13 - 1;
          uVar8 = 0xffffffffffffffff;
        }
      }
      puVar6 = operator_new__(uVar8);
      lVar11 = 0;
      puVar1 = puVar6 + 1;
      *puVar6 = uVar13;
      puVar6 = puVar1;
      do {
        lVar11 = lVar11 + 1;
        *(undefined4 *)puVar6 = 0;
        *(undefined4 *)((longlong)puVar6 + 0x1c) = 0;
        *(undefined4 *)(puVar6 + 3) = 0;
        puVar6[2] = 0;
        *(undefined4 *)((longlong)puVar6 + 4) = 0;
        *(undefined4 *)(puVar6 + 1) = 0;
        puVar6[4] = 0;
        puVar6 = puVar6 + 5;
      } while (lVar11 != lVar12 + 1);
      *(ulonglong **)(puVar5 + 4) = puVar1;
      puVar5[2] = 1;
      *puVar5 = uVar2;
      puVar5[1] = uStack_4c;
      piVar7 = (int *)param_1[7];
      if (*piVar7 == 0) {
LAB_00704989:
        piVar7[2] = piVar7[2] + -1;
        pvVar9 = (void *)param_1[7];
        if (*(int *)((longlong)pvVar9 + 8) == 0) {
          if (*(longlong *)((longlong)pvVar9 + 0x10) != 0) {
            operator_delete__((void *)(*(longlong *)((longlong)pvVar9 + 0x10) + -8));
            pvVar9 = (void *)param_1[7];
          }
          operator_delete(pvVar9);
        }
      }
      else {
        FUN_008db890(puVar1,*(undefined8 *)(piVar7 + 4));
        piVar7 = (int *)param_1[7];
        if (piVar7 != (int *)0x0) goto LAB_00704989;
      }
      param_1[7] = (longlong)puVar5;
    }
    iVar10 = iVar10 + 1;
    (*pcVar3)(param_1);
    puVar5 = (uint *)param_1[7];
    if (puVar5 != (uint *)0x0) goto LAB_007048a0;
LAB_007049dd:
    if (-1 < iVar10) goto LAB_007049f0;
  } while( true );
}


