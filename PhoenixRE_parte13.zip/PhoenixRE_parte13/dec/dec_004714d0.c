// FUN_004714d0 @ 004714d0 size=13
// callers: 0049fea0 
// callees: 

undefined4 FUN_004714d0(longlong param_1,uint param_2)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x48);
  *(uint *)(param_1 + 0x48) = (param_2 & 0xfffffffc) << 7;
  return uVar1;
}


