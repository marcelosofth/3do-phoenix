// FUN_004714e0 @ 004714e0 size=447
// callers: 0049fda0 
// callees: 008d8950:memcpy 

void FUN_004714e0(longlong *param_1,uint param_2,uint param_3)

{
  uint *puVar1;
  longlong lVar2;
  code *pcVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  undefined1 auStack_28 [4];
  int iStack_24;
  int iStack_20;
  uint uStack_1c;
  
  uVar4 = param_2 & 0xffffe000;
  uStack_1c = param_3;
  if (uVar4 == 0x4000) {
    param_2 = param_2 & 0x7fc;
    auStack_28[0] = 1;
    iStack_24 = param_2 << 9;
    iStack_20 = *(int *)((longlong)param_1 + 0x44);
    (**(code **)(*param_1 + 0x78))(param_1,param_1,0x10101,auStack_28);
    iVar5 = 0;
    if (param_3 == 0xffffffff) {
      iVar5 = 0;
      do {
        uVar4 = iVar5 + param_2 * 0x80;
        iVar5 = iVar5 + 1;
        *(undefined4 *)(param_1[10] + (ulonglong)uVar4 * 4) =
             *(undefined4 *)((longlong)param_1 + 0x44);
      } while (iVar5 != 0x200);
    }
    else {
      do {
        uVar4 = iVar5 + param_2 * 0x80;
        iVar5 = iVar5 + 1;
        puVar1 = (uint *)(param_1[10] + (ulonglong)uVar4 * 4);
        *puVar1 = (*puVar1 ^ *(uint *)((longlong)param_1 + 0x44)) & param_3 ^
                  *(uint *)((longlong)param_1 + 0x44);
      } while (iVar5 != 0x200);
    }
    lVar2 = param_1[5];
  }
  else {
    if (uVar4 != 0) {
      if (uVar4 != 0x2000) {
        return;
      }
      *(uint *)((longlong)param_1 + 0x44) = param_3;
      return;
    }
    auStack_28[0] = 0;
    iStack_24 = (param_2 & 0x7fc) << 9;
    *(uint *)((longlong)param_1 + 0x4c) = (param_2 & 0x7fc) << 7;
    iStack_20 = (int)param_1[9] << 2;
    (**(code **)(*param_1 + 0x78))(param_1,param_1,0x10101);
    iVar5 = 0;
    if (param_3 == 0xffffffff) {
      memcpy((void *)(param_1[10] + (ulonglong)*(uint *)((longlong)param_1 + 0x4c) * 4),
             (void *)(param_1[10] + (ulonglong)*(uint *)(param_1 + 9) * 4),0x800);
    }
    else {
      do {
        iVar6 = iVar5 + 1;
        puVar1 = (uint *)(param_1[10] +
                         (ulonglong)(uint)(iVar5 + *(int *)((longlong)param_1 + 0x4c)) * 4);
        uVar4 = *(uint *)(param_1[10] + (ulonglong)(uint)(iVar5 + (int)param_1[9]) * 4);
        *puVar1 = (*puVar1 ^ uVar4) & param_3 ^ uVar4;
        iVar5 = iVar6;
      } while (iVar6 != 0x200);
    }
    lVar2 = param_1[5];
    param_2 = param_2 & 0x7ff;
  }
  if (lVar2 == 0) {
    return;
  }
  pcVar3 = (code *)param_1[6];
  if (((ulonglong)pcVar3 & 1) == 0) {
    (*pcVar3)();
  }
  else {
    (**(code **)(pcVar3 + *(longlong *)(lVar2 + param_1[7]) + -1))
              ((longlong *)(lVar2 + param_1[7]),param_2 >> 2);
  }
  return;
}


