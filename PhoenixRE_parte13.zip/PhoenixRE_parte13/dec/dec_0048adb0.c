// FUN_0048adb0 @ 0048adb0 size=1243
// callers: 0049fda0 
// callees: 00489650:FUN_00489650 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_0048adb0(longlong param_1,uint param_2,uint param_3)

{
  uint uVar1;
  longlong lVar2;
  undefined8 uVar3;
  code *pcVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  
  uVar1 = param_2 & 0x7fc;
  switch(uVar1) {
  case 0:
  case 4:
  case 8:
  case 0xc:
  case 0x10:
  case 0x14:
  case 0x18:
  case 0x1c:
  case 0x20:
  case 0x24:
  case 0x28:
  case 0x2c:
  case 0x30:
  case 0x34:
  case 0x38:
  case 0x3c:
  case 0x40:
  case 0x44:
  case 0x48:
  case 0x4c:
  case 0x50:
  case 0x54:
  case 0x58:
  case 0x5c:
  case 0x60:
  case 100:
  case 0x68:
  case 0x6c:
  case 0x70:
  case 0x74:
  case 0x78:
  case 0x7c:
  case 0x80:
  case 0x84:
  case 0x88:
  case 0x8c:
  case 0x90:
  case 0x94:
  case 0x98:
  case 0x9c:
  case 0xa0:
  case 0xa4:
  case 0xa8:
  case 0xac:
  case 0xb0:
  case 0xb4:
  case 0xb8:
  case 0xbc:
  case 0xc0:
  case 0xc4:
  case 200:
  case 0xcc:
  case 0xd0:
  case 0xd4:
  case 0xd8:
  case 0xdc:
  case 0xe0:
  case 0xe4:
  case 0xe8:
  case 0xec:
  case 0xf0:
  case 0xf4:
  case 0xf8:
  case 0xfc:
    if (uVar1 == 4) {
      *(undefined4 *)(param_1 + 0x10003a4) = 0x29;
      return 0;
    }
    if (uVar1 == 8) {
      *(uint *)(param_1 + 0x10003a8) = param_3;
      return 0;
    }
    if (uVar1 == 0) {
      (**(code **)(*_DAT_00cf4050 + 0xc0))(_DAT_00cf4050,(int)(char)param_3);
      return 0;
    }
    break;
  case 0x100:
  case 0x104:
  case 0x108:
  case 0x10c:
  case 0x110:
  case 0x114:
  case 0x118:
  case 0x11c:
  case 0x120:
  case 0x124:
  case 0x128:
  case 300:
  case 0x130:
  case 0x134:
  case 0x138:
  case 0x13c:
  case 0x140:
  case 0x144:
  case 0x148:
  case 0x14c:
  case 0x150:
  case 0x154:
  case 0x158:
  case 0x15c:
  case 0x160:
  case 0x164:
  case 0x168:
  case 0x16c:
  case 0x170:
  case 0x174:
  case 0x178:
  case 0x17c:
  case 0x180:
  case 0x184:
  case 0x188:
  case 0x18c:
  case 400:
  case 0x194:
  case 0x198:
  case 0x19c:
  case 0x1a0:
  case 0x1a4:
  case 0x1a8:
  case 0x1ac:
  case 0x1b0:
  case 0x1b4:
  case 0x1b8:
  case 0x1bc:
  case 0x1c0:
  case 0x1c4:
  case 0x1c8:
  case 0x1cc:
  case 0x1d0:
  case 0x1d4:
  case 0x1d8:
  case 0x1dc:
  case 0x1e0:
  case 0x1e4:
  case 0x1e8:
  case 0x1ec:
  case 0x1f0:
  case 500:
  case 0x1f8:
  case 0x1fc:
    uVar3 = FUN_00489650(param_1 + 0x38,uVar1 - 0x100);
    return uVar3;
  case 0x400:
  case 0x404:
  case 0x408:
  case 0x40c:
  case 0x410:
  case 0x414:
  case 0x418:
  case 0x41c:
  case 0x420:
  case 0x424:
  case 0x428:
  case 0x42c:
  case 0x430:
  case 0x434:
  case 0x438:
  case 0x43c:
  case 0x440:
  case 0x444:
  case 0x448:
  case 0x44c:
  case 0x450:
  case 0x454:
  case 0x458:
  case 0x45c:
  case 0x460:
  case 0x464:
  case 0x468:
  case 0x46c:
  case 0x470:
  case 0x474:
  case 0x478:
  case 0x47c:
  case 0x480:
  case 0x484:
  case 0x488:
  case 0x48c:
  case 0x490:
  case 0x494:
  case 0x498:
  case 0x49c:
  case 0x4a0:
  case 0x4a4:
  case 0x4a8:
  case 0x4ac:
  case 0x4b0:
  case 0x4b4:
  case 0x4b8:
  case 0x4bc:
  case 0x4c0:
  case 0x4c4:
  case 0x4c8:
  case 0x4cc:
  case 0x4d0:
  case 0x4d4:
  case 0x4d8:
  case 0x4dc:
  case 0x4e0:
  case 0x4e4:
  case 0x4e8:
  case 0x4ec:
  case 0x4f0:
  case 0x4f4:
  case 0x4f8:
  case 0x4fc:
  case 0x500:
  case 0x504:
  case 0x508:
  case 0x50c:
  case 0x510:
  case 0x514:
  case 0x518:
  case 0x51c:
  case 0x520:
  case 0x524:
  case 0x528:
  case 0x52c:
  case 0x530:
  case 0x534:
  case 0x538:
  case 0x53c:
  case 0x540:
  case 0x544:
  case 0x548:
  case 0x54c:
  case 0x550:
  case 0x554:
  case 0x558:
  case 0x55c:
  case 0x560:
  case 0x564:
  case 0x568:
  case 0x56c:
  case 0x570:
  case 0x574:
  case 0x578:
  case 0x57c:
  case 0x580:
  case 0x584:
  case 0x588:
  case 0x58c:
  case 0x590:
  case 0x594:
  case 0x598:
  case 0x59c:
  case 0x5a0:
  case 0x5a4:
  case 0x5a8:
  case 0x5ac:
  case 0x5b0:
  case 0x5b4:
  case 0x5b8:
  case 0x5bc:
  case 0x5c0:
  case 0x5c4:
  case 0x5c8:
  case 0x5cc:
  case 0x5d0:
  case 0x5d4:
  case 0x5d8:
  case 0x5dc:
  case 0x5e0:
  case 0x5e4:
  case 0x5e8:
  case 0x5ec:
  case 0x5f0:
  case 0x5f4:
  case 0x5f8:
  case 0x5fc:
    param_3 = param_3 & 0xfffffc;
    if (uVar1 - 0x400 < 0x140) {
      if ((param_2 & 0xc) < 8) {
        *(undefined4 *)(param_1 + 0x10003a0 + (ulonglong)(uVar1 + 8 >> 2) * 4) = 0;
      }
    }
    else {
      if (uVar1 - 0x5a0 < 0x20) {
        *(uint *)(param_1 + 0x1000228 + (ulonglong)(uVar1 - 0x5a0 >> 2) * 4) = param_3;
        return 0;
      }
      if (uVar1 == 0x580) {
        if (*(longlong *)(param_1 + 0x1000bb8) == 0) {
          return 0;
        }
        pcVar4 = *(code **)(param_1 + 0x1000bc0);
        plVar5 = (longlong *)
                 (*(longlong *)(param_1 + 0x1000bb8) + *(longlong *)(param_1 + 0x1000bc8));
        if (((ulonglong)pcVar4 & 1) != 0) {
          pcVar4 = *(code **)(pcVar4 + *plVar5 + -1);
        }
        (*pcVar4)(plVar5,param_3);
        return 0;
      }
    }
    break;
  case 0x600:
  case 0x604:
  case 0x608:
  case 0x60c:
  case 0x610:
  case 0x614:
  case 0x618:
  case 0x61c:
  case 0x620:
  case 0x624:
  case 0x628:
  case 0x62c:
  case 0x630:
  case 0x634:
  case 0x638:
  case 0x63c:
  case 0x640:
  case 0x644:
  case 0x648:
  case 0x64c:
  case 0x650:
  case 0x654:
  case 0x658:
  case 0x65c:
  case 0x660:
  case 0x664:
  case 0x668:
  case 0x66c:
  case 0x670:
  case 0x674:
  case 0x678:
  case 0x67c:
  case 0x680:
  case 0x684:
  case 0x688:
  case 0x68c:
  case 0x690:
  case 0x694:
  case 0x698:
  case 0x69c:
  case 0x6a0:
  case 0x6a4:
  case 0x6a8:
  case 0x6ac:
  case 0x6b0:
  case 0x6b4:
  case 0x6b8:
  case 0x6bc:
  case 0x6c0:
  case 0x6c4:
  case 0x6c8:
  case 0x6cc:
  case 0x6d0:
  case 0x6d4:
  case 0x6d8:
  case 0x6dc:
  case 0x6e0:
  case 0x6e4:
  case 0x6e8:
  case 0x6ec:
  case 0x6f0:
  case 0x6f4:
  case 0x6f8:
  case 0x6fc:
  case 0x700:
  case 0x704:
  case 0x708:
  case 0x70c:
  case 0x710:
  case 0x714:
  case 0x718:
  case 0x71c:
  case 0x720:
  case 0x724:
  case 0x728:
  case 0x72c:
  case 0x730:
  case 0x734:
  case 0x738:
  case 0x73c:
  case 0x740:
  case 0x744:
  case 0x748:
  case 0x74c:
  case 0x750:
  case 0x754:
  case 0x758:
  case 0x75c:
  case 0x760:
  case 0x764:
  case 0x768:
  case 0x76c:
  case 0x770:
  case 0x774:
  case 0x778:
  case 0x77c:
  case 0x780:
  case 0x784:
  case 0x788:
  case 0x78c:
  case 0x790:
  case 0x794:
  case 0x798:
  case 0x79c:
  case 0x7a0:
  case 0x7a4:
  case 0x7a8:
  case 0x7ac:
  case 0x7b0:
  case 0x7b4:
  case 0x7b8:
  case 0x7bc:
  case 0x7c0:
  case 0x7c4:
  case 0x7c8:
  case 0x7cc:
  case 2000:
  case 0x7d4:
  case 0x7d8:
  case 0x7dc:
  case 0x7e0:
  case 0x7e4:
  case 0x7e8:
  case 0x7ec:
  case 0x7f0:
  case 0x7f4:
  case 0x7f8:
  case 0x7fc:
    if (uVar1 == 0x7fc) {
      *(undefined4 *)(param_1 + 0x1000b9c) = 0;
      if (param_3 == 1) {
        lVar8 = (longlong)*(int *)(param_1 + 0x10009e0);
        lVar7 = (longlong)*(int *)(param_1 + 0x10009e4);
        lVar6 = (longlong)*(int *)(param_1 + 0x10009e8);
        *(undefined4 *)(param_1 + 0x1000a00) = _DAT_00cf406c;
        *(undefined4 *)(param_1 + 0x1000a04) = _DAT_00cf4068;
        *(int *)(param_1 + 0x1000a08) = _DAT_00cf4064;
        *(undefined4 *)(param_1 + 0x1000a0c) = _DAT_00cf4060;
        lVar2 = (longlong)*(int *)(param_1 + 0x10009ec);
        _DAT_00cf4060 =
             (int)((ulonglong)
                   (lVar2 * *(int *)(param_1 + 0x10009dc) +
                   lVar6 * *(int *)(param_1 + 0x10009d8) +
                   lVar7 * *(int *)(param_1 + 0x10009d4) + lVar8 * *(int *)(param_1 + 0x10009d0)) >>
                  0x10);
        _DAT_00cf4064 =
             (int)((ulonglong)
                   (*(int *)(param_1 + 0x10009cc) * lVar2 +
                   *(int *)(param_1 + 0x10009c0) * lVar8 + *(int *)(param_1 + 0x10009c4) * lVar7 +
                   *(int *)(param_1 + 0x10009c8) * lVar6) >> 0x10);
        _DAT_00cf4068 =
             (int)((ulonglong)
                   (*(int *)(param_1 + 0x10009bc) * lVar2 +
                   *(int *)(param_1 + 0x10009b0) * lVar8 + *(int *)(param_1 + 0x10009b4) * lVar7 +
                   *(int *)(param_1 + 0x10009b8) * lVar6) >> 0x10);
        _DAT_00cf406c =
             (int)((ulonglong)
                   (*(int *)(param_1 + 0x10009ac) * lVar2 +
                   *(int *)(param_1 + 0x10009a0) * lVar8 + *(int *)(param_1 + 0x10009a4) * lVar7 +
                   *(int *)(param_1 + 0x10009a8) * lVar6) >> 0x10);
        return 0;
      }
      if (param_3 == 0) {
        *(undefined4 *)(param_1 + 0x1000a00) = _DAT_00cf406c;
        *(undefined4 *)(param_1 + 0x1000a04) = _DAT_00cf4068;
        *(int *)(param_1 + 0x1000a08) = _DAT_00cf4064;
        *(undefined4 *)(param_1 + 0x1000a0c) = _DAT_00cf4060;
        return 0;
      }
      if (param_3 == 2) {
        lVar7 = (longlong)*(int *)(param_1 + 0x10009e0);
        *(undefined4 *)(param_1 + 0x1000a00) = _DAT_00cf406c;
        lVar6 = (longlong)*(int *)(param_1 + 0x10009e8);
        *(undefined4 *)(param_1 + 0x1000a04) = _DAT_00cf4068;
        *(int *)(param_1 + 0x1000a08) = _DAT_00cf4064;
        *(undefined4 *)(param_1 + 0x1000a0c) = _DAT_00cf4060;
        lVar2 = (longlong)*(int *)(param_1 + 0x10009e4);
        _DAT_00cf4064 =
             (int)((ulonglong)
                   (lVar2 * *(int *)(param_1 + 0x10009c4) + lVar7 * *(int *)(param_1 + 0x10009c0) +
                   lVar6 * *(int *)(param_1 + 0x10009c8)) >> 0x10);
        _DAT_00cf4068 =
             (int)((ulonglong)
                   (*(int *)(param_1 + 0x10009b8) * lVar6 +
                   *(int *)(param_1 + 0x10009b0) * lVar7 + *(int *)(param_1 + 0x10009b4) * lVar2) >>
                  0x10);
        _DAT_00cf406c =
             (int)((ulonglong)
                   (*(int *)(param_1 + 0x10009a8) * lVar6 +
                   *(int *)(param_1 + 0x10009a0) * lVar7 + *(int *)(param_1 + 0x10009a4) * lVar2) >>
                  0x10);
        return 0;
      }
      if (param_3 != 3) {
        return 0;
      }
      lVar8 = (longlong)*(int *)(param_1 + 0x10009e0);
      lVar7 = (longlong)*(int *)(param_1 + 0x10009e4);
      *(undefined4 *)(param_1 + 0x1000a00) = _DAT_00cf406c;
      lVar6 = (longlong)*(int *)(param_1 + 0x10009e8);
      *(undefined4 *)(param_1 + 0x1000a04) = _DAT_00cf4068;
      *(int *)(param_1 + 0x1000a08) = _DAT_00cf4064;
      *(undefined4 *)(param_1 + 0x1000a0c) = _DAT_00cf4060;
      _DAT_00cf4064 =
           (int)((ulonglong)
                 (*(int *)(param_1 + 0x10009c0) * lVar8 + *(int *)(param_1 + 0x10009c4) * lVar7 +
                 *(int *)(param_1 + 0x10009c8) * lVar6) >> 0x10);
      lVar2 = CONCAT44(*(undefined4 *)(param_1 + 0x1000a20),*(undefined4 *)(param_1 + 0x1000a24));
      if (_DAT_00cf4064 != 0) {
        lVar2 = lVar2 / (longlong)_DAT_00cf4064;
      }
      _DAT_00cf4068 =
           (int)((ulonglong)
                 ((int)((ulonglong)
                        (*(int *)(param_1 + 0x10009b8) * lVar6 +
                        *(int *)(param_1 + 0x10009b0) * lVar8 +
                        *(int *)(param_1 + 0x10009b4) * lVar7) >> 0x10) * lVar2) >> 0x20);
      _DAT_00cf406c =
           (int)((ulonglong)
                 ((int)((ulonglong)
                        (*(int *)(param_1 + 0x10009a0) * lVar8 +
                         lVar7 * *(int *)(param_1 + 0x10009a4) +
                        lVar6 * *(int *)(param_1 + 0x10009a8)) >> 0x10) * lVar2) >> 0x20);
      return 0;
    }
  }
  *(uint *)(param_1 + 0x10003a0 + (ulonglong)(uVar1 >> 2) * 4) = param_3;
  return 0;
}


