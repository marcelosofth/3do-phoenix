// FUN_0048b2a0 @ 0048b2a0 size=107
// callers: 0049fea0 
// callees: 0047c7c0:FUN_0047c7c0 

ulonglong FUN_0048b2a0(longlong param_1,uint param_2)

{
  uint uVar1;
  ulonglong uVar2;
  
  param_2 = param_2 & 0x7fc;
  uVar1 = param_2 >> 8;
  if (uVar1 == 1) {
    uVar2 = FUN_0047c7c0(param_1 + 0x38,param_2 - 0x100);
    return uVar2;
  }
  if (uVar1 == 0) {
    if (param_2 == 0x28) {
      return (ulonglong)*(uint *)(param_1 + 0x1000124);
    }
  }
  else if (uVar1 - 4 < 2) {
    if (param_2 - 0x5a0 < 0x20) {
      return (ulonglong)
             (*(uint *)(param_1 + 0x1000228 + (ulonglong)(param_2 - 0x5a0 >> 2) * 4) & 0xfffffc);
    }
    return (ulonglong)(*(uint *)(param_1 + 0x10003a0 + (ulonglong)(param_2 >> 2) * 4) & 0xfffffc);
  }
  return (ulonglong)*(uint *)(param_1 + 0x10003a0 + (ulonglong)(param_2 >> 2) * 4);
}


