// FUN_0058e9f0 @ 0058e9f0 size=524
// callers: 004a0530 0049fea0 004a0090 004a0130 
// callees: 008ce280:operator.delete 00550ae0:FUN_00550ae0 008ce288:operator.new 008ce290:operator.new[] 008ce278:operator.delete[] 0058db20:FUN_0058db20 

void FUN_0058e9f0(longlong param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  longlong lVar3;
  void *pvVar4;
  uint *puVar5;
  void *pvVar6;
  uint uVar7;
  ulonglong uVar8;
  int *piVar9;
  longlong lVar10;
  int iVar11;
  int iStack_58;
  uint uStack_54;
  int iStack_50;
  longlong lStack_48;
  
  lVar3 = *(longlong *)(param_1 + 0x159f568);
  param_2 = param_2 >> 2;
  iVar1 = *(int *)(*(longlong *)(lVar3 + 8) + (longlong)(int)param_2 * 4);
  if (iVar1 == 0) {
    return;
  }
  puVar5 = *(uint **)(lVar3 + 0x40);
  if ((puVar5 == (uint *)0x0) || ((int)puVar5[2] < 2)) goto LAB_0058eae4;
  uVar2 = *puVar5;
  uVar7 = uVar2 + 1 + (uVar2 >> 1);
  if (uVar7 < 0x20) {
    puVar5 = operator_new(0x18);
    uVar7 = 0x20;
    uVar8 = 0x100;
  }
  else {
    puVar5 = operator_new(0x18);
    uVar8 = 0xffffffffffffffff;
    if ((ulonglong)(longlong)(int)uVar7 < 0xfe0000000000001) {
      uVar8 = (longlong)(int)uVar7 * 8;
    }
  }
  pvVar6 = operator_new__(uVar8);
  puVar5[1] = uVar7;
  *(void **)(puVar5 + 4) = pvVar6;
  puVar5[2] = 1;
  *puVar5 = uVar2;
  piVar9 = *(int **)(lVar3 + 0x40);
  iVar11 = *piVar9;
  if (iVar11 == 0) {
LAB_0058eab2:
    piVar9[2] = piVar9[2] + -1;
    pvVar6 = *(void **)(lVar3 + 0x40);
    if (*(int *)((longlong)pvVar6 + 8) == 0) {
      if (*(void **)((longlong)pvVar6 + 0x10) != (void *)0x0) {
        operator_delete__(*(void **)((longlong)pvVar6 + 0x10));
        pvVar6 = *(void **)(lVar3 + 0x40);
      }
      operator_delete(pvVar6);
    }
  }
  else {
    pvVar4 = *(void **)(piVar9 + 4);
    if (pvVar6 < pvVar4) {
      if (0 < iVar11) {
        lVar10 = 0;
        do {
          *(undefined8 *)((longlong)pvVar6 + lVar10 * 8) =
               *(undefined8 *)((longlong)pvVar4 + lVar10 * 8);
          lVar10 = lVar10 + 1;
        } while ((int)lVar10 < iVar11);
        goto LAB_0058ebd2;
      }
      goto LAB_0058eab2;
    }
    if ((pvVar6 <= pvVar4) || (uVar7 = iVar11 - 1, (int)uVar7 < 0)) goto LAB_0058eab2;
    lVar10 = 0;
    do {
      *(undefined8 *)((longlong)pvVar6 + lVar10 + (longlong)(int)uVar7 * 8) =
           *(undefined8 *)((longlong)pvVar4 + lVar10 + (longlong)(int)uVar7 * 8);
      lVar10 = lVar10 + -8;
    } while (lVar10 != ~(ulonglong)uVar7 * 8);
LAB_0058ebd2:
    piVar9 = *(int **)(lVar3 + 0x40);
    if (piVar9 != (int *)0x0) goto LAB_0058eab2;
  }
  *(uint **)(lVar3 + 0x40) = puVar5;
LAB_0058eae4:
  piVar9 = *(int **)(*(longlong *)(*(longlong *)(puVar5 + 4) + (longlong)(iVar1 + -1) * 8) + 8);
  if (piVar9 != (int *)0x0) {
    iVar1 = *piVar9;
    iVar11 = 0;
    if (0 < iVar1) {
      do {
        FUN_00550ae0(&iStack_58,*(undefined8 *)(param_1 + 0x159f568),param_2,iVar11);
        if ((((iStack_58 == 0x10002) && (uStack_54 <= param_2)) && (param_2 < uStack_54 + iStack_50)
            ) && ((lVar3 = *(longlong *)(lStack_48 + 0x58), *(char *)(lVar3 + 0x24) == '\0' &&
                  (*(char *)(lVar3 + 0x1c) != '\0')))) {
          *(undefined1 *)(lVar3 + 0x24) = 1;
          FUN_0058db20(param_1);
        }
        iVar11 = iVar11 + 1;
      } while (iVar11 != iVar1);
    }
  }
  return;
}


