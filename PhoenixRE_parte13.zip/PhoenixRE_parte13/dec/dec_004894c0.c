// FUN_004894c0 @ 004894c0 size=124
// callers: 0049fda0 004a0920 
// callees: 00704850:FUN_00704850 00488700:FUN_00488700 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_004894c0(longlong param_1,int param_2)

{
  if (param_2 == 0) {
    FUN_00704850();
  }
  if ((((*(char *)(param_1 + 0x40) == '\0') && (*(char *)(param_1 + 0x10000e0) != '\0')) &&
      (*(int *)(param_1 + 0x10000ec) != 0)) && (param_2 == 0)) {
    (**(code **)(*_DAT_00cf4050 + 0xd0))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x10000c4));
    FUN_00488700(param_1,0);
    (**(code **)(*_DAT_00cf4050 + 0xd8))(_DAT_00cf4050,*(undefined4 *)(param_1 + 0x10000c4));
  }
  *(int *)(param_1 + 0x10000ec) = param_2;
  return;
}


