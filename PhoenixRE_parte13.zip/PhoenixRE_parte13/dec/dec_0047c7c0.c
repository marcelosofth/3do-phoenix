// FUN_0047c7c0 @ 0047c7c0 size=22
// callers: 0048b2a0 
// callees: 

undefined4 FUN_0047c7c0(longlong param_1,uint param_2)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if (param_2 < 0x100) {
    uVar1 = *(undefined4 *)(param_1 + 0x10000f0 + (ulonglong)(param_2 >> 2) * 4);
  }
  return uVar1;
}


