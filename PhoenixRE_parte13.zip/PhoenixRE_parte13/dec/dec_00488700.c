// FUN_00488700 @ 00488700 size=3503
// callers: 004894c0 00489650 00489550 004895d0 
// callees: 00482950:FUN_00482950 00943830:FUN_00943830 00480290:FUN_00480290 00703e20:FUN_00703e20 00943e90:FUN_00943e90 008d8950:memcpy 00487100:FUN_00487100 004860d0:FUN_004860d0 004859b0:FUN_004859b0 00704200:FUN_00704200 00948300:FUN_00948300 

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_00488700(longlong *param_1,char param_2)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  bool bVar5;
  double dVar6;
  double dVar7;
  int iVar8;
  code *pcVar9;
  longlong *plVar10;
  longlong lVar11;
  uint *puVar12;
  uint uVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  undefined4 uVar21;
  ulonglong uVar22;
  int iVar23;
  int iVar24;
  uint *puStack_1c8;
  int iStack_1a8;
  int iStack_1a4;
  undefined4 uStack_19c;
  undefined4 uStack_198;
  undefined4 uStack_194;
  undefined4 uStack_190;
  undefined4 uStack_18c;
  longlong lStack_188;
  longlong lStack_180;
  longlong lStack_178;
  longlong lStack_170;
  undefined1 auStack_168 [296];
  
  (**(code **)(*param_1 + 0x60))();
  if (param_2 != '\0') {
    memcpy(auStack_168,param_1 + 0x20001e,0x100);
    lStack_170 = param_1[0x200041];
    iStack_1a4 = 0;
    lStack_188 = param_1[0x20003e];
    iStack_1a8 = 0;
    puStack_1c8 = (uint *)0x0;
    uStack_19c = (undefined4)param_1[0x200042];
    lStack_180 = param_1[0x20003f];
    uStack_198 = *(undefined4 *)((longlong)param_1 + 0x1000214);
    lStack_178 = param_1[0x200040];
    uStack_194 = (undefined4)param_1[0x200043];
    uStack_190 = *(undefined4 *)((longlong)param_1 + 0x100021c);
    uStack_18c = (undefined4)param_1[0x200044];
    goto LAB_004887da;
  }
  piVar4 = (int *)param_1[6];
  if ((piVar4 != (int *)0x0) && (*piVar4 != 0)) {
    if (piVar4[2] < 2) {
      *piVar4 = 0;
    }
    else {
      piVar4[2] = piVar4[2] + -1;
      param_1[6] = 0;
    }
  }
  FUN_00948300(param_1 + 0x20006c,0);
  *(uint *)((longlong)param_1 + 0x1000354) =
       *(uint *)((longlong)param_1 + 0x1000124) >> 0x10 & 0x3ff;
  *(uint *)(param_1 + 0x20006a) = *(uint *)((longlong)param_1 + 0x1000124) & 0x3ff;
  *(undefined4 *)(param_1 + 0x200069) = *(undefined4 *)((longlong)param_1 + 0x100012c);
  *(int *)((longlong)param_1 + 0x100034c) = (int)param_1[0x200025];
  *(int *)((longlong)param_1 + 0x100035c) = (int)param_1[0x200044];
  *(undefined4 *)(param_1 + 0x20006b) = *(undefined4 *)((longlong)param_1 + 0x100021c);
  if (param_1[0x200014] != 0) {
    pcVar9 = (code *)param_1[0x200015];
    if (((ulonglong)pcVar9 & 1) != 0) {
      pcVar9 = *(code **)(pcVar9 + *(longlong *)(param_1[0x200014] + param_1[0x200016]) + -1);
    }
    (*pcVar9)();
  }
  FUN_00943e90(param_1 + 0xc,0);
  piVar4 = (int *)param_1[0xe];
  if ((piVar4 == (int *)0x0) || (*piVar4 == 0)) {
LAB_00489208:
    iVar8 = (int)param_1[0x200019];
  }
  else {
    if (1 < piVar4[2]) {
      piVar4[2] = piVar4[2] + -1;
      param_1[0xe] = 0;
      goto LAB_00489208;
    }
    *piVar4 = 0;
    iVar8 = (int)param_1[0x200019];
  }
  if (1 < iVar8) {
    if ((((0x1fffff < *(int *)((longlong)param_1 + 0x100012c) - 0x100000U) ||
         ((**(code **)(*param_1 + 0x68))
                    (param_1,param_1 + 0xe,*(int *)((longlong)param_1 + 0x100012c),0x10002,0),
         1 < (int)param_1[0x200019])) && ((int *)param_1[0xe] != (int *)0x0)) &&
       (*(int *)param_1[0xe] != 0)) {
      FUN_00943830(param_1 + 0xe);
      puStack_1c8 = *(uint **)(*(longlong *)(param_1[0xe] + 0x10) + 0x10);
      (**(code **)(*param_1 + 0x78))(param_1,param_1,0x10100,puStack_1c8);
      uVar13 = puStack_1c8[8];
      *(undefined1 *)(param_1 + 9) = 0;
      *(uint *)((longlong)param_1 + 0x4c) = uVar13;
      uVar13 = *puStack_1c8;
      uVar1 = puStack_1c8[1];
      iVar8 = *(uint *)((longlong)param_1 + 0x100012c) - uVar13;
      lVar11 = CONCAT44(iVar8 >> 0x1f,iVar8 >> 1);
      iStack_1a4 = (int)(lVar11 % (longlong)(int)(uVar1 * 2)) >> 1;
      *(int *)(param_1 + 10) = iStack_1a4;
      plVar10 = _DAT_00cf4050;
      iStack_1a8 = ((int)(lVar11 / (longlong)(int)(uVar1 * 2)) * 2 -
                   (uint)((*(uint *)((longlong)param_1 + 0x100012c) & 2) == 0)) +
                   (uint)((uVar13 & 2) == 0);
      *(int *)((longlong)param_1 + 0x5c) = *(int *)((longlong)param_1 + 0x1000354) + 1;
      *(int *)(param_1 + 0xb) = (int)param_1[0x20006a] + 1;
      *(int *)((longlong)param_1 + 0x54) = iStack_1a8;
      uVar21 = (**(code **)(*plVar10 + 0x48))(plVar10,puStack_1c8[8]);
      *(undefined4 *)(param_1 + 0x200010) = uVar21;
      goto LAB_004887da;
    }
  }
  iStack_1a4 = 0;
  iStack_1a8 = 0;
  puStack_1c8 = (uint *)0x0;
LAB_004887da:
  *(undefined4 *)(param_1 + 0x200017) = 0;
  *(undefined4 *)((longlong)param_1 + 0x10000bc) = 0;
  if (*(uint *)((longlong)param_1 + 0x10001f4) == 0) {
    bVar5 = false;
  }
  else {
    uVar13 = *(uint *)((longlong)param_1 + 0x10001f4) & 0xfffffc;
    *(uint *)(param_1 + 0x20003e) = uVar13;
    dVar7 = _DAT_00b03118;
    dVar6 = _DAT_00b030f8;
    if (uVar13 < 0x300000) {
      bVar5 = false;
      do {
        lVar11 = param_1[0x20004b];
        uVar17 = 0;
        uVar19 = uVar13 + 4;
        uVar1 = *(uint *)(lVar11 + (ulonglong)uVar13);
        *(uint *)(param_1 + 0x20003e) = uVar19;
        *(uint *)(param_1 + 0x200042) = uVar1;
        if (uVar19 < 0x300000) {
          uVar17 = *(uint *)(lVar11 + (ulonglong)uVar19) & 0xfffffffc;
        }
        if ((uVar1 & 0x20000000) == 0) {
          uVar17 = uVar17 + uVar13 + 8 & 0xffffff;
          *(uint *)((longlong)param_1 + 0x10001f4) = uVar17;
        }
        else {
          *(uint *)((longlong)param_1 + 0x10001f4) = uVar17;
        }
        uVar19 = uVar13 + 8;
        if (0x2fffff < uVar17) {
          *(undefined4 *)((longlong)param_1 + 0x10001f4) = 0;
        }
        uVar17 = 0;
        *(uint *)(param_1 + 0x20003e) = uVar19;
        if (uVar19 < 0x300000) {
          uVar17 = *(uint *)(lVar11 + (ulonglong)uVar19) & 0xfffffffc;
        }
        if ((uVar1 & 0x10000000) == 0) {
          uVar17 = uVar17 + uVar13 + 0xc & 0xffffff;
          *(uint *)((longlong)param_1 + 0x10001fc) = uVar17;
        }
        else {
          *(uint *)((longlong)param_1 + 0x10001fc) = uVar17;
        }
        uVar19 = uVar13 + 0xc;
        *(uint *)(param_1 + 0x20003e) = uVar19;
        if (0x2fffff < uVar17) {
          *(undefined4 *)((longlong)param_1 + 0x10001fc) = 0;
        }
        if ((uVar1 & 0x800000) != 0) {
          uVar17 = 0;
          if (uVar19 < 0x300000) {
            uVar17 = *(uint *)(lVar11 + (ulonglong)uVar19) & 0xfffffffc;
          }
          if ((uVar1 & 0x8000000) == 0) {
            *(uint *)(param_1 + 0x20003f) = uVar17 + uVar13 + 0x10 & 0xffffff;
          }
          else {
            *(uint *)(param_1 + 0x20003f) = uVar17;
          }
        }
        uVar17 = uVar13 + 0x10;
        *(uint *)(param_1 + 0x20003e) = uVar17;
        if (((uVar1 & 0x200000) == 0) || ((int)uVar1 < 0)) {
          *(uint *)(param_1 + 0x20003e) = uVar13 + 0x18;
        }
        else {
          uVar21 = 0;
          if (uVar17 < 0x300000) {
            uVar21 = *(undefined4 *)(lVar11 + (ulonglong)uVar17);
          }
          uVar17 = uVar13 + 0x14;
          *(undefined4 *)(param_1 + 0x200026) = uVar21;
          uVar21 = 0;
          *(uint *)(param_1 + 0x20003e) = uVar17;
          if (uVar17 < 0x300000) {
            uVar21 = *(undefined4 *)(lVar11 + (ulonglong)uVar17);
          }
          *(undefined4 *)((longlong)param_1 + 0x1000134) = uVar21;
          *(uint *)(param_1 + 0x20003e) = uVar13 + 0x18;
        }
        if ((uVar1 & 0x40000000) != 0) {
          *(undefined4 *)((longlong)param_1 + 0x10001f4) = 0;
        }
        if ((uVar1 & 0x4000000) != 0) {
          uVar13 = *(uint *)(param_1 + 0x20003e);
          uVar21 = 0;
          if (uVar13 < 0x300000) {
            uVar21 = *(undefined4 *)(lVar11 + (ulonglong)uVar13);
          }
          *(undefined4 *)(param_1 + 0x200028) = uVar21;
          uVar17 = uVar13 + 4;
          uVar21 = 0;
          *(uint *)(param_1 + 0x20003e) = uVar17;
          if (uVar17 < 0x300000) {
            uVar21 = *(undefined4 *)(lVar11 + (ulonglong)uVar17);
          }
          uVar17 = uVar13 + 8;
          *(undefined4 *)((longlong)param_1 + 0x1000144) = uVar21;
          uVar21 = 0;
          *(uint *)(param_1 + 0x20003e) = uVar17;
          if (uVar17 < 0x300000) {
            uVar21 = *(undefined4 *)(lVar11 + (ulonglong)uVar17);
          }
          uVar17 = uVar13 + 0xc;
          *(undefined4 *)(param_1 + 0x200027) = uVar21;
          uVar21 = 0;
          *(uint *)(param_1 + 0x20003e) = uVar17;
          if (uVar17 < 0x300000) {
            uVar21 = *(undefined4 *)(lVar11 + (ulonglong)uVar17);
          }
          *(undefined4 *)((longlong)param_1 + 0x100013c) = uVar21;
          *(uint *)(param_1 + 0x20003e) = uVar13 + 0x10;
        }
        if ((uVar1 & 0x2000000) != 0) {
          uVar13 = *(uint *)(param_1 + 0x20003e);
          uVar21 = 0;
          if (uVar13 < 0x300000) {
            uVar21 = *(undefined4 *)(lVar11 + (ulonglong)uVar13);
          }
          *(undefined4 *)(param_1 + 0x200029) = uVar21;
          uVar17 = uVar13 + 4;
          uVar21 = 0;
          *(uint *)(param_1 + 0x20003e) = uVar17;
          if (uVar17 < 0x300000) {
            uVar21 = *(undefined4 *)(lVar11 + (ulonglong)uVar17);
          }
          *(undefined4 *)((longlong)param_1 + 0x100014c) = uVar21;
          *(uint *)(param_1 + 0x20003e) = uVar13 + 8;
        }
        if ((uVar1 & 0x1000000) != 0) {
          uVar13 = *(uint *)(param_1 + 0x20003e);
          uVar21 = 0;
          if (uVar13 < 0x300000) {
            uVar21 = *(undefined4 *)(lVar11 + (ulonglong)uVar13);
          }
          *(undefined4 *)(param_1 + 0x200022) = uVar21;
          *(uint *)(param_1 + 0x20003e) = uVar13 + 4;
        }
        if ((uVar1 & 0x400000) == 0) {
          uVar17 = *(uint *)((longlong)param_1 + 0x10001fc);
          uVar13 = 0;
          if (uVar17 < 0x300000) {
            uVar13 = *(uint *)(lVar11 + (ulonglong)uVar17);
          }
          uVar19 = uVar17 + 4;
          *(uint *)((longlong)param_1 + 0x1000214) = uVar13;
          *(uint *)((longlong)param_1 + 0x10001fc) = uVar19;
          if ((uVar1 & 0x200) == 0) {
            uVar22 = 0;
            if (uVar19 < 0x300000) {
              uVar22 = (ulonglong)*(uint *)(lVar11 + (ulonglong)uVar19);
            }
            uVar19 = uVar17 + 8;
            *(int *)(param_1 + 0x200043) = (int)uVar22;
            *(uint *)((longlong)param_1 + 0x10001fc) = uVar19;
          }
          else {
            uVar22 = (ulonglong)*(uint *)(param_1 + 0x200043);
          }
        }
        else {
          uVar17 = *(uint *)(param_1 + 0x20003e);
          uVar13 = 0;
          if (uVar17 < 0x300000) {
            uVar13 = *(uint *)(lVar11 + (ulonglong)uVar17);
          }
          uVar19 = uVar17 + 4;
          *(uint *)((longlong)param_1 + 0x1000214) = uVar13;
          *(uint *)(param_1 + 0x20003e) = uVar19;
          if ((uVar1 & 0x200) == 0) {
            uVar22 = 0;
            if (uVar19 < 0x300000) {
              uVar22 = (ulonglong)*(uint *)(lVar11 + (ulonglong)uVar19);
            }
            *(int *)(param_1 + 0x200043) = (int)uVar22;
            uVar19 = *(uint *)((longlong)param_1 + 0x10001fc);
            *(uint *)(param_1 + 0x20003e) = uVar17 + 8;
          }
          else {
            uVar22 = (ulonglong)*(uint *)(param_1 + 0x200043);
            uVar19 = *(uint *)((longlong)param_1 + 0x10001fc);
          }
        }
        uVar17 = uVar1 & 0x200;
        if ((uVar1 & 0x800000) != 0) {
          if ((uVar13 & 7) < 3) {
            uVar18 = *(uint *)(param_1 + 0x20003f) >> 1;
            plVar10 = param_1;
            do {
              uVar20 = 0;
              if (uVar18 * 2 < 0x300000) {
                uVar20 = (uint)*(ushort *)(param_1[0x20004b] + (ulonglong)(uVar18 * 2 ^ 2));
              }
              *(uint *)(plVar10 + 0x20002e) = uVar20;
              plVar10 = (longlong *)((longlong)plVar10 + 4);
              uVar18 = uVar18 + 1;
            } while (plVar10 != param_1 + 4);
          }
          else if ((uVar13 & 7) == 3) {
            uVar18 = *(uint *)(param_1 + 0x20003f) >> 1;
            plVar10 = param_1;
            do {
              uVar20 = 0;
              if (uVar18 * 2 < 0x300000) {
                uVar20 = (uint)*(ushort *)(param_1[0x20004b] + (ulonglong)(uVar18 * 2 ^ 2));
              }
              *(uint *)(plVar10 + 0x20002e) = uVar20;
              plVar10 = (longlong *)((longlong)plVar10 + 4);
              uVar18 = uVar18 + 1;
            } while (plVar10 != param_1 + 8);
          }
          else {
            puVar12 = (uint *)(param_1 + 0x20002e);
            uVar18 = *(uint *)(param_1 + 0x20003f) >> 1;
            do {
              uVar20 = 0;
              if (uVar18 * 2 < 0x300000) {
                uVar20 = (uint)*(ushort *)(param_1[0x20004b] + (ulonglong)(uVar18 * 2 ^ 2));
              }
              *puVar12 = uVar20;
              puVar12 = puVar12 + 1;
              uVar18 = uVar18 + 1;
            } while (puVar12 != (uint *)(param_1 + 0x20003e));
          }
        }
        iVar8 = (int)param_1[0x200029];
        *(uint *)((longlong)param_1 + 0x100027c) = uVar1;
        iVar14 = *(int *)((longlong)param_1 + 0x100014c);
        *(uint *)(param_1 + 0x200050) = uVar13;
        iVar2 = (int)param_1[0x200028];
        *(uint *)((longlong)param_1 + 0x1000284) = (uint)uVar22;
        iVar3 = *(int *)((longlong)param_1 + 0x1000144);
        *(uint *)(param_1 + 0x20004e) = uVar19;
        iVar15 = (int)param_1[0x200027];
        iVar24 = *(int *)((longlong)param_1 + 0x100013c);
        *(int *)(param_1 + 0x200051) = iVar8;
        *(int *)(param_1 + 0x200053) = iVar8 >> 4;
        iVar23 = *(int *)((longlong)param_1 + 0x1000134);
        *(int *)((longlong)param_1 + 0x1000294) = iVar3;
        *(int *)((longlong)param_1 + 0x100029c) = iVar14 >> 4;
        *(int *)((longlong)param_1 + 0x100028c) = iVar14;
        *(int *)(param_1 + 0x200054) = iVar2 >> 4;
        *(int *)(param_1 + 0x200052) = iVar2;
        *(int *)((longlong)param_1 + 0x10002a4) = iVar3 >> 4;
        iVar16 = (int)param_1[0x200026];
        param_1[0x200057] = (longlong)((double)iVar8 * dVar7);
        *(int *)(param_1 + 0x200055) = iVar15;
        *(int *)((longlong)param_1 + 0x10002ac) = iVar24;
        *(int *)(param_1 + 0x200056) = iVar16;
        *(int *)((longlong)param_1 + 0x10002b4) = iVar23;
        param_1[0x200058] = (longlong)((double)iVar14 * dVar7);
        param_1[0x200059] = (longlong)((double)iVar2 * dVar7);
        lVar11 = 0;
        param_1[0x20005a] = (longlong)((double)iVar3 * dVar7);
        param_1[0x20005b] = (longlong)((double)iVar15 * dVar6);
        param_1[0x20005c] = (longlong)((double)iVar24 * dVar6);
        param_1[0x20005d] = (longlong)((double)iVar16 * dVar6);
        param_1[0x20005e] = (longlong)((double)iVar23 * dVar6);
        do {
          *(short *)((longlong)param_1 + lVar11 + 0x1000300) =
               (short)*(undefined4 *)((longlong)param_1 + lVar11 * 2 + 0x1000170);
          lVar11 = lVar11 + 2;
        } while (lVar11 != 0x40);
        *(int *)(param_1 + 0x200068) = (int)param_1[0x200022];
        uVar19 = *(uint *)(param_1 + 0x200020);
        *(uint *)((longlong)param_1 + 0x1000344) = uVar19;
        if (uVar17 == 0) {
          *(uint *)(param_1 + 0x20005f) = (uint)(uVar22 >> 0xc) & 3;
        }
        else {
          *(uint *)(param_1 + 0x20005f) = uVar19 >> 0x14 & 3;
        }
        *(uint *)((longlong)param_1 + 0x10002fc) = (uint)((uVar1 & 0x40) != 0);
        if (((uVar17 != 0) || ((uVar22 & 0x4000) == 0)) && ((uVar19 & 0x8000000) != 0)) {
          *(uint *)((longlong)param_1 + 0x10002fc) = *(uint *)((longlong)param_1 + 0x10002fc) | 2;
        }
        if ((-1 < (int)uVar1) && ((*(uint *)(param_1 + 0x200042) & 0x60000) != 0)) {
          *(int *)((longlong)param_1 + 0x10000bc) = *(int *)((longlong)param_1 + 0x10000bc) + 1;
          if (uVar17 == 0) {
            if (((uVar22 & 0x800) == 0) ||
               (*(int *)(&DAT_00b030a0 + (ulonglong)(uVar13 & 7) * 4) != 0x10)) {
              iVar8 = FUN_00487100(param_1,puStack_1c8);
              *(int *)(param_1 + 0x200017) = (int)param_1[0x200017] + iVar8;
            }
            else {
              param_1[0x20004d] = 0;
              iVar8 = ((uint)uVar22 & 0x7ff) + 1;
              iVar14 = ((uVar13 & 0xffc0) >> 5) + 2;
              *(int *)(param_1 + 0x20004f) = iVar8;
              *(int *)((longlong)param_1 + 0x1000274) = iVar14;
              *(int *)(param_1 + 0x200017) = (int)param_1[0x200017] + iVar8 * iVar14 * 2;
            }
          }
          else {
            iVar8 = FUN_004859b0(param_1);
            *(int *)(param_1 + 0x200017) = (int)param_1[0x200017] + iVar8;
          }
          if (param_2 == '\0') {
            if (puStack_1c8 == (uint *)0x0) {
              if ((char)param_1[8] == '\0') {
                FUN_00480290(param_1);
              }
              else {
                FUN_00704200();
              }
            }
            else {
              FUN_004860d0(param_1,puStack_1c8,iStack_1a4,iStack_1a8);
            }
          }
          iVar8 = FUN_00482950(param_1);
          iVar16 = (int)param_1[0x200056];
          bVar5 = true;
          *(int *)(param_1 + 0x200017) = (int)param_1[0x200017] + iVar8;
          iVar15 = (int)param_1[0x200055];
          iVar23 = *(int *)((longlong)param_1 + 0x10002b4);
          iVar24 = *(int *)((longlong)param_1 + 0x10002ac);
        }
        *(int *)(param_1 + 0x200026) = iVar16 + iVar15 * *(int *)((longlong)param_1 + 0x1000274);
        *(int *)((longlong)param_1 + 0x1000134) =
             *(int *)((longlong)param_1 + 0x1000274) * iVar24 + iVar23;
        if (*(uint *)((longlong)param_1 + 0x10001f4) == 0) goto LAB_00488e21;
        uVar13 = *(uint *)((longlong)param_1 + 0x10001f4) & 0xfffffc;
        *(uint *)(param_1 + 0x20003e) = uVar13;
      } while (uVar13 < 0x300000);
    }
    else {
      bVar5 = false;
    }
    *(undefined4 *)((longlong)param_1 + 0x10001f4) = 0;
  }
LAB_00488e21:
  if (param_2 == '\0') {
    if (puStack_1c8 == (uint *)0x0) {
      if ((char)param_1[8] != '\0') {
        FUN_00703e20(param_1);
      }
      (**(code **)(*_DAT_00cf4050 + 0xe0))
                (_DAT_00cf4050,*(undefined4 *)((longlong)param_1 + 0x1000084),(int)param_1[0x200017]
                );
    }
    else {
      (**(code **)(*_DAT_00cf4050 + 0xe0))
                (_DAT_00cf4050,*(undefined4 *)((longlong)param_1 + 0x1000084),(int)param_1[0x200017]
                );
      plVar10 = _DAT_00cf4050;
      if (((int *)param_1[0xc] != (int *)0x0) && (*(int *)param_1[0xc] != 0)) {
        *(undefined1 *)(puStack_1c8 + 0x13) = 1;
        (**(code **)(*plVar10 + 0x88))(plVar10,param_1 + 9,0);
        FUN_00943e90(param_1 + 0xc,0);
        FUN_00948300(param_1 + 0x20006c,0);
      }
    }
    if (bVar5) {
      if (param_1[0x200011] != 0) {
        pcVar9 = (code *)param_1[0x200012];
        plVar10 = (longlong *)(param_1[0x200011] + param_1[0x200013]);
        if (((ulonglong)pcVar9 & 1) != 0) {
          pcVar9 = *(code **)(pcVar9 + *plVar10 + -1);
        }
        (*pcVar9)(plVar10,*(undefined4 *)((longlong)param_1 + 0x100012c),
                  ((int)*(uint *)((longlong)param_1 + 0x1000354) >> 1) * (int)param_1[0x200044] +
                  (*(uint *)((longlong)param_1 + 0x1000354) & 1) * 2 + 4 +
                  (int)param_1[0x20006a] * 4);
      }
      if (puStack_1c8 != (uint *)0x0) {
        (**(code **)(*param_1 + 0x78))(param_1,param_1,0x10102);
      }
    }
  }
  else {
    memcpy(param_1 + 0x20001e,auStack_168,0x100);
    *(undefined4 *)(param_1 + 0x200042) = uStack_19c;
    param_1[0x20003e] = lStack_188;
    *(undefined4 *)((longlong)param_1 + 0x1000214) = uStack_198;
    param_1[0x20003f] = lStack_180;
    *(undefined4 *)(param_1 + 0x200043) = uStack_194;
    param_1[0x200040] = lStack_178;
    *(undefined4 *)((longlong)param_1 + 0x100021c) = uStack_190;
    param_1[0x200041] = lStack_170;
    *(undefined4 *)(param_1 + 0x200044) = uStack_18c;
  }
  if ((int)param_1[0x200018] < *(int *)((longlong)param_1 + 0x10000bc)) {
    *(undefined4 *)(param_1 + 0x200018) = *(undefined4 *)((longlong)param_1 + 0x10000bc);
  }
  uVar13 = 0;
  if (*(uint *)(param_1 + 0x20001d) != 0) {
    uVar13 = (*(uint *)(param_1 + 0x200017) >> 2) / *(uint *)(param_1 + 0x20001d);
  }
  return uVar13;
}


